# SkillSwap Platform

This project is a Fiverr-inspired MERN stack platform connecting freelancers and clients, with a modern glassmorphism UI and Three.js effects.

## Structure
- `/server` — Node.js/Express backend (MongoDB Atlas, APIs)
- `/client` — React frontend (Tailwind CSS, Three.js, modern UI)

## Getting Started

### Backend
1. `cd server`
2. `npm install`
3. Create a `.env` file (see `.env.example`)
4. `npm run dev`

### Frontend
1. `cd client`
2. `npm install`
3. `npm start`

---

## Features
- Role-based authentication (JWT, bcrypt)
- Real-time bidding & messaging (Socket.io)
- Project posting & management
- Analytics dashboard
- Admin verification & analytics
- Modern glowing UI with glassmorphism

---

## Theme
- Inspired by Fiverr
- Glowing colors
- Glassmorphism
- Three.js for 3D effects
