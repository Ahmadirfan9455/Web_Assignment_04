import React, { useEffect, lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { GoogleOAuthProvider } from '@react-oauth/google';
import { useAuth } from './hooks/useAuth';
import { useSocket } from './hooks/useSocket';
import Layout from './components/layout/Layout';
import LoadingScreen from './components/ui/LoadingScreen';
import ProtectedRoute from './components/auth/ProtectedRoute';
import AdminLayout from './components/layout/AdminLayout';

// Lazy-loaded pages for better performance
const Home = lazy(() => import('./pages/Home'));
const Login = lazy(() => import('./pages/auth/Login'));
const Register = lazy(() => import('./pages/auth/Register'));
const VerifyEmail = lazy(() => import('./pages/auth/VerifyEmail'));
const AuthSuccess = lazy(() => import('./pages/auth/AuthSuccess'));
const Dashboard = lazy(() => import('./pages/dashboard/Dashboard'));
const Projects = lazy(() => import('./pages/projects/Projects'));
const ProjectDetails = lazy(() => import('./pages/projects/ProjectDetails'));
const CreateProject = lazy(() => import('./pages/projects/CreateProject'));
const FreelancerSearch = lazy(() => import('./pages/freelancers/FreelancerSearch'));
const FreelancerProfile = lazy(() => import('./pages/freelancers/FreelancerProfile'));
const Messages = lazy(() => import('./pages/messages/Messages'));
const Profile = lazy(() => import('./pages/profile/Profile'));
const EditProfile = lazy(() => import('./pages/profile/EditProfile'));
const LocationPage = lazy(() => import('./pages/profile/LocationPage'));
const Contracts = lazy(() => import('./pages/contracts/Contracts'));
const ContractDetails = lazy(() => import('./pages/contracts/ContractDetails'));
const NotFound = lazy(() => import('./pages/NotFound'));
const ForgotPassword = lazy(() => import('./pages/auth/ForgotPassword'));
const ResetPassword = lazy(() => import('./pages/auth/ResetPassword'));

// Admin pages
const AdminDashboard = lazy(() => import('./pages/admin/DashboardNew'));
const UserManagement = lazy(() => import('./pages/admin/UserManagement'));
const ProjectManagement = lazy(() => import('./pages/admin/ProjectManagement'));
const AdminContracts = lazy(() => import('./pages/admin/ContractsList'));
const AdminAnalytics = lazy(() => import('./pages/admin/Analytics'));
const PlatformSettings = lazy(() => import('./pages/admin/PlatformSettings'));
const TimeTracking = lazy(() => import('./pages/admin/TimeTracking'));
const MilestoneTracking = lazy(() => import('./pages/admin/MilestoneTracking'));

function App() {
  const { user, isLoading } = useAuth();
  const { socket, connect, disconnect } = useSocket();

  useEffect(() => {
    // Connect to socket when user is authenticated
    if (user && !socket) {
      connect();
    }

    // Disconnect from socket when user logs out
    return () => {
      if (socket) {
        disconnect();
      }
    };
  }, [user, socket, connect, disconnect]);

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <GoogleOAuthProvider clientId="478576519244-je16m0dn5begc1neh8muf62hmd647pkg.apps.googleusercontent.com">
      <Suspense fallback={<LoadingScreen />}>
        <Routes>
        {/* Public routes */}
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="login" element={!user ? <Login /> : <Navigate to="/dashboard" />} />
          <Route path="register" element={!user ? <Register /> : <Navigate to="/dashboard" />} />
          <Route path="verify-email/:token" element={<VerifyEmail />} />
          <Route path="forgot-password" element={!user ? <ForgotPassword /> : <Navigate to="/dashboard" />} />
          <Route path="reset-password/:token" element={!user ? <ResetPassword /> : <Navigate to="/dashboard" />} />
          <Route path="auth/success" element={<AuthSuccess />} />
          <Route path="freelancers" element={<FreelancerSearch />} />
          <Route path="freelancers/:id" element={<FreelancerProfile />} />

          {/* Protected routes */}
          <Route element={<ProtectedRoute />}>
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="projects" element={<Projects />} />
            <Route path="projects/create" element={<CreateProject />} />
            <Route path="projects/:id" element={<ProjectDetails />} />
            <Route path="messages" element={<Messages />} />
            <Route path="messages/:id" element={<Messages />} />
            <Route path="profile" element={<Profile />} />
            <Route path="profile/edit" element={<EditProfile />} />
            <Route path="profile/location" element={<LocationPage />} />
            <Route path="contracts" element={<Contracts />} />
            <Route path="contracts/:id" element={<ContractDetails />} />
          </Route>

          {/* Admin routes */}
          <Route 
            path="admin" 
            element={
              user && user.role === 'admin' 
                ? <AdminDashboard /> 
                : <Navigate to="/login" />
            } 
          />
          <Route 
            path="admin/dashboard" 
            element={
              user && user.role === 'admin' 
                ? <AdminDashboard /> 
                : <Navigate to="/login" />
            } 
          />
          <Route 
            path="admin/users" 
            element={
              user && user.role === 'admin' 
                ? <UserManagement /> 
                : <Navigate to="/login" />
            } 
          />
          <Route 
            path="admin/projects" 
            element={
              user && user.role === 'admin' 
                ? <ProjectManagement /> 
                : <Navigate to="/login" />
            } 
          />
          <Route 
            path="admin/contracts" 
            element={
              user && user.role === 'admin' 
                ? <AdminContracts /> 
                : <Navigate to="/login" />
            } 
          />
          <Route 
            path="admin/analytics" 
            element={
              user && user.role === 'admin' 
                ? <AdminAnalytics /> 
                : <Navigate to="/login" />
            } 
          />
          <Route 
            path="admin/settings" 
            element={
              user && user.role === 'admin' 
                ? <PlatformSettings /> 
                : <Navigate to="/login" />
            } 
          />
          <Route 
            path="admin/time-tracking" 
            element={
              user && user.role === 'admin' 
                ? <TimeTracking /> 
                : <Navigate to="/login" />
            } 
          />
          <Route 
            path="admin/milestone-tracking" 
            element={
              user && user.role === 'admin' 
                ? <MilestoneTracking /> 
                : <Navigate to="/login" />
            } 
          />

          {/* 404 route */}
          <Route path="*" element={<NotFound />} />
        </Route>
        </Routes>
      </Suspense>
    </GoogleOAuthProvider>
  );
}

export default App;
