import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';
import ContractForm from '../../components/contracts/ContractForm';

const CreateContract = () => {
  const { projectId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  // State
  const [project, setProject] = useState(null);
  const [existingContract, setExistingContract] = useState(null);
  const [loading, setLoading] = useState(true);
  
  // Fetch project and check for existing contract
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch project
        const { data: projectData } = await axios.get(`/api/projects/${projectId}`);
        setProject(projectData);
        
        // Check for existing contract
        try {
          const { data: contractData } = await axios.get(`/api/contracts/project/${projectId}`);
          setExistingContract(contractData);
        } catch (error) {
          // Contract might not exist yet, which is fine
          console.log('No contract found for this project');
        }
        
        setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        toast.error('Failed to load project data');
        setLoading(false);
      }
    };
    
    fetchData();
  }, [projectId]);
  
  // Handle contract creation
  const handleContractCreated = (contract) => {
    // Navigate to contract details
    navigate(`/contracts/${contract._id}`);
  };
  
  // Loading state
  if (loading) {
    return <LoadingScreen />;
  }
  
  // Check if user is authorized (only clients can create contracts)
  if (!user || user.role !== 'client') {
    return (
      <div className="container mx-auto px-4 py-8">
        <GlassCard className="p-6 text-center">
          <h2 className="text-xl text-white mb-4">Unauthorized</h2>
          <p className="text-indigo-300 mb-4">
            Only clients can create contracts for projects.
          </p>
          <GlowButton
            variant="primary"
            onClick={() => navigate('/projects')}
          >
            Browse Projects
          </GlowButton>
        </GlassCard>
      </div>
    );
  }
  
  // Check if project exists
  if (!project) {
    return (
      <div className="container mx-auto px-4 py-8">
        <GlassCard className="p-6 text-center">
          <h2 className="text-xl text-white mb-4">Project not found</h2>
          <GlowButton
            variant="primary"
            onClick={() => navigate('/projects')}
          >
            Browse Projects
          </GlowButton>
        </GlassCard>
      </div>
    );
  }
  
  // Check if user owns the project
  if (project.client._id !== user._id) {
    return (
      <div className="container mx-auto px-4 py-8">
        <GlassCard className="p-6 text-center">
          <h2 className="text-xl text-white mb-4">Unauthorized</h2>
          <p className="text-indigo-300 mb-4">
            You can only create contracts for your own projects.
          </p>
          <GlowButton
            variant="primary"
            onClick={() => navigate('/projects')}
          >
            Browse Projects
          </GlowButton>
        </GlassCard>
      </div>
    );
  }
  
  // Check if contract already exists
  if (existingContract) {
    return (
      <div className="container mx-auto px-4 py-8">
        <GlassCard className="p-6 text-center">
          <h2 className="text-xl text-white mb-4">Contract Already Exists</h2>
          <p className="text-indigo-300 mb-4">
            A contract has already been created for this project.
          </p>
          <div className="flex justify-center space-x-4">
            <GlowButton
              variant="secondary"
              onClick={() => navigate(`/projects/${projectId}`)}
            >
              Project Details
            </GlowButton>
            <GlowButton
              variant="primary"
              onClick={() => navigate(`/contracts/${existingContract._id}`)}
            >
              View Contract
            </GlowButton>
          </div>
        </GlassCard>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-white">Create Contract</h1>
          <p className="text-indigo-300">
            Create a legally binding contract for your project with the selected freelancer.
          </p>
        </div>
        
        <ContractForm
          projectId={projectId}
          onContractCreated={handleContractCreated}
        />
      </motion.div>
    </div>
  );
};

export default CreateContract;
