import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

const Contracts = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [contracts, setContracts] = useState([]);
  const [activeTab, setActiveTab] = useState('active');

  // Simulate fetching contracts
  useEffect(() => {
    const timer = setTimeout(() => {
      // Mock contracts data
      setContracts([]);
      setLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [user, activeTab]);

  const filteredContracts = contracts.filter(contract => {
    if (activeTab === 'active') {
      return ['pending', 'active', 'in_progress'].includes(contract.status);
    } else if (activeTab === 'completed') {
      return contract.status === 'completed';
    } else {
      return true; // all
    }
  });

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-bold text-white mb-6">My Contracts</h1>
        
        {/* Tabs */}
        <div className="flex border-b border-gray-700 mb-8">
          <button
            className={`px-4 py-2 font-medium ${
              activeTab === 'active'
                ? 'text-indigo-400 border-b-2 border-indigo-400'
                : 'text-gray-400 hover:text-indigo-300'
            }`}
            onClick={() => setActiveTab('active')}
          >
            Active
          </button>
          <button
            className={`px-4 py-2 font-medium ${
              activeTab === 'completed'
                ? 'text-indigo-400 border-b-2 border-indigo-400'
                : 'text-gray-400 hover:text-indigo-300'
            }`}
            onClick={() => setActiveTab('completed')}
          >
            Completed
          </button>
          <button
            className={`px-4 py-2 font-medium ${
              activeTab === 'all'
                ? 'text-indigo-400 border-b-2 border-indigo-400'
                : 'text-gray-400 hover:text-indigo-300'
            }`}
            onClick={() => setActiveTab('all')}
          >
            All
          </button>
        </div>
        
        {/* Contracts List */}
        {filteredContracts.length > 0 ? (
          <div className="space-y-6">
            {filteredContracts.map((contract) => (
              <GlassCard key={contract.id} className="p-6">
                <div className="flex flex-col md:flex-row justify-between">
                  <div>
                    <h2 className="text-xl font-semibold text-white">
                      <Link to={`/contracts/${contract.id}`} className="hover:text-indigo-400">
                        {contract.title}
                      </Link>
                    </h2>
                    <div className="mt-2">
                      <span className={`px-3 py-1 rounded-full text-sm ${
                        contract.status === 'completed'
                          ? 'bg-green-900/50 text-green-300'
                          : contract.status === 'active' || contract.status === 'in_progress'
                            ? 'bg-blue-900/50 text-blue-300'
                            : contract.status === 'pending'
                              ? 'bg-yellow-900/50 text-yellow-300'
                              : 'bg-red-900/50 text-red-300'
                      }`}>
                        {contract.status.replace('_', ' ').toUpperCase()}
                      </span>
                    </div>
                    <div className="mt-4 text-indigo-300">
                      <p>
                        <span className="font-medium">
                          {user.role === 'client' ? 'Freelancer:' : 'Client:'}
                        </span>{' '}
                        {user.role === 'client' ? contract.freelancer.name : contract.client.name}
                      </p>
                      <p>
                        <span className="font-medium">Project:</span> {contract.project.title}
                      </p>
                      <p>
                        <span className="font-medium">Created:</span>{' '}
                        {new Date(contract.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 md:mt-0 md:ml-6 flex flex-col items-end">
                    <div className="text-xl font-bold text-white">${contract.amount.toFixed(2)}</div>
                    <div className="text-indigo-300 mt-1">
                      {contract.paymentType === 'fixed' ? 'Fixed Price' : 'Hourly Rate'}
                    </div>
                    <Link to={`/contracts/${contract.id}`} className="mt-4">
                      <GlowButton variant="secondary" size="sm">
                        View Details
                      </GlowButton>
                    </Link>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
        ) : (
          <GlassCard className="p-8 text-center">
            <h3 className="text-xl font-semibold text-white mb-2">No contracts found</h3>
            <p className="text-indigo-300 mb-6">
              {activeTab === 'active'
                ? "You don't have any active contracts at the moment."
                : activeTab === 'completed'
                  ? "You don't have any completed contracts yet."
                  : "You don't have any contracts yet."}
            </p>
            {user.role === 'client' && (
              <Link to="/projects/create">
                <GlowButton variant="primary">Post a Project</GlowButton>
              </Link>
            )}
            {user.role === 'freelancer' && (
              <Link to="/projects">
                <GlowButton variant="primary">Browse Projects</GlowButton>
              </Link>
            )}
          </GlassCard>
        )}
      </motion.div>
    </div>
  );
};

export default Contracts;
