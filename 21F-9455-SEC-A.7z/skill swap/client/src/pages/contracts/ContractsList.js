import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

const ContractsList = () => {
  const { user } = useAuth();
  
  // State
  const [contracts, setContracts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('active'); // 'active', 'pending', 'completed'
  
  // Fetch contracts
  useEffect(() => {
    const fetchContracts = async () => {
      try {
        setLoading(true);
        
        // Different endpoints based on user role
        let endpoint = '';
        if (user.role === 'client') {
          endpoint = '/api/contracts/client';
        } else if (user.role === 'freelancer') {
          endpoint = '/api/contracts/freelancer';
        } else if (user.role === 'admin') {
          endpoint = '/api/contracts';
        }
        
        const { data } = await axios.get(endpoint);
        setContracts(data);
        
        setLoading(false);
      } catch (error) {
        console.error('Error fetching contracts:', error);
        toast.error('Failed to load contracts');
        setLoading(false);
      }
    };
    
    fetchContracts();
  }, [user]);
  
  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'Not set';
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  // Get contract status
  const getContractStatus = (contract) => {
    if (!contract) return 'Unknown';
    
    if (contract.status === 'completed') {
      return 'Completed';
    } else if (contract.status === 'terminated') {
      return 'Terminated';
    } else if (contract.clientSignedAt && contract.freelancerSignedAt) {
      return 'Active';
    } else if (contract.clientSignedAt || contract.freelancerSignedAt) {
      return 'Partially Signed';
    } else {
      return 'Pending Signatures';
    }
  };
  
  // Get contract status color
  const getContractStatusColor = (status) => {
    switch (status) {
      case 'Active':
        return 'text-green-400';
      case 'Partially Signed':
        return 'text-yellow-400';
      case 'Pending Signatures':
        return 'text-indigo-400';
      case 'Completed':
        return 'text-blue-400';
      case 'Terminated':
        return 'text-red-400';
      default:
        return 'text-gray-400';
    }
  };
  
  // Filter contracts based on active tab
  const filteredContracts = contracts.filter(contract => {
    const status = getContractStatus(contract);
    
    if (activeTab === 'active') {
      return status === 'Active';
    } else if (activeTab === 'pending') {
      return status === 'Pending Signatures' || status === 'Partially Signed';
    } else if (activeTab === 'completed') {
      return status === 'Completed' || status === 'Terminated';
    }
    
    return true;
  });
  
  // Loading state
  if (loading) {
    return <LoadingScreen />;
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-white">Contracts</h1>
          <p className="text-indigo-300">
            Manage your contracts and agreements
          </p>
        </div>
        
        {/* Tabs */}
        <div className="mb-6 border-b border-gray-700">
          <div className="flex space-x-8">
            <button
              className={`pb-2 px-1 ${
                activeTab === 'active'
                  ? 'text-indigo-400 border-b-2 border-indigo-400 font-medium'
                  : 'text-indigo-300 hover:text-indigo-200'
              }`}
              onClick={() => setActiveTab('active')}
            >
              Active
            </button>
            <button
              className={`pb-2 px-1 ${
                activeTab === 'pending'
                  ? 'text-indigo-400 border-b-2 border-indigo-400 font-medium'
                  : 'text-indigo-300 hover:text-indigo-200'
              }`}
              onClick={() => setActiveTab('pending')}
            >
              Pending
            </button>
            <button
              className={`pb-2 px-1 ${
                activeTab === 'completed'
                  ? 'text-indigo-400 border-b-2 border-indigo-400 font-medium'
                  : 'text-indigo-300 hover:text-indigo-200'
              }`}
              onClick={() => setActiveTab('completed')}
            >
              Completed
            </button>
          </div>
        </div>
        
        {/* Contracts List */}
        {filteredContracts.length > 0 ? (
          <div className="space-y-4">
            {filteredContracts.map(contract => (
              <motion.div
                key={contract._id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <GlassCard className="p-6">
                  <div className="flex flex-col md:flex-row justify-between">
                    <div>
                      <h2 className="text-xl font-semibold text-white">
                        {contract.project.title}
                      </h2>
                      
                      <div className="mt-2 grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <p className="text-indigo-300 text-sm">Contract Amount</p>
                          <p className="text-white font-medium">${contract.amount.toFixed(2)}</p>
                        </div>
                        
                        <div>
                          <p className="text-indigo-300 text-sm">Start Date</p>
                          <p className="text-white font-medium">{formatDate(contract.startDate)}</p>
                        </div>
                        
                        <div>
                          <p className="text-indigo-300 text-sm">End Date</p>
                          <p className="text-white font-medium">{formatDate(contract.endDate)}</p>
                        </div>
                      </div>
                      
                      <div className="mt-4 flex flex-wrap gap-2">
                        {user.role === 'client' ? (
                          <div className="flex items-center">
                            <p className="text-indigo-300 text-sm mr-2">Freelancer:</p>
                            <p className="text-white">{contract.freelancer.name}</p>
                          </div>
                        ) : (
                          <div className="flex items-center">
                            <p className="text-indigo-300 text-sm mr-2">Client:</p>
                            <p className="text-white">{contract.client.name}</p>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="mt-4 md:mt-0 flex flex-col items-end justify-between">
                      <span className={`${getContractStatusColor(getContractStatus(contract))} font-medium`}>
                        {getContractStatus(contract)}
                      </span>
                      
                      <div className="mt-4 md:mt-auto">
                        <Link to={`/contracts/${contract._id}`}>
                          <GlowButton variant="primary">
                            View Contract
                          </GlowButton>
                        </Link>
                      </div>
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        ) : (
          <GlassCard className="p-6 text-center">
            <p className="text-indigo-300">
              No {activeTab} contracts found.
            </p>
          </GlassCard>
        )}
      </motion.div>
    </div>
  );
};

export default ContractsList;
