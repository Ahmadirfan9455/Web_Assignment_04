import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';
import ContractDetailsComponent from '../../components/contracts/ContractDetails';

const ContractDetails = () => {
  const { contractId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  // State
  const [contract, setContract] = useState(null);
  const [loading, setLoading] = useState(true);
  
  // Fetch contract data
  useEffect(() => {
    const fetchContract = async () => {
      try {
        setLoading(true);
        
        const { data } = await axios.get(`/api/contracts/${contractId}`);
        setContract(data);
        
        setLoading(false);
      } catch (error) {
        console.error('Error fetching contract:', error);
        toast.error('Failed to load contract details');
        setLoading(false);
      }
    };
    
    fetchContract();
  }, [contractId]);
  
  // Handle contract update
  const handleContractUpdate = async () => {
    try {
      // Refresh contract data
      const { data } = await axios.get(`/api/contracts/${contractId}`);
      setContract(data);
    } catch (error) {
      console.error('Error refreshing contract:', error);
      toast.error('Failed to refresh contract details');
    }
  };
  
  // Check if user is authorized to view this contract
  const isAuthorized = () => {
    if (!user || !contract) return false;
    
    return (
      user.role === 'admin' ||
      (user.role === 'client' && contract.client._id === user._id) ||
      (user.role === 'freelancer' && contract.freelancer._id === user._id)
    );
  };
  
  // Loading state
  if (loading) {
    return <LoadingScreen />;
  }
  
  // Contract not found
  if (!contract) {
    return (
      <div className="container mx-auto px-4 py-8">
        <GlassCard className="p-6 text-center">
          <h2 className="text-xl text-white mb-4">Contract not found</h2>
          <GlowButton
            variant="primary"
            onClick={() => navigate('/dashboard')}
          >
            Go to Dashboard
          </GlowButton>
        </GlassCard>
      </div>
    );
  }
  
  // Unauthorized
  if (!isAuthorized()) {
    return (
      <div className="container mx-auto px-4 py-8">
        <GlassCard className="p-6 text-center">
          <h2 className="text-xl text-white mb-4">Unauthorized</h2>
          <p className="text-indigo-300 mb-4">
            You don't have permission to view this contract.
          </p>
          <GlowButton
            variant="primary"
            onClick={() => navigate('/dashboard')}
          >
            Go to Dashboard
          </GlowButton>
        </GlassCard>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <h1 className="text-2xl font-bold text-white">Contract Details</h1>
            <p className="text-indigo-300">
              View and manage contract for project: {contract.project.title}
            </p>
          </div>
          
          <div className="mt-4 md:mt-0">
            <Link to={`/projects/${contract.project._id}`}>
              <GlowButton variant="secondary">
                Project Details
              </GlowButton>
            </Link>
          </div>
        </div>
        
        <ContractDetailsComponent
          contract={contract}
          onContractUpdate={handleContractUpdate}
        />
      </motion.div>
    </div>
  );
};

export default ContractDetails;
