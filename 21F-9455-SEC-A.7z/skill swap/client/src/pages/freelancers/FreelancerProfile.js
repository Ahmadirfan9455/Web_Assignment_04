import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

const FreelancerProfile = () => {
  const { id } = useParams();
  const [loading, setLoading] = useState(true);
  const [freelancer, setFreelancer] = useState(null);
  const [showContactForm, setShowContactForm] = useState(false);
  const [message, setMessage] = useState('');

  // Simulate fetching freelancer details
  useEffect(() => {
    const timer = setTimeout(() => {
      // Mock freelancer data
      setFreelancer({
        id,
        name: 'Jane Smith',
        title: 'Full Stack Developer',
        bio: 'Experienced full stack developer with expertise in MERN stack. I specialize in building responsive web applications with modern technologies.',
        skills: ['React', 'Node.js', 'MongoDB', 'Express', 'JavaScript', 'TypeScript', 'Tailwind CSS'],
        hourlyRate: 45,
        rating: 4.9,
        reviewCount: 28,
        completedProjects: 32,
        location: 'New York, USA',
        languages: ['English (Native)', 'Spanish (Fluent)'],
        education: [
          {
            degree: 'Bachelor of Science in Computer Science',
            institution: 'University of Technology',
            year: '2018'
          }
        ],
        experience: [
          {
            title: 'Senior Developer',
            company: 'Tech Solutions Inc.',
            period: '2019 - Present',
            description: 'Developed and maintained web applications for various clients.'
          },
          {
            title: 'Junior Developer',
            company: 'Digital Innovations',
            period: '2018 - 2019',
            description: 'Worked on frontend development using React and Angular.'
          }
        ],
        portfolio: [
          {
            id: 'p1',
            title: 'E-commerce Platform',
            description: 'A full-featured e-commerce platform with payment integration.',
            image: 'https://via.placeholder.com/300'
          },
          {
            id: 'p2',
            title: 'Social Media Dashboard',
            description: 'Analytics dashboard for social media management.',
            image: 'https://via.placeholder.com/300'
          }
        ],
        reviews: [
          {
            id: 'r1',
            client: 'John Doe',
            rating: 5,
            comment: 'Excellent work! Delivered the project on time and exceeded expectations.',
            date: '2023-04-15'
          },
          {
            id: 'r2',
            client: 'Sarah Johnson',
            rating: 4.5,
            comment: 'Very professional and responsive. Would hire again.',
            date: '2023-03-22'
          }
        ]
      });
      setLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [id]);

  const handleSendMessage = (e) => {
    e.preventDefault();
    
    if (!message.trim()) {
      toast.error('Please enter a message');
      return;
    }
    
    // Simulate sending message
    toast.success('Message sent successfully!');
    setShowContactForm(false);
    setMessage('');
  };

  if (loading) {
    return <LoadingScreen />;
  }

  if (!freelancer) {
    return (
      <div className="container mx-auto px-4 py-8">
        <GlassCard className="p-8 text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Freelancer Not Found</h2>
          <p className="text-indigo-300 mb-6">The freelancer profile you're looking for doesn't exist or has been removed.</p>
          <Link to="/freelancers">
            <GlowButton variant="primary">Browse Freelancers</GlowButton>
          </Link>
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Link to="/freelancers" className="text-indigo-400 hover:text-indigo-300 mb-6 inline-block">
          &larr; Back to Freelancers
        </Link>
        
        {/* Profile Header */}
        <GlassCard className="p-6 mb-8">
          <div className="flex flex-col md:flex-row">
            <div className="w-24 h-24 md:w-32 md:h-32 rounded-full bg-indigo-900/50 flex items-center justify-center text-white text-3xl font-bold">
              {freelancer.name.charAt(0)}
            </div>
            <div className="mt-4 md:mt-0 md:ml-6 flex-1">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                <div>
                  <h1 className="text-2xl md:text-3xl font-bold text-white">{freelancer.name}</h1>
                  <p className="text-indigo-300 text-lg">{freelancer.title}</p>
                  <div className="flex items-center mt-2">
                    <span className="text-yellow-400">★</span>
                    <span className="text-white ml-1">{freelancer.rating}</span>
                    <span className="text-indigo-300 ml-2">({freelancer.reviewCount} reviews)</span>
                  </div>
                  <p className="text-indigo-300 mt-1">
                    <span className="font-medium">Location:</span> {freelancer.location}
                  </p>
                </div>
                <div className="mt-4 md:mt-0">
                  <p className="text-xl font-bold text-white">${freelancer.hourlyRate}/hr</p>
                  <p className="text-indigo-300">{freelancer.completedProjects} Projects Completed</p>
                  <GlowButton
                    variant="primary"
                    className="mt-3"
                    onClick={() => setShowContactForm(true)}
                  >
                    Contact Me
                  </GlowButton>
                </div>
              </div>
            </div>
          </div>
        </GlassCard>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            {/* About */}
            <GlassCard className="p-6 mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">About Me</h2>
              <p className="text-indigo-300">{freelancer.bio}</p>
            </GlassCard>
            
            {/* Skills */}
            <GlassCard className="p-6 mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">Skills</h2>
              <div className="flex flex-wrap gap-2">
                {freelancer.skills.map((skill) => (
                  <span key={skill} className="px-3 py-1 bg-indigo-900/50 text-indigo-300 rounded-full">
                    {skill}
                  </span>
                ))}
              </div>
            </GlassCard>
            
            {/* Portfolio */}
            <GlassCard className="p-6 mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">Portfolio</h2>
              {freelancer.portfolio.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {freelancer.portfolio.map((item) => (
                    <div key={item.id} className="border border-gray-700 rounded-lg overflow-hidden">
                      <img src={item.image} alt={item.title} className="w-full h-40 object-cover" />
                      <div className="p-4">
                        <h3 className="text-lg font-medium text-white">{item.title}</h3>
                        <p className="text-indigo-300 mt-1">{item.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-indigo-300">No portfolio items to display.</p>
              )}
            </GlassCard>
            
            {/* Reviews */}
            <GlassCard className="p-6">
              <h2 className="text-xl font-semibold text-white mb-4">Client Reviews</h2>
              {freelancer.reviews.length > 0 ? (
                <div className="space-y-6">
                  {freelancer.reviews.map((review) => (
                    <div key={review.id} className="border-b border-gray-700 pb-6 last:border-0 last:pb-0">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-lg font-medium text-white">{review.client}</h3>
                          <div className="flex items-center mt-1">
                            <div className="flex">
                              {[...Array(5)].map((_, i) => (
                                <span key={i} className={`text-${i < review.rating ? 'yellow' : 'gray'}-400`}>★</span>
                              ))}
                            </div>
                            <span className="text-indigo-300 ml-2">{new Date(review.date).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>
                      <p className="text-indigo-300 mt-3">{review.comment}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-indigo-300">No reviews yet.</p>
              )}
            </GlassCard>
          </div>
          
          <div>
            {/* Contact Form */}
            {showContactForm && (
              <GlassCard className="p-6 mb-8">
                <h2 className="text-xl font-semibold text-white mb-4">Contact {freelancer.name}</h2>
                <form onSubmit={handleSendMessage}>
                  <div className="mb-4">
                    <label className="block text-indigo-300 mb-2">Message</label>
                    <textarea
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="w-full px-4 py-2 rounded-md bg-gray-900/50 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder={`Hi ${freelancer.name}, I'm interested in working with you...`}
                      rows="6"
                      required
                    />
                  </div>
                  <div className="flex space-x-4">
                    <GlowButton type="submit" variant="primary">
                      Send Message
                    </GlowButton>
                    <GlowButton
                      type="button"
                      variant="secondary"
                      onClick={() => setShowContactForm(false)}
                    >
                      Cancel
                    </GlowButton>
                  </div>
                </form>
              </GlassCard>
            )}
            
            {/* Languages */}
            <GlassCard className="p-6 mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">Languages</h2>
              <ul className="space-y-2">
                {freelancer.languages.map((language, index) => (
                  <li key={index} className="text-indigo-300">{language}</li>
                ))}
              </ul>
            </GlassCard>
            
            {/* Education */}
            <GlassCard className="p-6 mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">Education</h2>
              {freelancer.education.length > 0 ? (
                <div className="space-y-4">
                  {freelancer.education.map((edu, index) => (
                    <div key={index}>
                      <h3 className="text-lg font-medium text-white">{edu.degree}</h3>
                      <p className="text-indigo-300">{edu.institution}</p>
                      <p className="text-indigo-300">{edu.year}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-indigo-300">No education information available.</p>
              )}
            </GlassCard>
            
            {/* Experience */}
            <GlassCard className="p-6">
              <h2 className="text-xl font-semibold text-white mb-4">Experience</h2>
              {freelancer.experience.length > 0 ? (
                <div className="space-y-6">
                  {freelancer.experience.map((exp, index) => (
                    <div key={index} className="border-b border-gray-700 pb-4 last:border-0 last:pb-0">
                      <h3 className="text-lg font-medium text-white">{exp.title}</h3>
                      <p className="text-indigo-300">{exp.company}</p>
                      <p className="text-indigo-300 text-sm">{exp.period}</p>
                      <p className="text-indigo-300 mt-2">{exp.description}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-indigo-300">No experience information available.</p>
              )}
            </GlassCard>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default FreelancerProfile;
