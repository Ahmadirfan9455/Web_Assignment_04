import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import GlassCard from '../../components/ui/GlassCard';
import LoadingScreen from '../../components/ui/LoadingScreen';

import api from '../../utils/api';

const FreelancerSearch = () => {
  const [loading, setLoading] = useState(true);
  const [freelancers, setFreelancers] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState({
    skill: 'all',
    rating: 'all',
    verified: 'all',
    minRate: '',
    maxRate: ''
  });

  useEffect(() => {
    const fetchFreelancers = async () => {
      setLoading(true);
      setError(null);
      try {
        const params = {};
        if (filters.skill && filters.skill !== 'all') params.skills = filters.skill;
        if (filters.rating && filters.rating !== 'all') params.minRating = filters.rating;
        if (filters.verified && filters.verified !== 'all') params.verified = filters.verified;
        if (filters.minRate) params.minRate = filters.minRate;
        if (filters.maxRate) params.maxRate = filters.maxRate;
        params.page = page;
        params.limit = 12;
        params.sort = 'rating';
        params.order = 'desc';
        const res = await api.get('/freelancers/search', { params });
        setFreelancers(res.data.freelancers);
        setTotal(res.data.total);
      } catch (err) {
        setError('Failed to load freelancers.');
      }
      setLoading(false);
    };
    fetchFreelancers();
    // eslint-disable-next-line
  }, [filters, page]);

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-bold text-white mb-6">Find Talented Freelancers</h1>
        
        {/* Filters */}
        <GlassCard className="p-6 mb-8">
          <h2 className="text-xl font-semibold text-white mb-4">Filters</h2>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div>
              <label className="block text-indigo-300 mb-2">Skill</label>
              <select
                value={filters.skill}
                onChange={(e) => setFilters({ ...filters, skill: e.target.value })}
                className="w-full px-4 py-2 rounded-md bg-gray-900/50 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="all">All Skills</option>
                <option value="web">Web Development</option>
                <option value="mobile">Mobile Development</option>
                <option value="design">Design</option>
                <option value="writing">Content Writing</option>
                <option value="marketing">Marketing</option>
              </select>
            </div>
            <div>
              <label className="block text-indigo-300 mb-2">Verified</label>
              <select
                value={filters.verified}
                onChange={(e) => setFilters({ ...filters, verified: e.target.value })}
                className="w-full px-4 py-2 rounded-md bg-gray-900/50 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="all">Any</option>
                <option value="true">Verified</option>
                <option value="false">Not Verified</option>
              </select>
            </div>
            <div>
              <label className="block text-indigo-300 mb-2">Rating</label>
              <select
                value={filters.rating}
                onChange={(e) => setFilters({ ...filters, rating: e.target.value })}
                className="w-full px-4 py-2 rounded-md bg-gray-900/50 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="all">Any Rating</option>
                <option value="4">4+ Stars</option>
                <option value="4.5">4.5+ Stars</option>
                <option value="5">5 Stars</option>
              </select>
            </div>
          </div>
        </GlassCard>
        
        {/* Freelancers List */}
        {error && (
          <GlassCard className="p-4 mb-4 bg-red-900/60">
            <p className="text-red-300">{error}</p>
          </GlassCard>
        )}
        {freelancers.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {freelancers.map((freelancer) => (
              <GlassCard key={freelancer._id || freelancer.id} className="p-6">
                <div className="flex items-start">
                  <div className="w-16 h-16 rounded-full bg-indigo-900/50 flex items-center justify-center text-white text-xl font-bold">
                    {freelancer.user?.name?.charAt(0) || '?'}
                  </div>
                  <div className="ml-4">
                    <h3 className="text-xl font-semibold text-white">
                      <Link to={`/freelancers/${freelancer._id || freelancer.id}`} className="hover:text-indigo-400">
                        {freelancer.user?.name || 'Unknown'}
                      </Link>
                    </h3>
                    <div className="flex items-center mt-1">
                      <span className="text-yellow-400">★</span>
                      <span className="text-white ml-1">{freelancer.rating}</span>
                    </div>
                    <div className="mt-3">
                      <p className="text-indigo-300">${freelancer.hourlyRate}/hr</p>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-3">
                      {freelancer.skills && freelancer.skills.slice(0, 3).map((skill) => (
                        <span key={skill} className="px-2 py-1 bg-indigo-900/50 text-indigo-300 rounded-full text-xs">
                          {skill}
                        </span>
                      ))}
                      {freelancer.skills && freelancer.skills.length > 3 && (
                        <span className="px-2 py-1 bg-indigo-900/50 text-indigo-300 rounded-full text-xs">
                          +{freelancer.skills.length - 3} more
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
        ) : (
          <GlassCard className="p-8 text-center">
            <h3 className="text-xl font-semibold text-white mb-2">No freelancers found</h3>
            <p className="text-indigo-300">
              No freelancers match your current filters. Try adjusting your filters or check back later.
            </p>
          </GlassCard>
        )}
        {/* Pagination Controls */}
        {total > 12 && (
          <div className="flex justify-center mt-8">
            <button
              className="px-4 py-2 mx-1 rounded bg-indigo-800 text-white disabled:opacity-50"
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
            >
              Prev
            </button>
            <span className="px-4 py-2 mx-1 text-indigo-200">Page {page}</span>
            <button
              className="px-4 py-2 mx-1 rounded bg-indigo-800 text-white disabled:opacity-50"
              onClick={() => setPage((p) => (p * 12 < total ? p + 1 : p))}
              disabled={page * 12 >= total}
            >
              Next
            </button>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default FreelancerSearch;
