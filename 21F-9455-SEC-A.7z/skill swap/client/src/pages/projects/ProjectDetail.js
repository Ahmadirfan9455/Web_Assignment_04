import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

const ProjectDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  
  // Project data
  const [project, setProject] = useState(null);
  const [bids, setBids] = useState([]);
  const [userBid, setUserBid] = useState(null);
  
  // Bid form
  const [bidForm, setBidForm] = useState({
    amount: '',
    deliveryTime: '',
    proposal: '',
  });
  
  // UI states
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showBidForm, setShowBidForm] = useState(false);
  
  // Real-time bid updates
  useEffect(() => {
    function handleBidEvent(e) {
      const { projectId, bid } = e.detail;
      if (projectId !== id) return;
      // For simplicity, refetch bids (or update state as needed)
      if (user?.role === 'client' && project?.client?._id === user._id) {
        // Refetch bids for client
        axios.get(`/api/projects/${id}/bids`).then(res => setBids(res.data));
      } else if (user?.role === 'freelancer') {
        // Refetch user's bid
        axios.get(`/api/projects/${id}/bids/user`).then(res => setUserBid(res.data)).catch(() => setUserBid(null));
      }
    }
    window.addEventListener('bid:new', handleBidEvent);
    window.addEventListener('bid:updated', handleBidEvent);
    window.addEventListener('bid:accepted', handleBidEvent);
    window.addEventListener('bid:rejected', handleBidEvent);
    window.addEventListener('bid:countered', handleBidEvent);
    return () => {
      window.removeEventListener('bid:new', handleBidEvent);
      window.removeEventListener('bid:updated', handleBidEvent);
      window.removeEventListener('bid:accepted', handleBidEvent);
      window.removeEventListener('bid:rejected', handleBidEvent);
      window.removeEventListener('bid:countered', handleBidEvent);
    };
  }, [id, user, project]);

  // Fetch project data
  useEffect(() => {
    const fetchProjectData = async () => {
      try {
        setIsLoading(true);
        
        // Fetch project details
        const projectResponse = await axios.get(`/api/projects/${id}`);
        setProject(projectResponse.data);
        
        // Fetch bids if user is the project owner
        if (user?.role === 'client' && projectResponse.data.client._id === user._id) {
          const bidsResponse = await axios.get(`/api/projects/${id}/bids`);
          setBids(bidsResponse.data);
        }
        
        // Check if user has already bid on this project
        if (user?.role === 'freelancer') {
          try {
            const userBidResponse = await axios.get(`/api/projects/${id}/bids/user`);
            setUserBid(userBidResponse.data);
          } catch (error) {
            // No bid found, that's okay
            setUserBid(null);
          }
        }
      } catch (error) {
        console.error('Error fetching project data:', error);
        toast.error('Failed to load project details. Please try again.');
        navigate('/projects');
      } finally {
        setIsLoading(false);
      }
    };
    
    if (id && user) {
      fetchProjectData();
    }
  }, [id, user, navigate]);
  
  // Handle bid form input change
  const handleBidChange = (e) => {
    const { name, value } = e.target;
    setBidForm(prev => ({
      ...prev,
      [name]: value,
    }));
  };
  
  // Submit bid
  const handleBidSubmit = async (e) => {
    e.preventDefault();
    
    // Validate form
    if (!bidForm.amount || !bidForm.deliveryTime || !bidForm.proposal) {
      toast.error('Please fill in all fields');
      return;
    }
    
    // Validate amount
    if (parseFloat(bidForm.amount) <= 0) {
      toast.error('Bid amount must be greater than zero');
      return;
    }
    
    // Validate delivery time
    if (parseInt(bidForm.deliveryTime) <= 0) {
      toast.error('Delivery time must be greater than zero days');
      return;
    }
    
    try {
      setIsSubmitting(true);
      
      // Submit bid
      await axios.post(`/api/projects/${id}/bids`, bidForm);
      
      toast.success('Your bid has been submitted successfully!');
      
      // Refresh user bid
      const userBidResponse = await axios.get(`/api/projects/${id}/bids/user`);
      setUserBid(userBidResponse.data);
      
      // Hide bid form
      setShowBidForm(false);
    } catch (error) {
      console.error('Error submitting bid:', error);
      toast.error(error.response?.data?.message || 'Failed to submit bid. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Accept bid (for project owner)
  const handleAcceptBid = async (bidId) => {
    try {
      await axios.put(`/api/projects/${id}/bids/${bidId}/accept`);
      
      toast.success('Bid accepted! A contract will be created shortly.');
      
      // Redirect to contracts page
      setTimeout(() => {
        navigate('/contracts');
      }, 2000);
    } catch (error) {
      console.error('Error accepting bid:', error);
      toast.error('Failed to accept bid. Please try again.');
    }
  };
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
      },
    },
  };
  
  // Show loading screen while fetching data
  if (isLoading) {
    return <LoadingScreen />;
  }
  
  // Check if project exists
  if (!project) {
    return (
      <div className="py-8 px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-3xl font-bold text-white mb-4">Project Not Found</h1>
        <p className="text-indigo-200 mb-6">The project you're looking for doesn't exist or has been removed.</p>
        <GlowButton
          as={Link}
          to="/projects"
          variant="primary"
          className="px-4 py-2"
        >
          Browse Projects
        </GlowButton>
      </div>
    );
  }
  
  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8">
      <motion.div
        className="max-w-7xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Back Button */}
        <motion.div variants={itemVariants} className="mb-6">
          <Link
            to="/projects"
            className="inline-flex items-center text-indigo-400 hover:text-indigo-300 transition-colors"
          >
            <svg
              className="w-5 h-5 mr-2"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M10 19l-7-7m0 0l7-7m-7 7h18"
              />
            </svg>
            Back to Projects
          </Link>
        </motion.div>
        
        {/* Project Header */}
        <motion.div variants={itemVariants} className="mb-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold text-white">{project.title}</h1>
              <p className="text-indigo-200 mt-1">
                Posted by {project.client.name} on {new Date(project.createdAt).toLocaleDateString()}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <span className={`px-3 py-1 rounded-full text-sm ${
                project.status === 'open'
                  ? 'bg-green-500/20 text-green-400'
                  : project.status === 'in-progress'
                  ? 'bg-blue-500/20 text-blue-400'
                  : 'bg-yellow-500/20 text-yellow-400'
              }`}>
                {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
              </span>
              <span className="px-3 py-1 bg-indigo-900/50 rounded-full text-indigo-300 text-sm">
                Budget: ${project.budget.toFixed(2)}
              </span>
            </div>
          </div>
        </motion.div>
        
        {/* Project Details */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <motion.div variants={itemVariants} className="lg:col-span-2">
            <GlassCard className="p-6 mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">Project Description</h2>
              <div className="text-indigo-200 space-y-4">
                <p>{project.description}</p>
              </div>
              
              {project.attachments && project.attachments.length > 0 && (
  <div className="mt-6">
    <h3 className="text-lg font-medium text-white mb-2">Attachments</h3>
    <ul className="space-y-2">
      {project.attachments.map((attachment, index) => {
        // Support both {url, name} and string
        let url = attachment.url || attachment;
        let name = attachment.name || (typeof attachment === 'string' ? attachment.split('/').pop() : 'File');
        return (
          <li key={index}>
            <a
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center text-indigo-400 hover:text-indigo-300 transition-colors"
            >
              <svg
                className="w-4 h-4 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"
                />
              </svg>
              {name}
            </a>
          </li>
        );
      })}
    </ul>
  </div>
)}
            </GlassCard>
            
            {/* Required Skills */}
            <GlassCard className="p-6 mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">Required Skills</h2>
              <div className="flex flex-wrap gap-2">
                {project.skills.map((skill, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-indigo-900/50 rounded-full text-indigo-300 text-sm"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </GlassCard>
            
            {/* Bid Section (for freelancers) */}
            {user?.role === 'freelancer' && project.status === 'open' && (
              <GlassCard className="p-6">
                <h2 className="text-xl font-semibold text-white mb-4">Submit a Proposal</h2>
                
                {userBid ? (
                  <div>
                    <div className="bg-indigo-900/30 p-4 rounded-md mb-4">
                      <h3 className="text-lg font-medium text-white mb-2">Your Bid</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <p className="text-sm text-indigo-300">Amount</p>
                          <p className="text-lg font-medium text-white">${userBid.amount.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-sm text-indigo-300">Delivery Time</p>
                          <p className="text-lg font-medium text-white">{userBid.deliveryTime} days</p>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm text-indigo-300">Your Proposal</p>
                        <p className="text-white">{userBid.proposal}</p>
                      </div>
                      <div className="mt-4 flex items-center">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          userBid.status === 'pending'
                            ? 'bg-yellow-500/20 text-yellow-400'
                            : userBid.status === 'accepted'
                            ? 'bg-green-500/20 text-green-400'
                            : 'bg-red-500/20 text-red-400'
                        }`}>
                          {userBid.status.charAt(0).toUpperCase() + userBid.status.slice(1)}
                        </span>
                        {userBid.status === 'pending' && (
                          <button
                            className="ml-4 text-indigo-400 hover:text-indigo-300 transition-colors text-sm"
                            onClick={() => setShowBidForm(true)}
                          >
                            Edit Bid
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div>
                    {showBidForm ? (
                      <form onSubmit={handleBidSubmit}>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                          <div>
                            <label htmlFor="amount" className="block text-sm font-medium text-indigo-300 mb-1">
                              Bid Amount ($)
                            </label>
                            <input
                              type="number"
                              id="amount"
                              name="amount"
                              value={bidForm.amount}
                              onChange={handleBidChange}
                              className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                              placeholder="Enter your bid amount"
                              min="1"
                              step="0.01"
                              required
                            />
                          </div>
                          <div>
                            <label htmlFor="deliveryTime" className="block text-sm font-medium text-indigo-300 mb-1">
                              Delivery Time (days)
                            </label>
                            <input
                              type="number"
                              id="deliveryTime"
                              name="deliveryTime"
                              value={bidForm.deliveryTime}
                              onChange={handleBidChange}
                              className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                              placeholder="Enter delivery time in days"
                              min="1"
                              required
                            />
                          </div>
                        </div>
                        <div className="mb-4">
                          <label htmlFor="proposal" className="block text-sm font-medium text-indigo-300 mb-1">
                            Your Proposal
                          </label>
                          <textarea
                            id="proposal"
                            name="proposal"
                            value={bidForm.proposal}
                            onChange={handleBidChange}
                            rows="5"
                            className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                            placeholder="Describe why you're the best fit for this project..."
                            required
                          ></textarea>
                        </div>
                        <div className="flex justify-end space-x-3">
                          <button
                            type="button"
                            onClick={() => setShowBidForm(false)}
                            className="px-4 py-2 border border-gray-700 rounded-md text-indigo-300 hover:bg-gray-800 transition-colors"
                          >
                            Cancel
                          </button>
                          <GlowButton
                            type="submit"
                            variant="primary"
                            className="px-4 py-2"
                            disabled={isSubmitting}
                          >
                            {isSubmitting ? 'Submitting...' : 'Submit Bid'}
                          </GlowButton>
                        </div>
                      </form>
                    ) : (
                      <div className="text-center">
                        <p className="text-indigo-200 mb-4">
                          Ready to work on this project? Submit your proposal now!
                        </p>
                        <GlowButton
                          onClick={() => setShowBidForm(true)}
                          variant="primary"
                          className="px-4 py-2"
                        >
                          Place a Bid
                        </GlowButton>
                      </div>
                    )}
                  </div>
                )}
              </GlassCard>
            )}
            
            {/* Bids Section (for project owner) */}
            {user?.role === 'client' && project.client._id === user._id && (
              <GlassCard className="p-6">
                <h2 className="text-xl font-semibold text-white mb-4">
                  Bids ({bids.length})
                </h2>
                
                {bids.length > 0 ? (
                  <div className="space-y-6">
                    {bids.map((bid) => (
                      <div key={bid._id} className="border border-gray-700 rounded-md p-4">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="text-lg font-medium text-white">{bid.freelancer.name}</h3>
                            <p className="text-indigo-300 text-sm">
                              Submitted on {new Date(bid.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                          <span className={`px-2 py-1 text-xs rounded-full ${
                            bid.status === 'pending'
                              ? 'bg-yellow-500/20 text-yellow-400'
                              : bid.status === 'accepted'
                              ? 'bg-green-500/20 text-green-400'
                              : 'bg-red-500/20 text-red-400'
                          }`}>
                            {bid.status.charAt(0).toUpperCase() + bid.status.slice(1)}
                          </span>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                          <div>
                            <p className="text-sm text-indigo-300">Bid Amount</p>
                            <p className="text-lg font-medium text-white">${bid.amount.toFixed(2)}</p>
                          </div>
                          <div>
                            <p className="text-sm text-indigo-300">Delivery Time</p>
                            <p className="text-lg font-medium text-white">{bid.deliveryTime} days</p>
                          </div>
                        </div>
                        <div className="mb-4">
                          <p className="text-sm text-indigo-300">Proposal</p>
                          <p className="text-white">{bid.proposal}</p>
                        </div>
                        {bid.status === 'pending' && project.status === 'open' && (
                          <div className="flex justify-end">
                            <GlowButton
                              onClick={() => handleAcceptBid(bid._id)}
                              variant="success"
                              className="px-4 py-2"
                            >
                              Accept Bid
                            </GlowButton>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-indigo-200 text-center">
                    No bids have been submitted for this project yet.
                  </p>
                )}
              </GlassCard>
            )}
          </motion.div>
          
          {/* Sidebar */}
          <motion.div variants={itemVariants} className="lg:col-span-1">
            {/* Project Details */}
            <GlassCard className="p-6 mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">Project Details</h2>
              <ul className="space-y-4">
                <li className="flex justify-between">
                  <span className="text-indigo-300">Category</span>
                  <span className="text-white">{project.category}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-indigo-300">Budget</span>
                  <span className="text-white">${project.budget.toFixed(2)}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-indigo-300">Duration</span>
                  <span className="text-white">{project.duration} days</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-indigo-300">Bids</span>
                  <span className="text-white">{project.bids?.length || 0}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-indigo-300">Posted</span>
                  <span className="text-white">{new Date(project.createdAt).toLocaleDateString()}</span>
                </li>
              </ul>
            </GlassCard>
            
            {/* Client Info */}
            <GlassCard className="p-6 mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">About the Client</h2>
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-indigo-900 rounded-full flex items-center justify-center mr-4">
                  <span className="text-white text-lg font-medium">
                    {project.client.name.charAt(0)}
                  </span>
                </div>
                <div>
                  <h3 className="text-lg font-medium text-white">{project.client.name}</h3>
                  <p className="text-indigo-300 text-sm">Member since {new Date(project.client.createdAt).toLocaleDateString()}</p>
                </div>
              </div>
              <ul className="space-y-2">
                <li className="flex justify-between">
                  <span className="text-indigo-300">Projects Posted</span>
                  <span className="text-white">{project.client.projectsCount || 0}</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-indigo-300">Hire Rate</span>
                  <span className="text-white">{project.client.hireRate || 0}%</span>
                </li>
              </ul>
              {user?.role === 'freelancer' && (
                <div className="mt-4">
                  <Link
                    to={`/messages/new?recipient=${project.client._id}`}
                    className="text-indigo-400 hover:text-indigo-300 transition-colors inline-flex items-center"
                  >
                    <svg
                      className="w-4 h-4 mr-2"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                      />
                    </svg>
                    Contact Client
                  </Link>
                </div>
              )}
            </GlassCard>
            
            {/* Similar Projects */}
            <GlassCard className="p-6">
              <h2 className="text-xl font-semibold text-white mb-4">Similar Projects</h2>
              <div className="space-y-4">
                {project.similarProjects && project.similarProjects.length > 0 ? (
                  project.similarProjects.map((similarProject) => (
                    <div key={similarProject._id} className="border-b border-gray-700 pb-4 last:border-0 last:pb-0">
                      <h3 className="text-white font-medium mb-1">
                        <Link
                          to={`/projects/${similarProject._id}`}
                          className="hover:text-indigo-400 transition-colors"
                        >
                          {similarProject.title}
                        </Link>
                      </h3>
                      <p className="text-indigo-300 text-sm mb-2">${similarProject.budget.toFixed(2)}</p>
                      <p className="text-indigo-200 text-sm line-clamp-2">{similarProject.description}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-indigo-200">No similar projects found.</p>
                )}
              </div>
            </GlassCard>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
};

export default ProjectDetail;
