import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

const Projects = () => {
  const [loading, setLoading] = useState(true);
  const [projects, setProjects] = useState([]);
  const [filters, setFilters] = useState({
    category: 'all',
    budget: 'all',
    status: 'active'
  });

  // Simulate fetching projects
  useEffect(() => {
    const timer = setTimeout(() => {
      // Mock projects data
      setProjects([]);
      setLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [filters]);

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">Browse Projects</h1>
            <p className="text-indigo-300 mt-2">Find your next opportunity</p>
          </div>
          
          <Link to="/projects/create">
            <GlowButton variant="primary" className="mt-4 md:mt-0">
              Post a Project
            </GlowButton>
          </Link>
        </div>
        
        {/* Filters */}
        <GlassCard className="p-6 mb-8">
          <h2 className="text-xl font-semibold text-white mb-4">Filters</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-indigo-300 mb-2">Category</label>
              <select
                value={filters.category}
                onChange={(e) => setFilters({ ...filters, category: e.target.value })}
                className="w-full px-4 py-2 rounded-md bg-gray-900/50 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="all">All Categories</option>
                <option value="web">Web Development</option>
                <option value="mobile">Mobile Development</option>
                <option value="design">Design</option>
                <option value="writing">Content Writing</option>
                <option value="marketing">Marketing</option>
              </select>
            </div>
            
            <div>
              <label className="block text-indigo-300 mb-2">Budget</label>
              <select
                value={filters.budget}
                onChange={(e) => setFilters({ ...filters, budget: e.target.value })}
                className="w-full px-4 py-2 rounded-md bg-gray-900/50 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="all">All Budgets</option>
                <option value="low">$0 - $100</option>
                <option value="medium">$100 - $500</option>
                <option value="high">$500 - $1000</option>
                <option value="very-high">$1000+</option>
              </select>
            </div>
            
            <div>
              <label className="block text-indigo-300 mb-2">Status</label>
              <select
                value={filters.status}
                onChange={(e) => setFilters({ ...filters, status: e.target.value })}
                className="w-full px-4 py-2 rounded-md bg-gray-900/50 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="active">Active</option>
                <option value="completed">Completed</option>
                <option value="all">All</option>
              </select>
            </div>
          </div>
        </GlassCard>
        
        {/* Projects List */}
        {projects.length > 0 ? (
          <div className="grid grid-cols-1 gap-6">
            {projects.map((project) => (
              <GlassCard key={project.id} className="p-6">
                <div className="flex flex-col md:flex-row justify-between">
                  <div>
                    <h3 className="text-xl font-semibold text-white">
                      <Link to={`/projects/${project.id}`} className="hover:text-indigo-400">
                        {project.title}
                      </Link>
                    </h3>
                    <p className="text-indigo-300 mt-2">{project.description}</p>
                    <div className="flex flex-wrap gap-2 mt-4">
                      {project.skills.map((skill) => (
                        <span key={skill} className="px-3 py-1 bg-indigo-900/50 text-indigo-300 rounded-full text-sm">
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="mt-4 md:mt-0 md:ml-6 flex flex-col items-end">
                    <div className="text-xl font-bold text-white">{project.budget}</div>
                    <div className="text-indigo-300 mt-1">{project.type}</div>
                    <Link to={`/projects/${project.id}`} className="mt-4">
                      <GlowButton variant="secondary" size="sm">
                        View Details
                      </GlowButton>
                    </Link>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
        ) : (
          <GlassCard className="p-8 text-center">
            <h3 className="text-xl font-semibold text-white mb-2">No projects found</h3>
            <p className="text-indigo-300">
              No projects match your current filters. Try adjusting your filters or check back later.
            </p>
          </GlassCard>
        )}
      </motion.div>
    </div>
  );
};

export default Projects;
