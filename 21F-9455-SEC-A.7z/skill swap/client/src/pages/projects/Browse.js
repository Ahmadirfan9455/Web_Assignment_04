import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';
import SearchSuggestions from '../../components/search/SearchSuggestions';

const BrowseProjects = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  
  // Projects state
  const [projects, setProjects] = useState([]);
  const [filteredProjects, setFilteredProjects] = useState([]);
  
  // Filter states
  const [filters, setFilters] = useState({
    search: '',
    category: '',
    minBudget: '',
    maxBudget: '',
    skills: [],
  });
  
  // Loading state
  const [isLoading, setIsLoading] = useState(true);
  
  // Categories and skills for filters
  const [categories, setCategories] = useState([]);
  const [availableSkills, setAvailableSkills] = useState([]);
  
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [projectsPerPage] = useState(9);
  
  // Search state
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  
  // Fetch projects
  useEffect(() => {
    const fetchProjects = async () => {
      try {
        setIsLoading(true);
        
        // Fetch projects
        const projectsResponse = await axios.get('/api/projects');
        setProjects(projectsResponse.data);
        setFilteredProjects(projectsResponse.data);
        
        // Extract unique categories and skills
        const uniqueCategories = [...new Set(projectsResponse.data.map(project => project.category))];
        setCategories(uniqueCategories);
        
        const skillsSet = new Set();
        projectsResponse.data.forEach(project => {
          project.skills.forEach(skill => skillsSet.add(skill));
        });
        setAvailableSkills(Array.from(skillsSet));
      } catch (error) {
        console.error('Error fetching projects:', error);
        toast.error('Failed to load projects. Please try again.');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchProjects();
  }, []);
  
  // Handle project selection from search suggestions
  const handleSelectProject = (project) => {
    navigate(`/projects/${project._id}`);
  };

  // Apply filters
  useEffect(() => {
    let result = [...projects];
    
    // Search filter
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      result = result.filter(
        project =>
          project.title.toLowerCase().includes(searchLower) ||
          project.description.toLowerCase().includes(searchLower)
      );
    }
    
    // Category filter
    if (filters.category) {
      result = result.filter(project => project.category === filters.category);
    }
    
    // Budget filters
    if (filters.minBudget) {
      result = result.filter(project => project.budget >= parseFloat(filters.minBudget));
    }
    
    if (filters.maxBudget) {
      result = result.filter(project => project.budget <= parseFloat(filters.maxBudget));
    }
    
    // Skills filter
    if (filters.skills.length > 0) {
      result = result.filter(project =>
        filters.skills.some(skill => project.skills.includes(skill))
      );
    }
    
    setFilteredProjects(result);
    setCurrentPage(1); // Reset to first page when filters change
  }, [filters, projects]);
  
  // Handle filter changes
  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value,
    }));
  };
  
  // Handle skill selection
  const handleSkillToggle = (skill) => {
    setFilters(prev => {
      const skills = prev.skills.includes(skill)
        ? prev.skills.filter(s => s !== skill)
        : [...prev.skills, skill];
      
      return {
        ...prev,
        skills,
      };
    });
  };
  
  // Clear all filters
  const clearFilters = () => {
    setFilters({
      search: '',
      category: '',
      minBudget: '',
      maxBudget: '',
      skills: [],
    });
  };
  
  // Pagination logic
  const indexOfLastProject = currentPage * projectsPerPage;
  const indexOfFirstProject = indexOfLastProject - projectsPerPage;
  const currentProjects = filteredProjects.slice(indexOfFirstProject, indexOfLastProject);
  const totalPages = Math.ceil(filteredProjects.length / projectsPerPage);
  
  // Change page
  const paginate = (pageNumber) => setCurrentPage(pageNumber);
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
      },
    },
  };
  
  // Show loading screen while fetching data
  if (isLoading) {
    return <LoadingScreen />;
  }
  
  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8">
      <motion.div
        className="max-w-7xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Header Section */}
        <motion.div variants={itemVariants} className="mb-8">
          <h1 className="text-3xl font-bold text-white">
            Browse Projects
          </h1>
          <p className="text-indigo-200 mt-2">
            Find the perfect project that matches your skills and interests.
          </p>
        </motion.div>
        
        {/* Search Section */}
        <motion.div variants={itemVariants} className="mb-8">
          <GlassCard className="p-6">
            <div className="mb-4">
              <div className="flex justify-between items-center mb-2">
                <label className="block text-sm font-medium text-indigo-300">
                  Search Projects
                </label>
                <button 
                  onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
                  className="text-sm text-indigo-400 hover:text-indigo-300 transition-colors flex items-center gap-1"
                >
                  {showAdvancedFilters ? (
                    <>
                      <span>Hide Filters</span>
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clipRule="evenodd" />
                      </svg>
                    </>
                  ) : (
                    <>
                      <span>Advanced Filters</span>
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                      </svg>
                    </>
                  )}
                </button>
              </div>
              <SearchSuggestions 
                onSelect={handleSelectProject}
              />
            </div>
            
            {showAdvancedFilters && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
                {/* Category */}
                <div>
                  <label htmlFor="category" className="block text-sm font-medium text-indigo-300 mb-1">
                    Category
                  </label>
                  <select
                    id="category"
                    name="category"
                    value={filters.category}
                    onChange={handleFilterChange}
                    className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  >
                    <option value="">All Categories</option>
                    {categories.map((category, index) => (
                      <option key={index} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>
              
                {/* Min Budget */}
                <div>
                  <label htmlFor="minBudget" className="block text-sm font-medium text-indigo-300 mb-1">
                    Min Budget
                  </label>
                  <input
                    type="number"
                    id="minBudget"
                    name="minBudget"
                    value={filters.minBudget}
                    onChange={handleFilterChange}
                    className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="Min $"
                    min="0"
                  />
                </div>
                
                {/* Max Budget */}
                <div>
                  <label htmlFor="maxBudget" className="block text-sm font-medium text-indigo-300 mb-1">
                    Max Budget
                  </label>
                  <input
                    type="number"
                    id="maxBudget"
                    name="maxBudget"
                    value={filters.maxBudget}
                    onChange={handleFilterChange}
                    className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="Max $"
                    min="0"
                  />
                </div>
              </div>
            )}
            
            {showAdvancedFilters && (
              /* Skills Filter */
              <div className="mb-4">
                <label className="block text-sm font-medium text-indigo-300 mb-2">
                  Skills
                </label>
                <div className="flex flex-wrap gap-2">
                  {availableSkills.slice(0, 15).map((skill, index) => (
                    <button
                      key={index}
                      onClick={() => handleSkillToggle(skill)}
                      className={`px-3 py-1 text-sm rounded-full transition-colors ${
                        filters.skills.includes(skill)
                          ? 'bg-indigo-600 text-white'
                          : 'bg-gray-800 text-indigo-300 hover:bg-gray-700'
                      }`}
                    >
                      {skill}
                    </button>
                  ))}
                  {availableSkills.length > 15 && (
                    <span className="px-3 py-1 text-sm rounded-full bg-gray-800 text-indigo-300">
                      +{availableSkills.length - 15} more
                    </span>
                  )}
                </div>
              </div>
            )}
            
            {/* Filter Actions */}
            <div className="flex justify-between items-center">
              <div className="text-indigo-300">
                <span className="font-medium">{filteredProjects.length}</span> projects found
              </div>
              <button
                onClick={clearFilters}
                className="text-indigo-400 hover:text-indigo-300 transition-colors"
              >
                Clear Filters
              </button>
            </div>
          </GlassCard>
        </motion.div>
        
        {/* Projects Grid */}
        <motion.div variants={itemVariants} className="mb-8">
          {currentProjects.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {currentProjects.map((project) => (
                <GlassCard key={project._id} className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-lg font-medium text-white">{project.title}</h3>
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      project.status === 'open'
                        ? 'bg-green-500/20 text-green-400'
                        : project.status === 'in-progress'
                        ? 'bg-blue-500/20 text-blue-400'
                        : 'bg-yellow-500/20 text-yellow-400'
                    }`}>
                      {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
                    </span>
                  </div>
                  <p className="text-indigo-200 mb-4 line-clamp-3">{project.description}</p>
                  <div className="flex justify-between items-center mb-4">
                    <div className="text-indigo-300">
                      <span className="font-medium">${project.budget.toFixed(2)}</span>
                    </div>
                    <div className="text-indigo-300 text-sm">
                      {project.bids?.length || 0} bids
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.skills.slice(0, 3).map((skill, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 text-xs rounded-full bg-indigo-900/50 text-indigo-300"
                      >
                        {skill}
                      </span>
                    ))}
                    {project.skills.length > 3 && (
                      <span className="px-2 py-1 text-xs rounded-full bg-indigo-900/50 text-indigo-300">
                        +{project.skills.length - 3} more
                      </span>
                    )}
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="text-sm text-indigo-300">
                      Posted: {new Date(project.createdAt).toLocaleDateString()}
                    </div>
                    <Link
                      to={`/projects/${project._id}`}
                      className="text-indigo-400 hover:text-indigo-300 transition-colors"
                    >
                      View Details
                    </Link>
                  </div>
                </GlassCard>
              ))}
            </div>
          ) : (
            <GlassCard className="p-6 text-center">
              <p className="text-indigo-200 mb-4">No projects found matching your filters.</p>
              <GlowButton
                onClick={clearFilters}
                variant="primary"
                className="px-4 py-2"
              >
                Clear Filters
              </GlowButton>
            </GlassCard>
          )}
        </motion.div>
        
        {/* Pagination */}
        {totalPages > 1 && (
          <motion.div variants={itemVariants} className="flex justify-center">
            <nav className="flex items-center space-x-2">
              <button
                onClick={() => paginate(currentPage - 1)}
                disabled={currentPage === 1}
                className={`px-3 py-1 rounded-md ${
                  currentPage === 1
                    ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                    : 'bg-gray-800 text-indigo-300 hover:bg-gray-700'
                }`}
              >
                Previous
              </button>
              
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((number) => (
                <button
                  key={number}
                  onClick={() => paginate(number)}
                  className={`px-3 py-1 rounded-md ${
                    currentPage === number
                      ? 'bg-indigo-600 text-white'
                      : 'bg-gray-800 text-indigo-300 hover:bg-gray-700'
                  }`}
                >
                  {number}
                </button>
              ))}
              
              <button
                onClick={() => paginate(currentPage + 1)}
                disabled={currentPage === totalPages}
                className={`px-3 py-1 rounded-md ${
                  currentPage === totalPages
                    ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                    : 'bg-gray-800 text-indigo-300 hover:bg-gray-700'
                }`}
              >
                Next
              </button>
            </nav>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};

export default BrowseProjects;
