import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../../hooks/useAuth';
import GlassCard from '../../../components/ui/GlassCard';
import GlowButton from '../../../components/ui/GlowButton';
import LoadingScreen from '../../../components/ui/LoadingScreen';
import MilestoneTracker from '../../../components/projects/MilestoneTracker';

const ProjectTimeline = () => {
  const { projectId } = useParams();
  const { user } = useAuth();
  
  // State
  const [project, setProject] = useState(null);
  const [milestones, setMilestones] = useState([]);
  const [contract, setContract] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showMilestoneForm, setShowMilestoneForm] = useState(false);
  const [milestoneFormData, setMilestoneFormData] = useState({
    title: '',
    description: '',
    amount: '',
    dueDate: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Check if user is client or freelancer
  const isClient = user && user.role === 'client';
  const isFreelancer = user && user.role === 'freelancer';
  
  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'Not set';
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  // Calculate remaining days
  const calculateRemainingDays = (endDate) => {
    if (!endDate) return 'No deadline';
    
    const end = new Date(endDate);
    const today = new Date();
    const diffTime = end - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) {
      return 'Overdue';
    } else if (diffDays === 0) {
      return 'Due today';
    } else {
      return `${diffDays} days remaining`;
    }
  };
  
  // Calculate project progress
  const calculateProgress = () => {
    if (!milestones || milestones.length === 0) return 0;
    
    const completedMilestones = milestones.filter(
      milestone => milestone.status === 'approved'
    ).length;
    
    return Math.round((completedMilestones / milestones.length) * 100);
  };
  
  // Fetch project data
  useEffect(() => {
    const fetchProjectData = async () => {
      try {
        setLoading(true);
        
        // Fetch project
        const { data: projectData } = await axios.get(`/api/projects/${projectId}`);
        setProject(projectData);
        
        // Fetch milestones
        const { data: milestonesData } = await axios.get(`/api/projects/${projectId}/milestones`);
        setMilestones(milestonesData);
        
        // Fetch contract if exists
        try {
          const { data: contractData } = await axios.get(`/api/contracts/project/${projectId}`);
          setContract(contractData);
        } catch (error) {
          // Contract might not exist yet, which is fine
          console.log('No contract found for this project');
        }
        
        setLoading(false);
      } catch (error) {
        console.error('Error fetching project data:', error);
        toast.error('Failed to load project data');
        setLoading(false);
      }
    };
    
    fetchProjectData();
  }, [projectId]);
  
  // Handle milestone form input change
  const handleMilestoneInputChange = (e) => {
    const { name, value } = e.target;
    setMilestoneFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Handle milestone form submission
  const handleMilestoneSubmit = async (e) => {
    e.preventDefault();
    
    // Validate form
    if (!milestoneFormData.title.trim()) {
      toast.error('Please provide a milestone title');
      return;
    }
    
    if (!milestoneFormData.description.trim()) {
      toast.error('Please provide a milestone description');
      return;
    }
    
    if (!milestoneFormData.amount || isNaN(milestoneFormData.amount) || parseFloat(milestoneFormData.amount) <= 0) {
      toast.error('Please provide a valid amount');
      return;
    }
    
    if (!milestoneFormData.dueDate) {
      toast.error('Please provide a due date');
      return;
    }
    
    try {
      setIsSubmitting(true);
      
      // Create milestone
      await axios.post(`/api/projects/${projectId}/milestones`, {
        title: milestoneFormData.title,
        description: milestoneFormData.description,
        amount: parseFloat(milestoneFormData.amount),
        dueDate: milestoneFormData.dueDate
      });
      
      toast.success('Milestone created successfully!');
      
      // Reset form
      setMilestoneFormData({
        title: '',
        description: '',
        amount: '',
        dueDate: ''
      });
      
      setShowMilestoneForm(false);
      
      // Refresh milestones
      const { data: milestonesData } = await axios.get(`/api/projects/${projectId}/milestones`);
      setMilestones(milestonesData);
    } catch (error) {
      console.error('Error creating milestone:', error);
      toast.error(error.response?.data?.message || 'Failed to create milestone. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Handle milestone update
  const handleMilestoneUpdate = async () => {
    try {
      // Refresh milestones
      const { data: milestonesData } = await axios.get(`/api/projects/${projectId}/milestones`);
      setMilestones(milestonesData);
      
      // Refresh project
      const { data: projectData } = await axios.get(`/api/projects/${projectId}`);
      setProject(projectData);
    } catch (error) {
      console.error('Error refreshing data:', error);
    }
  };
  
  // Loading state
  if (loading) {
    return <LoadingScreen />;
  }
  
  // Project not found state
  if (!project) {
    return (
      <div className="container mx-auto px-4 py-8">
        <GlassCard className="p-6 text-center">
          <h2 className="text-xl text-white mb-4">Project not found</h2>
          <Link to="/projects">
            <GlowButton variant="primary">Browse Projects</GlowButton>
          </Link>
        </GlassCard>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {/* Project Header */}
        <GlassCard className="p-6 mb-8">
          <div className="flex flex-col md:flex-row justify-between">
            <div>
              <h1 className="text-2xl font-bold text-white">{project.title}</h1>
              
              <div className="flex flex-wrap gap-2 mt-2">
                {project.skills && project.skills.map((skill, index) => (
                  <span 
                    key={index}
                    className="px-2 py-1 bg-indigo-900/50 rounded-full text-xs text-indigo-300"
                  >
                    {skill}
                  </span>
                ))}
              </div>
              
              <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <p className="text-indigo-300 text-sm">Budget</p>
                  <p className="text-white font-medium">${project.budget.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-indigo-300 text-sm">Deadline</p>
                  <p className="text-white font-medium">{formatDate(project.deadline)}</p>
                </div>
                <div>
                  <p className="text-indigo-300 text-sm">Status</p>
                  <p className="text-white font-medium capitalize">{project.status}</p>
                </div>
              </div>
            </div>
            
            <div className="mt-4 md:mt-0 flex flex-col items-end">
              <div className="flex items-center mb-2">
                <div className="w-2 h-2 rounded-full bg-green-400 mr-2"></div>
                <span className="text-indigo-300 text-sm">
                  {calculateRemainingDays(project.deadline)}
                </span>
              </div>
              
              <div className="flex flex-col items-end">
                <span className="text-indigo-300 text-sm">Progress</span>
                <div className="w-32 bg-gray-700 rounded-full h-2.5 mt-1">
                  <div 
                    className="bg-indigo-600 h-2.5 rounded-full" 
                    style={{ width: `${calculateProgress()}%` }}
                  ></div>
                </div>
                <span className="text-indigo-300 text-xs mt-1">
                  {calculateProgress()}% Complete
                </span>
              </div>
              
              <div className="mt-4">
                <Link to={`/projects/${projectId}`}>
                  <GlowButton variant="secondary">
                    Project Details
                  </GlowButton>
                </Link>
              </div>
            </div>
          </div>
        </GlassCard>
        
        {/* Contract Details */}
        {contract && (
          <GlassCard className="p-6 mb-8">
            <h2 className="text-xl font-semibold text-white mb-4">Contract Details</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-indigo-300 text-sm mb-2">Client</h3>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-indigo-700 rounded-full flex items-center justify-center mr-3">
                    <span className="text-white font-medium">
                      {contract.client.name.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <p className="text-white font-medium">{contract.client.name}</p>
                    <p className="text-indigo-300 text-sm">{contract.client.email}</p>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-indigo-300 text-sm mb-2">Freelancer</h3>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-indigo-700 rounded-full flex items-center justify-center mr-3">
                    <span className="text-white font-medium">
                      {contract.freelancer.name.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <p className="text-white font-medium">{contract.freelancer.name}</p>
                    <p className="text-indigo-300 text-sm">{contract.freelancer.email}</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <p className="text-indigo-300 text-sm">Contract Amount</p>
                <p className="text-white font-medium">${contract.amount.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-indigo-300 text-sm">Start Date</p>
                <p className="text-white font-medium">{formatDate(contract.startDate)}</p>
              </div>
              <div>
                <p className="text-indigo-300 text-sm">End Date</p>
                <p className="text-white font-medium">{formatDate(contract.endDate)}</p>
              </div>
            </div>
            
            <div className="mt-6">
              <h3 className="text-indigo-300 text-sm mb-2">Contract Terms</h3>
              <p className="text-white">{contract.terms}</p>
            </div>
            
            <div className="mt-6 flex justify-end">
              <Link to={`/contracts/${contract._id}`}>
                <GlowButton variant="secondary">
                  View Full Contract
                </GlowButton>
              </Link>
            </div>
          </GlassCard>
        )}
        
        {/* Add Milestone Form (for clients only) */}
        {isClient && contract && (
          <div className="mb-8">
            {showMilestoneForm ? (
              <GlassCard className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-semibold text-white">Add New Milestone</h2>
                  <button
                    onClick={() => setShowMilestoneForm(false)}
                    className="text-indigo-300 hover:text-indigo-200"
                  >
                    Cancel
                  </button>
                </div>
                
                <form onSubmit={handleMilestoneSubmit}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label htmlFor="title" className="block text-sm font-medium text-indigo-300 mb-2">
                        Title <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="text"
                        id="title"
                        name="title"
                        value={milestoneFormData.title}
                        onChange={handleMilestoneInputChange}
                        className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                        placeholder="Milestone title"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="amount" className="block text-sm font-medium text-indigo-300 mb-2">
                        Amount ($) <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="number"
                        id="amount"
                        name="amount"
                        value={milestoneFormData.amount}
                        onChange={handleMilestoneInputChange}
                        className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                        placeholder="0.00"
                        min="0"
                        step="0.01"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <label htmlFor="description" className="block text-sm font-medium text-indigo-300 mb-2">
                      Description <span className="text-red-400">*</span>
                    </label>
                    <textarea
                      id="description"
                      name="description"
                      value={milestoneFormData.description}
                      onChange={handleMilestoneInputChange}
                      rows="3"
                      className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                      placeholder="Describe what needs to be completed for this milestone..."
                      required
                    ></textarea>
                  </div>
                  
                  <div className="mb-4">
                    <label htmlFor="dueDate" className="block text-sm font-medium text-indigo-300 mb-2">
                      Due Date <span className="text-red-400">*</span>
                    </label>
                    <input
                      type="date"
                      id="dueDate"
                      name="dueDate"
                      value={milestoneFormData.dueDate}
                      onChange={handleMilestoneInputChange}
                      className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                      required
                    />
                  </div>
                  
                  <div className="flex justify-end">
                    <GlowButton
                      type="submit"
                      variant="primary"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? 'Creating...' : 'Create Milestone'}
                    </GlowButton>
                  </div>
                </form>
              </GlassCard>
            ) : (
              <div className="text-center mb-8">
                <GlowButton
                  variant="primary"
                  onClick={() => setShowMilestoneForm(true)}
                >
                  Add New Milestone
                </GlowButton>
              </div>
            )}
          </div>
        )}
        
        {/* Milestone Tracker */}
        <MilestoneTracker
          projectId={projectId}
          milestones={milestones}
          onMilestoneUpdate={handleMilestoneUpdate}
        />
      </motion.div>
    </div>
  );
};

export default ProjectTimeline;
