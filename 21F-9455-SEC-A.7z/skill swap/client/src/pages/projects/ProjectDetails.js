import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';
import { useAuth } from '../../hooks/useAuth';

const ProjectDetails = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [project, setProject] = useState(null);
  const [bidAmount, setBidAmount] = useState('');
  const [bidProposal, setBidProposal] = useState('');
  const [showBidForm, setShowBidForm] = useState(false);

  // Simulate fetching project details
  useEffect(() => {
    const timer = setTimeout(() => {
      // Mock project data
      setProject({
        id,
        title: 'Sample Project',
        description: 'This is a sample project description. The actual project details would be loaded from the API.',
        budget: '$500 - $1000',
        deadline: '30 days',
        skills: ['React', 'Node.js', 'MongoDB'],
        client: {
          id: 'client123',
          name: 'John Doe',
          rating: 4.8,
          projectsPosted: 15
        },
        status: 'active',
        bids: [],
        createdAt: new Date().toISOString()
      });
      setLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [id]);

  const handleSubmitBid = (e) => {
    e.preventDefault();
    
    if (!bidAmount || !bidProposal) {
      toast.error('Please fill in all fields');
      return;
    }
    
    // Simulate submitting bid
    toast.success('Your bid has been submitted successfully!');
    setShowBidForm(false);
    setBidAmount('');
    setBidProposal('');
  };

  if (loading) {
    return <LoadingScreen />;
  }

  if (!project) {
    return (
      <div className="container mx-auto px-4 py-8">
        <GlassCard className="p-8 text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Project Not Found</h2>
          <p className="text-indigo-300 mb-6">The project you're looking for doesn't exist or has been removed.</p>
          <Link to="/projects">
            <GlowButton variant="primary">Browse Projects</GlowButton>
          </Link>
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Link to="/projects" className="text-indigo-400 hover:text-indigo-300 mb-6 inline-block">
          &larr; Back to Projects
        </Link>
        
        <GlassCard className="p-6 mb-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <h1 className="text-2xl md:text-3xl font-bold text-white">{project.title}</h1>
            <div className="mt-4 md:mt-0">
              <span className="px-4 py-2 bg-indigo-900/50 text-indigo-300 rounded-full">
                Budget: {project.budget}
              </span>
            </div>
          </div>
          
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-white mb-2">Project Description</h2>
            <p className="text-indigo-300">{project.description}</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <h2 className="text-xl font-semibold text-white mb-2">Details</h2>
              <div className="space-y-2">
                <p className="text-indigo-300">
                  <span className="font-medium">Deadline:</span> {project.deadline}
                </p>
                <p className="text-indigo-300">
                  <span className="font-medium">Posted:</span> {new Date(project.createdAt).toLocaleDateString()}
                </p>
                <p className="text-indigo-300">
                  <span className="font-medium">Status:</span> {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
                </p>
              </div>
            </div>
            
            <div>
              <h2 className="text-xl font-semibold text-white mb-2">Required Skills</h2>
              <div className="flex flex-wrap gap-2">
                {project.skills.map((skill) => (
                  <span key={skill} className="px-3 py-1 bg-indigo-900/50 text-indigo-300 rounded-full text-sm">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
          
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-white mb-2">About the Client</h2>
            <div className="flex items-center">
              <div className="w-12 h-12 bg-indigo-900/50 rounded-full flex items-center justify-center text-white font-bold">
                {project.client.name.charAt(0)}
              </div>
              <div className="ml-4">
                <p className="text-white font-medium">{project.client.name}</p>
                <p className="text-indigo-300">
                  Rating: {project.client.rating} • {project.client.projectsPosted} Projects Posted
                </p>
              </div>
            </div>
          </div>
          
          {user && user.role === 'freelancer' && (
            <div>
              {showBidForm ? (
                <div>
                  <h2 className="text-xl font-semibold text-white mb-4">Submit Your Bid</h2>
                  <form onSubmit={handleSubmitBid}>
                    <div className="mb-4">
                      <label className="block text-indigo-300 mb-2">Bid Amount ($)</label>
                      <input
                        type="number"
                        value={bidAmount}
                        onChange={(e) => setBidAmount(e.target.value)}
                        className="w-full px-4 py-2 rounded-md bg-gray-900/50 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="Enter your bid amount"
                        min="1"
                        required
                      />
                    </div>
                    
                    <div className="mb-4">
                      <label className="block text-indigo-300 mb-2">Proposal</label>
                      <textarea
                        value={bidProposal}
                        onChange={(e) => setBidProposal(e.target.value)}
                        className="w-full px-4 py-2 rounded-md bg-gray-900/50 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="Describe why you're the best fit for this project"
                        rows="4"
                        required
                      />
                    </div>
                    
                    <div className="flex space-x-4">
                      <GlowButton type="submit" variant="primary">
                        Submit Bid
                      </GlowButton>
                      <GlowButton
                        type="button"
                        variant="secondary"
                        onClick={() => setShowBidForm(false)}
                      >
                        Cancel
                      </GlowButton>
                    </div>
                  </form>
                </div>
              ) : (
                <GlowButton
                  variant="primary"
                  onClick={() => setShowBidForm(true)}
                >
                  Place a Bid
                </GlowButton>
              )}
            </div>
          )}
        </GlassCard>
        
        <GlassCard className="p-6">
          <h2 className="text-xl font-semibold text-white mb-4">Bids ({project.bids.length})</h2>
          {project.bids.length > 0 ? (
            <div className="space-y-4">
              {project.bids.map((bid) => (
                <div key={bid.id} className="border-b border-gray-700 pb-4 last:border-0 last:pb-0">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-indigo-900/50 rounded-full flex items-center justify-center text-white font-bold">
                        {bid.freelancer.name.charAt(0)}
                      </div>
                      <div className="ml-3">
                        <p className="text-white font-medium">{bid.freelancer.name}</p>
                        <p className="text-indigo-300 text-sm">
                          Rating: {bid.freelancer.rating} • {bid.freelancer.completedProjects} Projects Completed
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-bold">${bid.amount}</p>
                      <p className="text-indigo-300 text-sm">{bid.deliveryTime} days</p>
                    </div>
                  </div>
                  <p className="text-indigo-300 mt-3">{bid.proposal}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-indigo-300">No bids yet. Be the first to bid on this project!</p>
          )}
        </GlassCard>
      </motion.div>
    </div>
  );
};

export default ProjectDetails;
