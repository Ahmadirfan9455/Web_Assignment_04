import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUpload, faTimes, faCalendar } from '@fortawesome/free-solid-svg-icons';

const CreateProject = () => {
  const navigate = useNavigate();
  const { user, updateUserRole } = useAuth();
  
  // Form state
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    requirements: '',
    category: '',
    budget: '',
    duration: '',
    deadline: '',
    skills: [],
    attachments: [],
  });
  
  // UI states
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentSkill, setCurrentSkill] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  
  // Available categories
  const categories = [
    'Web Development',
    'Mobile Development',
    'UI/UX Design',
    'Graphic Design',
    'Content Writing',
    'Digital Marketing',
    'Data Entry',
    'Virtual Assistant',
    'Translation',
    'Other',
  ];
  
  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };
  
  // Handle skill input
  const handleSkillChange = (e) => {
    setCurrentSkill(e.target.value);
  };
  
  // Add skill
  const addSkill = () => {
    if (currentSkill.trim() === '') return;
    
    if (formData.skills.includes(currentSkill.trim())) {
      toast.info('This skill is already added');
      return;
    }
    
    setFormData(prev => ({
      ...prev,
      skills: [...prev.skills, currentSkill.trim()],
    }));
    
    setCurrentSkill('');
  };
  
  // Remove skill
  const removeSkill = (skillToRemove) => {
    setFormData(prev => ({
      ...prev,
      skills: prev.skills.filter(skill => skill !== skillToRemove),
    }));
  };
  
  // Handle file selection (for preview/UI only)
  const handleFileUpload = (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;
    if (formData.attachments.length + files.length > 5) {
      toast.error('You can upload a maximum of 5 files.');
      return;
    }
    // Check file size (max 5MB per file)
    const oversizedFiles = files.filter(file => file.size > 5 * 1024 * 1024);
    if (oversizedFiles.length > 0) {
      toast.error('Some files exceed the 5MB size limit');
      return;
    }
    setFormData(prev => ({
      ...prev,
      attachments: [...prev.attachments, ...files],
    }));
  };

  
  // Remove attachment
  const removeAttachment = (index) => {
    setFormData(prev => ({
      ...prev,
      attachments: prev.attachments.filter((_, i) => i !== index),
    }));
  };
  
  // Submit form
  const handleSubmit = async (e) => {
    e.preventDefault();
    // Validate form
    if (!formData.title || !formData.description || !formData.requirements || !formData.category || !formData.budget || !formData.duration || !formData.deadline) {
      toast.error('Please fill in all required fields');
      return;
    }
    if (parseFloat(formData.budget) <= 0) {
      toast.error('Budget must be greater than zero');
      return;
    }
    if (parseInt(formData.duration) <= 0) {
      toast.error('Duration must be greater than zero days');
      return;
    }
    const deadlineDate = new Date(formData.deadline);
    if (isNaN(deadlineDate.getTime())) {
      toast.error('Invalid deadline date');
      return;
    }
    if (formData.skills.length === 0) {
      toast.error('Please add at least one required skill');
      return;
    }
    setIsSubmitting(true);
    setUploadProgress(0);
    const uploadToast = toast.loading('Uploading project...');
    try {
      // Prepare FormData for multipart/form-data
      const fd = new FormData();
      fd.append('title', formData.title);
      fd.append('description', formData.description);
      fd.append('requirements', formData.requirements);
      fd.append('category', formData.category);
      fd.append('budget', formData.budget);
      fd.append('duration', formData.duration);
      fd.append('deadline', formData.deadline);
      formData.skills.forEach(skill => fd.append('skills', skill));
      // Attach files
      formData.attachments.forEach(file => fd.append('files', file));
      // POST to backend
      const response = await axios.post('/api/projects', fd, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (progressEvent) => {
          const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          setUploadProgress(percentCompleted);
          if (percentCompleted < 100) {
            toast.update(uploadToast, {
              render: `Uploading: ${percentCompleted}%`,
              type: 'info',
              isLoading: true,
            });
          }
        }
      });
      toast.update(uploadToast, {
        render: 'Project created successfully!',
        type: 'success',
        isLoading: false,
        autoClose: 3000,
      });
      setUploadProgress(0);
      navigate(`/projects/${response.data._id}`);
    } catch (error) {
      console.error('Error creating project:', error);
      toast.update(uploadToast, {
        render: error.response?.data?.message || 'Failed to create project. Please try again.',
        type: 'error',
        isLoading: false,
        autoClose: 3000,
      });
      setUploadProgress(0);
    } finally {
      setIsSubmitting(false);
    }
  };

  
  // Check if user has client role
  useEffect(() => {
    const checkUserRole = async () => {
      if (user) {
        // If user is already a client, no need to show the role switch message
        if (user.role === 'client') {
          return;
        }
        
        // If user is not a client, show the role switch message
        toast.info('You need to have a client role to create projects. You can switch roles below.');
      }
    };
    
    checkUserRole();
  }, [user]);
  
  // Handle role switch
  const handleRoleSwitch = async () => {
    if (!user) {
      toast.error('You must be logged in to switch roles');
      return;
    }
    
    // Show loading toast
    const loadingToast = toast.loading('Switching to client role...');
    
    try {
      const success = await updateUserRole('client');
      
      if (success) {
        // Update loading toast to success
        toast.update(loadingToast, {
          render: 'You are now a client and can create projects!',
          type: 'success',
          isLoading: false,
          autoClose: 3000
        });
        
        // Reload the page after a short delay to ensure all components update with the new role
        setTimeout(() => {
          window.location.reload();
        }, 1000);
      } else {
        // Update loading toast to error
        toast.update(loadingToast, {
          render: 'Failed to switch roles. Please try again.',
          type: 'error',
          isLoading: false,
          autoClose: 3000
        });
      }
    } catch (error) {
      console.error('Role switch error:', error);
      
      // Update loading toast to error
      toast.update(loadingToast, {
        render: 'Failed to switch roles. Please try again.',
        type: 'error',
        isLoading: false,
        autoClose: 3000
      });
    }
  };

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
      },
    },
  };
  
  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8">
      <motion.div
        className="max-w-3xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants} className="mb-8">
          <h1 className="text-3xl font-bold text-white">Post a New Project</h1>
          <p className="text-indigo-200 mt-2">
            Fill in the details below to post your project and start receiving bids from freelancers.
          </p>
        </motion.div>
        
        {user && user.role !== 'client' && (
          <GlassCard className="mb-8 p-6">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold mb-2">You're currently a {user.role}</h2>
                <p className="text-gray-600">You need to be a client to create projects.</p>
              </div>
              <GlowButton 
                onClick={handleRoleSwitch}
                className="mt-4 md:mt-0"
              >
                Switch to Client Role
              </GlowButton>
            </div>
          </GlassCard>
        )}
        
        <motion.div variants={itemVariants}>
          <GlassCard className="p-6">
            <form onSubmit={handleSubmit}>
              {/* Project Title */}
              <div className="mb-6">
                <label htmlFor="title" className="block text-sm font-medium text-indigo-300 mb-1">
                  Project Title <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  id="title"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Enter a clear, descriptive title for your project"
                  required
                />
              </div>
              
              {/* Project Description */}
              <div className="mb-6">
                <label htmlFor="description" className="block text-sm font-medium text-indigo-300 mb-1">
                  Project Description <span className="text-red-400">*</span>
                </label>
                <textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  rows="6"
                  className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Describe your project in detail, including requirements, expectations, and any specific instructions"
                  required
                ></textarea>
              </div>
              
              {/* Project Requirements */}
              <div className="mb-6">
                <label htmlFor="requirements" className="block text-sm font-medium text-indigo-300 mb-1">
                  Project Requirements <span className="text-red-400">*</span>
                </label>
                <textarea
                  id="requirements"
                  name="requirements"
                  value={formData.requirements}
                  onChange={handleChange}
                  rows="6"
                  className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="List the specific requirements for your project"
                  required
                ></textarea>
              </div>
              
              {/* Category and Budget */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="category" className="block text-sm font-medium text-indigo-300 mb-1">
                    Category <span className="text-red-400">*</span>
                  </label>
                  <select
                    id="category"
                    name="category"
                    value={formData.category}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    required
                  >
                    <option value="">Select a category</option>
                    {categories.map((category, index) => (
                      <option key={index} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label htmlFor="budget" className="block text-sm font-medium text-indigo-300 mb-1">
                    Budget ($) <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="number"
                    id="budget"
                    name="budget"
                    value={formData.budget}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="Enter your budget"
                    min="1"
                    step="0.01"
                    required
                  />
                </div>
              </div>
              
              {/* Duration */}
              <div className="mb-6">
                <label htmlFor="duration" className="block text-sm font-medium text-indigo-300 mb-1">
                  Duration (days) <span className="text-red-400">*</span>
                </label>
                <input
                  type="number"
                  id="duration"
                  name="duration"
                  value={formData.duration}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Enter project duration in days"
                  min="1"
                  required
                />
              </div>
              
              {/* Deadline */}
              <div className="mb-6">
                <label htmlFor="deadline" className="block text-sm font-medium text-indigo-300 mb-1">
                  Deadline <span className="text-red-400">*</span>
                </label>
                <input
                  type="date"
                  id="deadline"
                  name="deadline"
                  value={formData.deadline}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  required
                />
              </div>
              
              {/* Skills */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-indigo-300 mb-1">
                  Required Skills <span className="text-red-400">*</span>
                </label>
                <div className="flex">
                  <input
                    type="text"
                    value={currentSkill}
                    onChange={handleSkillChange}
                    className="flex-1 px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-l-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="Add a required skill"
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addSkill();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={addSkill}
                    className="px-4 py-2 bg-indigo-600 text-white rounded-r-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    Add
                  </button>
                </div>
                
                {formData.skills.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {formData.skills.map((skill, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-indigo-900/50 text-indigo-300"
                      >
                        {skill}
                        <button
                          type="button"
                          onClick={() => removeSkill(skill)}
                          className="ml-2 text-indigo-300 hover:text-indigo-100"
                        >
                          &times;
                        </button>
                      </span>
                    ))}
                  </div>
                )}
              </div>
              
              {/* Attachments */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-indigo-300 mb-1">
                  Attachments
                </label>
                <div className="border-2 border-dashed border-gray-700 rounded-md p-4 text-center">
                  <input
                    type="file"
                    id="attachments"
                    onChange={handleFileUpload}
                    className="hidden"
                    multiple
                  />
                  <label
                    htmlFor="attachments"
                    className="cursor-pointer text-indigo-400 hover:text-indigo-300 transition-colors"
                  >
                    <div className="flex flex-col items-center">
                      <FontAwesomeIcon icon={faUpload} className="w-8 h-8 mb-2" />
                      <span className="text-indigo-300">
                        Click to upload files or drag and drop
                      </span>
                      <span className="text-indigo-400 text-xs mt-1">
                        Max file size: 5MB
                      </span>
                    </div>
                  </label>
                  
                  {uploadProgress > 0 && uploadProgress < 100 && (
                    <div className="mt-4">
                      <div className="w-full bg-gray-700 rounded-full h-2.5">
                        <div
                          className="bg-indigo-600 h-2.5 rounded-full"
                          style={{ width: `${uploadProgress}%` }}
                        ></div>
                      </div>
                      <p className="text-indigo-300 text-xs mt-1">
                        Uploading: {uploadProgress}%
                      </p>
                    </div>
                  )}
                </div>
                
                {formData.attachments.length > 0 && (
                  <div className="mt-3">
                    <h4 className="text-sm font-medium text-indigo-300 mb-2">
                      Uploaded Files:
                    </h4>
                    <ul className="space-y-2">
                      {formData.attachments.map((file, index) => (
                        <li
                          key={index}
                          className="flex items-center justify-between bg-gray-800 rounded-md p-2"
                        >
                          <a
                            href={file.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-indigo-400 hover:text-indigo-300 transition-colors"
                          >
                            {file.name}
                          </a>
                          <button
                            type="button"
                            onClick={() => removeAttachment(index)}
                            className="text-red-400 hover:text-red-300 transition-colors"
                          >
                            <FontAwesomeIcon icon={faTimes} className="w-4 h-4" />
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
              
              {/* Submit Button */}
              <div className="flex justify-end">
                <GlowButton
                  type="submit"
                  variant="primary"
                  className="px-6 py-2"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? 'Creating Project...' : 'Post Project'}
                </GlowButton>
              </div>
            </form>
          </GlassCard>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default CreateProject;
