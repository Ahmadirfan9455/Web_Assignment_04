import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';
import ReviewList from '../../components/reviews/ReviewList';
import ReviewForm from '../../components/reviews/ReviewForm';

const FreelancerReviews = () => {
  const { freelancerId } = useParams();
  const { user } = useAuth();
  
  // State
  const [freelancer, setFreelancer] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [contracts, setContracts] = useState([]);
  const [selectedContract, setSelectedContract] = useState('');
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [reviewsLoading, setReviewsLoading] = useState(true);
  
  // Check if user can leave a review
  const canLeaveReview = () => {
    if (!user || user.role !== 'client') return false;
    
    // Check if user has completed contracts with this freelancer
    return contracts.length > 0;
  };
  
  // Fetch freelancer data
  useEffect(() => {
    const fetchFreelancer = async () => {
      try {
        const { data } = await axios.get(`/api/users/${freelancerId}`);
        setFreelancer(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching freelancer:', error);
        toast.error('Failed to load freelancer information');
        setLoading(false);
      }
    };
    
    fetchFreelancer();
  }, [freelancerId]);
  
  // Fetch reviews
  useEffect(() => {
    const fetchReviews = async () => {
      try {
        setReviewsLoading(true);
        const { data } = await axios.get(`/api/reviews/freelancer/${freelancerId}`);
        setReviews(data);
        setReviewsLoading(false);
      } catch (error) {
        console.error('Error fetching reviews:', error);
        toast.error('Failed to load reviews');
        setReviewsLoading(false);
      }
    };
    
    fetchReviews();
  }, [freelancerId]);
  
  // Fetch contracts for the client with this freelancer
  useEffect(() => {
    const fetchContracts = async () => {
      if (!user || user.role !== 'client') return;
      
      try {
        const { data } = await axios.get(`/api/contracts/client/freelancer/${freelancerId}`);
        
        // Filter only completed contracts that haven't been reviewed
        const eligibleContracts = data.filter(
          contract => contract.status === 'completed' && !contract.reviewed
        );
        
        setContracts(eligibleContracts);
      } catch (error) {
        console.error('Error fetching contracts:', error);
      }
    };
    
    fetchContracts();
  }, [freelancerId, user]);
  
  // Handle review submission
  const handleReviewSubmitted = () => {
    // Refresh reviews
    const fetchReviews = async () => {
      try {
        const { data } = await axios.get(`/api/reviews/freelancer/${freelancerId}`);
        setReviews(data);
      } catch (error) {
        console.error('Error fetching reviews:', error);
      }
    };
    
    // Refresh contracts
    const fetchContracts = async () => {
      if (!user || user.role !== 'client') return;
      
      try {
        const { data } = await axios.get(`/api/contracts/client/freelancer/${freelancerId}`);
        
        // Filter only completed contracts that haven't been reviewed
        const eligibleContracts = data.filter(
          contract => contract.status === 'completed' && !contract.reviewed
        );
        
        setContracts(eligibleContracts);
      } catch (error) {
        console.error('Error fetching contracts:', error);
      }
    };
    
    fetchReviews();
    fetchContracts();
    setShowReviewForm(false);
    setSelectedContract('');
  };
  
  if (loading) {
    return <LoadingScreen />;
  }
  
  if (!freelancer) {
    return (
      <div className="container mx-auto px-4 py-8">
        <GlassCard className="p-6 text-center">
          <h2 className="text-xl text-white mb-4">Freelancer not found</h2>
          <Link to="/browse">
            <GlowButton variant="primary">Browse Freelancers</GlowButton>
          </Link>
        </GlassCard>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {/* Freelancer Header */}
        <GlassCard className="p-6 mb-8">
          <div className="flex flex-col md:flex-row items-center">
            <div className="w-24 h-24 bg-indigo-700 rounded-full flex items-center justify-center mb-4 md:mb-0 md:mr-6">
              {freelancer.profileImage ? (
                <img 
                  src={freelancer.profileImage} 
                  alt={freelancer.name} 
                  className="w-24 h-24 rounded-full object-cover"
                />
              ) : (
                <span className="text-white text-3xl font-bold">
                  {freelancer.name.charAt(0).toUpperCase()}
                </span>
              )}
            </div>
            
            <div className="text-center md:text-left">
              <h1 className="text-2xl font-bold text-white">{freelancer.name}</h1>
              <p className="text-indigo-300">{freelancer.title || 'Freelancer'}</p>
              
              <div className="mt-2 flex flex-wrap gap-2 justify-center md:justify-start">
                {freelancer.skills && freelancer.skills.map((skill, index) => (
                  <span 
                    key={index}
                    className="px-2 py-1 bg-indigo-900/50 rounded-full text-xs text-indigo-300"
                  >
                    {skill}
                  </span>
                ))}
              </div>
              
              <div className="mt-4">
                <Link to={`/freelancer/${freelancerId}`}>
                  <GlowButton variant="secondary" className="mr-2">
                    View Profile
                  </GlowButton>
                </Link>
                
                <Link to={`/messages/new/${freelancerId}`}>
                  <GlowButton variant="primary">
                    Contact
                  </GlowButton>
                </Link>
              </div>
            </div>
          </div>
        </GlassCard>
        
        {/* Leave Review Section */}
        {canLeaveReview() && (
          <div className="mb-8">
            {showReviewForm ? (
              <div>
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-semibold text-white">Leave a Review</h2>
                  <button
                    onClick={() => setShowReviewForm(false)}
                    className="text-indigo-300 hover:text-indigo-200"
                  >
                    Cancel
                  </button>
                </div>
                
                <div className="mb-4">
                  <label className="block text-sm font-medium text-indigo-300 mb-2">
                    Select Project
                  </label>
                  <select
                    value={selectedContract}
                    onChange={(e) => setSelectedContract(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    required
                  >
                    <option value="">Select a completed project</option>
                    {contracts.map((contract) => (
                      <option key={contract._id} value={contract._id}>
                        {contract.project.title}
                      </option>
                    ))}
                  </select>
                </div>
                
                {selectedContract && (
                  <ReviewForm
                    contractId={selectedContract}
                    freelancerId={freelancerId}
                    onReviewSubmitted={handleReviewSubmitted}
                  />
                )}
              </div>
            ) : (
              <div className="text-center">
                <GlowButton
                  variant="primary"
                  onClick={() => setShowReviewForm(true)}
                >
                  Leave a Review
                </GlowButton>
              </div>
            )}
          </div>
        )}
        
        {/* Reviews */}
        <h2 className="text-2xl font-semibold text-white mb-4">Reviews</h2>
        <ReviewList
          reviews={reviews}
          onResponseAdded={handleReviewSubmitted}
          isLoading={reviewsLoading}
        />
      </motion.div>
    </div>
  );
};

export default FreelancerReviews;
