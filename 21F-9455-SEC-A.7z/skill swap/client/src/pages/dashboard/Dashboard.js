import React from 'react';
import { motion } from 'framer-motion';
import GlassCard from '../../components/ui/GlassCard';
import { useAuth } from '../../hooks/useAuth';

const Dashboard = () => {
  const { user } = useAuth();
  
  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-bold text-white mb-6">Dashboard</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <GlassCard className="p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Welcome, {user?.name || 'User'}!</h2>
            <p className="text-indigo-300">
              This is your SkillSwap dashboard. Here you can manage your projects, contracts, and more.
            </p>
          </GlassCard>
          
          <GlassCard className="p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Quick Actions</h2>
            <div className="flex flex-col space-y-2">
              <a href="/projects" className="text-indigo-400 hover:text-indigo-300">Browse Projects</a>
              <a href="/messages" className="text-indigo-400 hover:text-indigo-300">Check Messages</a>
              <a href="/profile" className="text-indigo-400 hover:text-indigo-300">Update Profile</a>
            </div>
          </GlassCard>
          
          <GlassCard className="p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Stats</h2>
            <div className="flex flex-col space-y-2">
              <p className="text-indigo-300">Active Projects: <span className="text-white">0</span></p>
              <p className="text-indigo-300">Pending Contracts: <span className="text-white">0</span></p>
              <p className="text-indigo-300">Unread Messages: <span className="text-white">0</span></p>
            </div>
          </GlassCard>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <GlassCard className="p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Recent Activity</h2>
            <p className="text-indigo-300">No recent activity to display.</p>
          </GlassCard>
          
          <GlassCard className="p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Upcoming Deadlines</h2>
            <p className="text-indigo-300">No upcoming deadlines.</p>
          </GlassCard>
        </div>
      </motion.div>
    </div>
  );
};

export default Dashboard;
