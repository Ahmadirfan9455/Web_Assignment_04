import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import GlowButton from '../components/ui/GlowButton';

const NotFound = () => {
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
      },
    },
  };
  
  return (
    <div className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8">
      <motion.div
        className="max-w-md w-full text-center"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants}>
          <h1 className="text-9xl font-bold text-indigo-500 mb-4">404</h1>
        </motion.div>
        
        <motion.div variants={itemVariants}>
          <h2 className="text-3xl font-bold text-white mb-4">Page Not Found</h2>
        </motion.div>
        
        <motion.div variants={itemVariants}>
          <p className="text-indigo-200 mb-8">
            The page you're looking for doesn't exist or has been moved.
          </p>
        </motion.div>
        
        <motion.div variants={itemVariants} className="flex justify-center">
          <GlowButton
            as={Link}
            to="/"
            variant="primary"
            className="px-8 py-3"
          >
            Back to Home
          </GlowButton>
        </motion.div>
        
        <motion.div 
          variants={itemVariants}
          className="mt-12"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ 
            opacity: 1, 
            scale: 1,
            rotate: [0, 5, -5, 5, 0],
            transition: { 
              duration: 0.5,
              repeat: Infinity,
              repeatType: "reverse",
              repeatDelay: 5
            }
          }}
        >
          <div className="text-9xl">👾</div>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default NotFound;
