import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

const Profile = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState(null);

  // Simulate fetching profile data
  useEffect(() => {
    if (user) {
      const timer = setTimeout(() => {
        // Mock profile data based on user role
        setProfile({
          ...user,
          bio: 'Experienced professional with a passion for quality work.',
          skills: ['JavaScript', 'React', 'Node.js'],
          hourlyRate: user.role === 'freelancer' ? 45 : null,
          completedProjects: user.role === 'freelancer' ? 12 : 8,
          rating: user.role === 'freelancer' ? 4.8 : 4.5,
          reviewCount: user.role === 'freelancer' ? 15 : 8,
          location: 'New York, USA',
          languages: ['English (Native)', 'Spanish (Conversational)'],
          education: [
            {
              degree: 'Bachelor of Science in Computer Science',
              institution: 'University of Technology',
              year: '2018'
            }
          ],
          experience: [
            {
              title: 'Senior Developer',
              company: 'Tech Solutions Inc.',
              period: '2019 - Present',
              description: 'Developed and maintained web applications for various clients.'
            }
          ]
        });
        setLoading(false);
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [user]);

  if (loading) {
    return <LoadingScreen />;
  }

  if (!profile) {
    return (
      <div className="container mx-auto px-4 py-8">
        <GlassCard className="p-8 text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Profile Not Found</h2>
          <p className="text-indigo-300 mb-6">Please log in to view your profile.</p>
        </GlassCard>
      </div>
    );
  }

  // Review state for freelancers
  const [reviews, setReviews] = useState([]);
  const [reviewsLoading, setReviewsLoading] = useState(false);

  useEffect(() => {
    if (user?.role === 'freelancer') {
      setReviewsLoading(true);
      // Fetch reviews for freelancer
      fetch(`/api/reviews/freelancer/${user._id}`)
        .then(res => res.json())
        .then(data => setReviews(data))
        .catch(() => setReviews([]))
        .finally(() => setReviewsLoading(false));
    }
  }, [user]);

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-white">My Profile</h1>
          <Link to="/profile/edit">
            <GlowButton variant="primary">Edit Profile</GlowButton>
          </Link>
        </div>

        {/* Profile Header */}
        <GlassCard className="p-6 mb-8">
          <div className="flex flex-col md:flex-row">
            <div className="w-24 h-24 md:w-32 md:h-32 rounded-full bg-indigo-900/50 flex items-center justify-center text-white text-3xl font-bold">
              {profile.name?.charAt(0) || 'U'}
            </div>
            <div className="mt-4 md:mt-0 md:ml-6 flex-1">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                <div>
                  <h2 className="text-2xl md:text-3xl font-bold text-white">{profile.name}</h2>
                  <p className="text-indigo-300 text-lg capitalize">{profile.role}</p>
                  {profile.rating && (
                    <div className="flex items-center mt-2">
                      <span className="text-yellow-400">★</span>
                      <span className="text-white ml-1">{profile.rating}</span>
                      <span className="text-indigo-300 ml-2">({profile.reviewCount} reviews)</span>
                    </div>
                  )}
                  <p className="text-indigo-300 mt-1">
                    <span className="font-medium">Location:</span> {profile.location}
                  </p>
                </div>
                <div className="mt-4 md:mt-0">
                  {profile.hourlyRate && (
                    <p className="text-xl font-bold text-white">${profile.hourlyRate}/hr</p>
                  )}
                  <p className="text-indigo-300">{profile.completedProjects} Projects Completed</p>
                </div>
              </div>
            </div>
          </div>
        </GlassCard>

        {/* Reviews section for freelancers */}
        {user?.role === 'freelancer' && (
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-white mb-4">Reviews</h2>
            <React.Suspense fallback={<div>Loading reviews...</div>}>
              <ReviewList reviews={reviews} isLoading={reviewsLoading} />
            </React.Suspense>
          </div>
        )}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            {/* About */}
            <GlassCard className="p-6 mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">About Me</h2>
              <p className="text-indigo-300">{profile.bio}</p>
            </GlassCard>
            
            {/* Skills */}
            <GlassCard className="p-6 mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">Skills</h2>
              <div className="flex flex-wrap gap-2">
                {profile.skills?.map((skill) => (
                  <span key={skill} className="px-3 py-1 bg-indigo-900/50 text-indigo-300 rounded-full">
                    {skill}
                  </span>
                ))}
              </div>
            </GlassCard>
            
            {/* Experience */}
            <GlassCard className="p-6">
              <h2 className="text-xl font-semibold text-white mb-4">Experience</h2>
              {profile.experience?.length > 0 ? (
                <div className="space-y-6">
                  {profile.experience.map((exp, index) => (
                    <div key={index} className="border-b border-gray-700 pb-4 last:border-0 last:pb-0">
                      <h3 className="text-lg font-medium text-white">{exp.title}</h3>
                      <p className="text-indigo-300">{exp.company}</p>
                      <p className="text-indigo-300 text-sm">{exp.period}</p>
                      <p className="text-indigo-300 mt-2">{exp.description}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-indigo-300">No experience information available.</p>
              )}
            </GlassCard>
          </div>
          
          <div>
            {/* Account Details */}
            <GlassCard className="p-6 mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">Account Details</h2>
              <div className="space-y-3">
                <div>
                  <p className="text-indigo-300 text-sm">Email</p>
                  <p className="text-white">{profile.email}</p>
                </div>
                <div>
                  <p className="text-indigo-300 text-sm">Member Since</p>
                  <p className="text-white">{new Date(profile.createdAt || Date.now()).toLocaleDateString()}</p>
                </div>
                <div>
                  <p className="text-indigo-300 text-sm">Account Type</p>
                  <p className="text-white capitalize">{profile.role}</p>
                </div>
              </div>
            </GlassCard>
            
            {/* Languages */}
            <GlassCard className="p-6 mb-8">
              <h2 className="text-xl font-semibold text-white mb-4">Languages</h2>
              <ul className="space-y-2">
                {profile.languages?.map((language, index) => (
                  <li key={index} className="text-indigo-300">{language}</li>
                ))}
              </ul>
            </GlassCard>
            
            {/* Education */}
            <GlassCard className="p-6">
              <h2 className="text-xl font-semibold text-white mb-4">Education</h2>
              {profile.education?.length > 0 ? (
                <div className="space-y-4">
                  {profile.education.map((edu, index) => (
                    <div key={index}>
                      <h3 className="text-lg font-medium text-white">{edu.degree}</h3>
                      <p className="text-indigo-300">{edu.institution}</p>
                      <p className="text-indigo-300">{edu.year}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-indigo-300">No education information available.</p>
              )}
            </GlassCard>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Profile;
