import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { motion } from 'framer-motion';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import Layout from '../../components/layout/Layout';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LocationSelector from '../../components/maps/LocationSelector';

const LocationPage = () => {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [locationAddress, setLocationAddress] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // If user is not logged in, redirect to login
  useEffect(() => {
    if (!loading && !user) {
      navigate('/login');
    }
  }, [user, loading, navigate]);

  // Handle location selection from the map
  const handleLocationSelect = (location, address) => {
    setSelectedLocation(location);
    setLocationAddress(address);
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!selectedLocation) {
      toast.error('Please select a location on the map');
      return;
    }
    
    try {
      setIsSubmitting(true);
      
      // Update user profile with location data
      const response = await axios.put(
        'http://localhost:5000/api/auth/profile',
        {
          location: {
            coordinates: [selectedLocation.lng, selectedLocation.lat], // MongoDB uses [lng, lat] format
            address: locationAddress
          }
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`
          }
        }
      );
      
      if (response.data) {
        toast.success('Location updated successfully');
        navigate('/profile');
      }
    } catch (error) {
      console.error('Error updating location:', error);
      toast.error(error.response?.data?.message || 'Failed to update location');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
      },
    },
  };

  return (
    <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <GlassCard className="max-w-4xl mx-auto">
        <motion.div
          className="space-y-8 p-6"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div variants={itemVariants}>
            <h2 className="text-center text-3xl font-extrabold text-white">
              Update Your Location
            </h2>
            <p className="mt-2 text-center text-indigo-300">
              Select your location on the map or search for an address
            </p>
          </motion.div>
          
          <motion.div variants={itemVariants}>
            <LocationSelector onLocationSelect={handleLocationSelect} />
          </motion.div>
          
          <motion.div variants={itemVariants} className="flex justify-between">
            <GlowButton
              type="button"
              variant="secondary"
              onClick={() => navigate('/profile')}
              className="w-auto px-4"
            >
              Cancel
            </GlowButton>
            
            <GlowButton
              type="button"
              variant="primary"
              onClick={handleSubmit}
              className="w-auto px-4"
              disabled={isSubmitting || !selectedLocation}
            >
              {isSubmitting ? 'Saving...' : 'Save Location'}
            </GlowButton>
          </motion.div>
        </motion.div>
      </GlassCard>
    </div>
  );
};

export default LocationPage;
