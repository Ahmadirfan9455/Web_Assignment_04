import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

const EditProfile = () => {
  const { user, updateUser } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    bio: '',
    location: '',
    skills: [],
    hourlyRate: '',
    languages: [],
    newSkill: '',
    newLanguage: ''
  });

  // Simulate fetching profile data
  useEffect(() => {
    if (user) {
      const timer = setTimeout(() => {
        // Mock profile data based on user
        setFormData({
          name: user.name || '',
          bio: 'Experienced professional with a passion for quality work.',
          location: 'New York, USA',
          skills: ['JavaScript', 'React', 'Node.js'],
          hourlyRate: user.role === 'freelancer' ? '45' : '',
          languages: ['English (Native)', 'Spanish (Conversational)'],
          newSkill: '',
          newLanguage: ''
        });
        setLoading(false);
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [user]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleAddSkill = () => {
    if (formData.newSkill.trim() && !formData.skills.includes(formData.newSkill.trim())) {
      setFormData(prev => ({
        ...prev,
        skills: [...prev.skills, prev.newSkill.trim()],
        newSkill: ''
      }));
    }
  };

  const handleRemoveSkill = (skill) => {
    setFormData(prev => ({
      ...prev,
      skills: prev.skills.filter(s => s !== skill)
    }));
  };

  const handleAddLanguage = () => {
    if (formData.newLanguage.trim() && !formData.languages.includes(formData.newLanguage.trim())) {
      setFormData(prev => ({
        ...prev,
        languages: [...prev.languages, prev.newLanguage.trim()],
        newLanguage: ''
      }));
    }
  };

  const handleRemoveLanguage = (language) => {
    setFormData(prev => ({
      ...prev,
      languages: prev.languages.filter(l => l !== language)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    
    try {
      // Prepare data for submission
      const profileData = {
        name: formData.name,
        bio: formData.bio,
        location: formData.location,
        skills: formData.skills,
        hourlyRate: user.role === 'freelancer' ? parseFloat(formData.hourlyRate) : undefined,
        languages: formData.languages
      };
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Update user in context
      await updateUser(profileData);
      
      toast.success('Profile updated successfully!');
      navigate('/profile');
    } catch (error) {
      console.error('Error updating profile:', error);
      toast.error('Failed to update profile. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-white">Edit Profile</h1>
          <Link to="/profile">
            <GlowButton variant="secondary">Cancel</GlowButton>
          </Link>
        </div>
        
        <form onSubmit={handleSubmit}>
          {/* Basic Information */}
          <GlassCard className="p-6 mb-8">
            <h2 className="text-xl font-semibold text-white mb-4">Basic Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-indigo-300 mb-2">Name</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full px-4 py-2 rounded-md bg-gray-900/50 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>
              
              <div>
                <label className="block text-indigo-300 mb-2">Location</label>
                <input
                  type="text"
                  name="location"
                  value={formData.location}
                  onChange={handleChange}
                  className="w-full px-4 py-2 rounded-md bg-gray-900/50 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              
              {user.role === 'freelancer' && (
                <div>
                  <label className="block text-indigo-300 mb-2">Hourly Rate ($)</label>
                  <input
                    type="number"
                    name="hourlyRate"
                    value={formData.hourlyRate}
                    onChange={handleChange}
                    className="w-full px-4 py-2 rounded-md bg-gray-900/50 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    min="1"
                  />
                </div>
              )}
              
              <div className="md:col-span-2">
                <label className="block text-indigo-300 mb-2">Bio</label>
                <textarea
                  name="bio"
                  value={formData.bio}
                  onChange={handleChange}
                  className="w-full px-4 py-2 rounded-md bg-gray-900/50 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  rows="4"
                />
              </div>
            </div>
          </GlassCard>
          
          {/* Skills */}
          <GlassCard className="p-6 mb-8">
            <h2 className="text-xl font-semibold text-white mb-4">Skills</h2>
            <div className="flex flex-wrap gap-2 mb-4">
              {formData.skills.map((skill) => (
                <div key={skill} className="px-3 py-1 bg-indigo-900/50 text-indigo-300 rounded-full flex items-center">
                  {skill}
                  <button
                    type="button"
                    onClick={() => handleRemoveSkill(skill)}
                    className="ml-2 text-indigo-300 hover:text-indigo-100"
                  >
                    &times;
                  </button>
                </div>
              ))}
            </div>
            <div className="flex">
              <input
                type="text"
                name="newSkill"
                value={formData.newSkill}
                onChange={handleChange}
                className="flex-1 px-4 py-2 rounded-l-md bg-gray-900/50 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="Add a skill"
              />
              <button
                type="button"
                onClick={handleAddSkill}
                className="px-4 py-2 bg-indigo-600 text-white rounded-r-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                Add
              </button>
            </div>
          </GlassCard>
          
          {/* Languages */}
          <GlassCard className="p-6 mb-8">
            <h2 className="text-xl font-semibold text-white mb-4">Languages</h2>
            <div className="flex flex-wrap gap-2 mb-4">
              {formData.languages.map((language) => (
                <div key={language} className="px-3 py-1 bg-indigo-900/50 text-indigo-300 rounded-full flex items-center">
                  {language}
                  <button
                    type="button"
                    onClick={() => handleRemoveLanguage(language)}
                    className="ml-2 text-indigo-300 hover:text-indigo-100"
                  >
                    &times;
                  </button>
                </div>
              ))}
            </div>
            <div className="flex">
              <input
                type="text"
                name="newLanguage"
                value={formData.newLanguage}
                onChange={handleChange}
                className="flex-1 px-4 py-2 rounded-l-md bg-gray-900/50 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="Add a language (e.g. English (Native))"
              />
              <button
                type="button"
                onClick={handleAddLanguage}
                className="px-4 py-2 bg-indigo-600 text-white rounded-r-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                Add
              </button>
            </div>
          </GlassCard>
          
          {/* Submit Button */}
          <div className="flex justify-end">
            <GlowButton
              type="submit"
              variant="primary"
              disabled={submitting}
            >
              {submitting ? 'Saving...' : 'Save Changes'}
            </GlowButton>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default EditProfile;
