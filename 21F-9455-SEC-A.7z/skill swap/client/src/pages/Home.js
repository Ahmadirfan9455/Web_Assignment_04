import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import { gsap } from 'gsap';
import GlowButton from '../components/ui/GlowButton';
import GlassCard from '../components/ui/GlassCard';

const Home = () => {
  const targetRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: targetRef,
    offset: ["start start", "end start"]
  });
  
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.5], [1, 0.8]);
  const y = useTransform(scrollYProgress, [0, 0.5], [0, -50]);
  
  // GSAP animation for hero section
  useEffect(() => {
    const tl = gsap.timeline();
    
    tl.from('.hero-title span', {
      opacity: 0,
      y: 50,
      duration: 1,
      stagger: 0.1,
      ease: 'power3.out'
    })
    .from('.hero-subtitle', {
      opacity: 0,
      y: 20,
      duration: 0.8,
      ease: 'power3.out'
    }, '-=0.4')
    .from('.hero-buttons', {
      opacity: 0,
      y: 20,
      duration: 0.6,
      ease: 'power3.out'
    }, '-=0.2');
    
    return () => {
      tl.kill();
    };
  }, []);
  
  // Features data
  const features = [
    {
      icon: '💼',
      title: 'Post Projects',
      description: 'Easily post your projects and find skilled freelancers to bring your ideas to life.'
    },
    {
      icon: '🚀',
      title: 'Secure Payments',
      description: 'Our escrow payment system ensures secure transactions for both clients and freelancers.'
    },
    {
      icon: '📝',
      title: 'Smart Contracts',
      description: 'Blockchain-based smart contracts for transparent and secure agreements.'
    },
    {
      icon: '💬',
      title: 'Real-time Chat',
      description: 'Communicate with clients and freelancers in real-time through our messaging system.'
    },
    {
      icon: '⭐',
      title: 'Reviews & Ratings',
      description: 'Build your reputation with our comprehensive review and rating system.'
    },
    {
      icon: '🔍',
      title: 'Find Work',
      description: 'Browse through a wide range of projects and find the perfect opportunity for your skills.'
    }
  ];
  
  // Split hero title into spans for animation
  const heroTitle = "Connect. Collaborate. Create.";
  const heroTitleSpans = heroTitle.split(' ').map((word, index) => (
    <span key={index} className="inline-block">
      {word}{' '}
    </span>
  ));
  
  return (
    <div className="relative">
      {/* Hero Section */}
      <motion.section
        ref={targetRef}
        className="relative min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8 py-20"
        style={{ opacity, scale, y }}
      >
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="hero-title text-5xl md:text-7xl font-bold text-white mb-6">
            {heroTitleSpans}
          </h1>
          <p className="hero-subtitle text-xl md:text-2xl text-indigo-200 mb-10 max-w-3xl mx-auto">
            The next-generation freelancing platform powered by blockchain technology.
            Find talent, secure contracts, and build amazing projects together.
          </p>
          <div className="hero-buttons flex flex-col sm:flex-row items-center justify-center gap-4">
            <GlowButton
              as={Link}
              to="/register"
              variant="primary"
              className="px-8 py-3 text-lg"
            >
              Get Started
            </GlowButton>
            <GlowButton
              as={Link}
              to="/projects"
              variant="secondary"
              className="px-8 py-3 text-lg"
            >
              Browse Projects
            </GlowButton>
          </div>
        </div>
      </motion.section>
      
      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">Why Choose SkillSwap?</h2>
            <p className="text-xl text-indigo-200 max-w-3xl mx-auto">
              Our platform offers a unique combination of features designed to make freelancing more secure, transparent, and efficient.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <GlassCard className="h-full p-6">
                  <div className="text-4xl mb-4">{feature.icon}</div>
                  <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
                  <p className="text-indigo-200">{feature.description}</p>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-indigo-900/50 to-purple-900/50">
        <div className="max-w-5xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-6">Ready to start your journey?</h2>
          <p className="text-xl text-indigo-200 mb-10 max-w-3xl mx-auto">
            Join thousands of freelancers and clients already using SkillSwap to bring their projects to life.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <GlowButton
              as={Link}
              to="/register"
              variant="primary"
              className="px-8 py-3 text-lg"
            >
              Sign Up Now
            </GlowButton>
            <GlowButton
              as="a"
              href="#how-it-works"
              variant="secondary"
              className="px-8 py-3 text-lg"
            >
              Learn More
            </GlowButton>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
