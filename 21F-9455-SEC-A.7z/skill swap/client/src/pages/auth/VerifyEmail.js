import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

const VerifyEmail = () => {
  const navigate = useNavigate();
  const { token } = useParams();
  const { verifyEmail } = useAuth();
  
  // Verification states
  const [isLoading, setIsLoading] = useState(true);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState('');
  
  // Verify email token on component mount
  useEffect(() => {
    const verify = async () => {
      if (!token) {
        setError('Invalid or missing verification token');
        setIsLoading(false);
        return;
      }
      
      try {
        await verifyEmail(token);
        setIsSuccess(true);
        
        // Redirect to login after 5 seconds
        setTimeout(() => {
          navigate('/login');
        }, 5000);
      } catch (error) {
        console.error('Email verification error:', error);
        setError('Failed to verify email. The link may have expired or is invalid.');
      } finally {
        setIsLoading(false);
      }
    };
    
    verify();
  }, [token, verifyEmail, navigate]);
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
      },
    },
  };
  
  // Show loading screen while verifying
  if (isLoading) {
    return <LoadingScreen />;
  }
  
  return (
    <div className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8">
      <GlassCard className="w-full max-w-md p-8">
        <motion.div
          className="space-y-8"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div variants={itemVariants} className="text-center">
            {isSuccess ? (
              <>
                <div className="flex justify-center">
                  <div className="rounded-full bg-green-500/20 p-2">
                    <svg
                      className="h-8 w-8 text-green-400"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M5 13l4 4L19 7"
                      />
                    </svg>
                  </div>
                </div>
                <h2 className="mt-6 text-center text-3xl font-extrabold text-white">
                  Email Verified!
                </h2>
                <p className="mt-2 text-center text-sm text-indigo-200">
                  Your email has been successfully verified. You can now log in to your account.
                </p>
                <p className="mt-4 text-indigo-300">
                  Redirecting to login page in 5 seconds...
                </p>
              </>
            ) : (
              <>
                <div className="flex justify-center">
                  <div className="rounded-full bg-red-500/20 p-2">
                    <svg
                      className="h-8 w-8 text-red-400"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M6 18L18 6M6 6l12 12"
                      />
                    </svg>
                  </div>
                </div>
                <h2 className="mt-6 text-center text-3xl font-extrabold text-white">
                  Verification Failed
                </h2>
                <p className="mt-2 text-center text-sm text-indigo-200">
                  {error}
                </p>
              </>
            )}
          </motion.div>
          
          <motion.div variants={itemVariants} className="flex justify-center">
            <GlowButton
              as={Link}
              to="/login"
              variant="primary"
              className="px-8"
            >
              Go to Login
            </GlowButton>
          </motion.div>
          
          {!isSuccess && (
            <motion.div
              variants={itemVariants}
              className="mt-6 text-center text-sm"
            >
              <p className="text-indigo-200">
                If you're having trouble verifying your email, please{' '}
                <Link
                  to="/contact"
                  className="font-medium text-indigo-400 hover:text-indigo-300 transition-colors"
                >
                  contact support
                </Link>
                .
              </p>
            </motion.div>
          )}
        </motion.div>
      </GlassCard>
    </div>
  );
};

export default VerifyEmail;
