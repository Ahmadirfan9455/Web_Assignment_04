import React, { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import LoadingScreen from '../../components/ui/LoadingScreen';

const AuthSuccess = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();
  
  useEffect(() => {
    const handleAuthSuccess = async () => {
      try {
        // Get token from URL query params
        const params = new URLSearchParams(location.search);
        const token = params.get('token');
        
        if (!token) {
          console.error('No token found in URL');
          navigate('/login?error=No authentication token received');
          return;
        }
        
        // Store token and redirect
        await login(token);
        navigate('/dashboard');
      } catch (error) {
        console.error('Error handling auth success:', error);
        navigate('/login?error=Authentication failed');
      }
    };
    
    handleAuthSuccess();
  }, [location, navigate, login]);
  
  return <LoadingScreen message="Completing authentication..." />;
};

export default AuthSuccess;
