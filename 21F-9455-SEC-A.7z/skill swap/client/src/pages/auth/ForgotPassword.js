import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';

const ForgotPassword = () => {
  const { requestPasswordReset } = useAuth();
  
  // Form state
  const [email, setEmail] = useState('');
  
  // Loading and success states
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  
  // Handle input change
  const handleChange = (e) => {
    setEmail(e.target.value);
  };
  
  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate email
    if (!email) {
      toast.error('Please enter your email address');
      return;
    }
    
    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      toast.error('Please enter a valid email address');
      return;
    }
    
    try {
      setIsLoading(true);
      
      // Call requestPasswordReset from auth context
      await requestPasswordReset(email);
      
      // Set success state
      setIsSuccess(true);
    } catch (error) {
      console.error('Password reset request error:', error);
      // Toast notification is handled in the auth context
    } finally {
      setIsLoading(false);
    }
  };
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
      },
    },
  };
  
  return (
    <div className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8">
      <GlassCard className="w-full max-w-md p-8">
        <motion.div
          className="space-y-8"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div variants={itemVariants}>
            <h2 className="mt-6 text-center text-3xl font-extrabold text-white">
              Reset your password
            </h2>
            <p className="mt-2 text-center text-sm text-indigo-200">
              Enter your email address and we'll send you a link to reset your password
            </p>
          </motion.div>
          
          {!isSuccess ? (
            <motion.form
              className="mt-8 space-y-6"
              onSubmit={handleSubmit}
              variants={itemVariants}
            >
              <div className="rounded-md shadow-sm">
                <motion.div variants={itemVariants}>
                  <label htmlFor="email" className="sr-only">
                    Email address
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    required
                    className="appearance-none relative block w-full px-3 py-2 border border-gray-700 bg-gray-900/50 placeholder-gray-400 text-white rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                    placeholder="Email address"
                    value={email}
                    onChange={handleChange}
                  />
                </motion.div>
              </div>
              
              <motion.div variants={itemVariants}>
                <GlowButton
                  type="submit"
                  variant="primary"
                  className="group relative w-full"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <span className="flex items-center justify-center">
                      <svg
                        className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        ></circle>
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        ></path>
                      </svg>
                      Processing...
                    </span>
                  ) : (
                    'Send Reset Link'
                  )}
                </GlowButton>
              </motion.div>
            </motion.form>
          ) : (
            <motion.div
              className="mt-8 space-y-6 text-center"
              variants={itemVariants}
            >
              <div className="flex justify-center">
                <div className="rounded-full bg-green-500/20 p-2">
                  <svg
                    className="h-8 w-8 text-green-400"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M5 13l4 4L19 7"
                    />
                  </svg>
                </div>
              </div>
              <h3 className="text-xl font-medium text-white">Check your email</h3>
              <p className="text-indigo-200">
                We've sent a password reset link to <span className="font-medium text-indigo-400">{email}</span>. Please check your inbox and follow the instructions to reset your password.
              </p>
              <p className="text-indigo-300 text-sm">
                If you don't see the email, check your spam folder.
              </p>
            </motion.div>
          )}
          
          <motion.div
            variants={itemVariants}
            className="mt-6 flex items-center justify-center"
          >
            <div className="text-sm">
              <Link
                to="/login"
                className="font-medium text-indigo-400 hover:text-indigo-300 transition-colors"
              >
                ← Back to login
              </Link>
            </div>
          </motion.div>
        </motion.div>
      </GlassCard>
    </div>
  );
};

export default ForgotPassword;
