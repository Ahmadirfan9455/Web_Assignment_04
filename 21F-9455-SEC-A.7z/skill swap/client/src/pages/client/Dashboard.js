import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

const Dashboard = () => {
  const { user } = useAuth();
  
  // Dashboard data states
  const [projects, setProjects] = useState([]);
  const [contracts, setContracts] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [stats, setStats] = useState({
    activeProjects: 0,
    completedProjects: 0,
    totalSpent: 0,
    averageRating: 0,
  });
  
  // Loading state
  const [isLoading, setIsLoading] = useState(true);
  
  // Fetch dashboard data
  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setIsLoading(true);
        
        // Fetch projects
        const projectsResponse = await axios.get('/api/projects/client');
        setProjects(projectsResponse.data);
        
        // Fetch contracts
        const contractsResponse = await axios.get('/api/contracts/client');
        setContracts(contractsResponse.data);
        
        // Fetch notifications
        const notificationsResponse = await axios.get('/api/notifications');
        setNotifications(notificationsResponse.data);
        
        // Fetch stats
        const statsResponse = await axios.get('/api/stats/client');
        setStats(statsResponse.data);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        toast.error('Failed to load dashboard data. Please try again.');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchDashboardData();
  }, []);
  
  // Mark notification as read
  const markNotificationAsRead = async (notificationId) => {
    try {
      await axios.put(`/api/notifications/${notificationId}/read`);
      
      // Update notifications state
      setNotifications((prev) =>
        prev.map((notification) =>
          notification._id === notificationId
            ? { ...notification, read: true }
            : notification
        )
      );
    } catch (error) {
      console.error('Error marking notification as read:', error);
      toast.error('Failed to mark notification as read.');
    }
  };
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
      },
    },
  };
  
  // Show loading screen while fetching data
  if (isLoading) {
    return <LoadingScreen />;
  }
  
  // Get unread notifications count
  const unreadNotificationsCount = notifications.filter(
    (notification) => !notification.read
  ).length;
  
  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8">
      <motion.div
        className="max-w-7xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Welcome Section */}
        <motion.div variants={itemVariants} className="mb-8">
          <h1 className="text-3xl font-bold text-white">
            Welcome back, {user?.name}!
          </h1>
          <p className="text-indigo-200 mt-2">
            Here's what's happening with your projects today.
          </p>
        </motion.div>
        
        {/* Stats Section */}
        <motion.div variants={itemVariants} className="mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-indigo-300 mb-2">Active Projects</h3>
              <p className="text-3xl font-bold text-white">{stats.activeProjects}</p>
            </GlassCard>
            
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-indigo-300 mb-2">Completed Projects</h3>
              <p className="text-3xl font-bold text-white">{stats.completedProjects}</p>
            </GlassCard>
            
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-indigo-300 mb-2">Total Spent</h3>
              <p className="text-3xl font-bold text-white">${stats.totalSpent.toFixed(2)}</p>
            </GlassCard>
            
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-indigo-300 mb-2">Average Rating</h3>
              <div className="flex items-center">
                <p className="text-3xl font-bold text-white mr-2">{stats.averageRating.toFixed(1)}</p>
                <div className="text-yellow-400 text-xl">★</div>
              </div>
            </GlassCard>
          </div>
        </motion.div>
        
        {/* Quick Actions */}
        <motion.div variants={itemVariants} className="mb-8">
          <h2 className="text-xl font-semibold text-white mb-4">Quick Actions</h2>
          <div className="flex flex-wrap gap-4">
            <GlowButton
              as={Link}
              to="/projects/new"
              variant="primary"
              className="px-4 py-2"
            >
              Post New Project
            </GlowButton>
            
            <GlowButton
              as={Link}
              to="/freelancers"
              variant="secondary"
              className="px-4 py-2"
            >
              Find Freelancers
            </GlowButton>
            
            <GlowButton
              as={Link}
              to="/messages"
              variant="tertiary"
              className="px-4 py-2"
            >
              Messages
              {unreadNotificationsCount > 0 && (
                <span className="ml-2 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-indigo-100 bg-indigo-600 rounded-full">
                  {unreadNotificationsCount}
                </span>
              )}
            </GlowButton>
          </div>
        </motion.div>
        
        {/* Active Projects */}
        <motion.div variants={itemVariants} className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-white">Active Projects</h2>
            <Link
              to="/projects"
              className="text-indigo-400 hover:text-indigo-300 transition-colors"
            >
              View All
            </Link>
          </div>
          
          {projects.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects
                .filter((project) => project.status !== 'completed')
                .slice(0, 3)
                .map((project) => (
                  <GlassCard key={project._id} className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <h3 className="text-lg font-medium text-white">{project.title}</h3>
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        project.status === 'open'
                          ? 'bg-green-500/20 text-green-400'
                          : project.status === 'in-progress'
                          ? 'bg-blue-500/20 text-blue-400'
                          : 'bg-yellow-500/20 text-yellow-400'
                      }`}>
                        {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
                      </span>
                    </div>
                    <p className="text-indigo-200 mb-4 line-clamp-2">{project.description}</p>
                    <div className="flex justify-between items-center">
                      <div className="text-indigo-300">
                        <span className="font-medium">${project.budget}</span>
                        <span className="text-sm"> | {project.bids?.length || 0} bids</span>
                      </div>
                      <Link
                        to={`/projects/${project._id}`}
                        className="text-indigo-400 hover:text-indigo-300 transition-colors"
                      >
                        View Details
                      </Link>
                    </div>
                  </GlassCard>
                ))}
            </div>
          ) : (
            <GlassCard className="p-6 text-center">
              <p className="text-indigo-200 mb-4">You don't have any active projects yet.</p>
              <GlowButton
                as={Link}
                to="/projects/new"
                variant="primary"
                className="px-4 py-2"
              >
                Post Your First Project
              </GlowButton>
            </GlassCard>
          )}
        </motion.div>
        
        {/* Recent Contracts */}
        <motion.div variants={itemVariants} className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-white">Recent Contracts</h2>
            <Link
              to="/contracts"
              className="text-indigo-400 hover:text-indigo-300 transition-colors"
            >
              View All
            </Link>
          </div>
          
          {contracts.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-700">
                <thead>
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                      Project
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                      Freelancer
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                      Amount
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                      Due Date
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-indigo-300 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-700">
                  {contracts.slice(0, 5).map((contract) => (
                    <tr key={contract._id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        {contract.project.title}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        {contract.freelancer.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        ${contract.amount.toFixed(2)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          contract.status === 'active'
                            ? 'bg-green-500/20 text-green-400'
                            : contract.status === 'completed'
                            ? 'bg-blue-500/20 text-blue-400'
                            : 'bg-yellow-500/20 text-yellow-400'
                        }`}>
                          {contract.status.charAt(0).toUpperCase() + contract.status.slice(1)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        {new Date(contract.dueDate).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm">
                        <Link
                          to={`/contracts/${contract._id}`}
                          className="text-indigo-400 hover:text-indigo-300 transition-colors"
                        >
                          View
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <GlassCard className="p-6 text-center">
              <p className="text-indigo-200">You don't have any contracts yet.</p>
            </GlassCard>
          )}
        </motion.div>
        
        {/* Recent Notifications */}
        <motion.div variants={itemVariants}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-white">Recent Notifications</h2>
            <Link
              to="/notifications"
              className="text-indigo-400 hover:text-indigo-300 transition-colors"
            >
              View All
            </Link>
          </div>
          
          {notifications.length > 0 ? (
            <GlassCard className="p-4">
              <ul className="divide-y divide-gray-700">
                {notifications.slice(0, 5).map((notification) => (
                  <li
                    key={notification._id}
                    className={`py-4 ${!notification.read ? 'bg-indigo-900/20' : ''}`}
                  >
                    <div className="flex items-start">
                      <div className="flex-shrink-0 mr-4">
                        <div className={`p-2 rounded-full ${
                          notification.type === 'message'
                            ? 'bg-blue-500/20 text-blue-400'
                            : notification.type === 'bid'
                            ? 'bg-green-500/20 text-green-400'
                            : notification.type === 'contract'
                            ? 'bg-purple-500/20 text-purple-400'
                            : 'bg-yellow-500/20 text-yellow-400'
                        }`}>
                          {notification.type === 'message' ? '💬' :
                           notification.type === 'bid' ? '💰' :
                           notification.type === 'contract' ? '📝' : '🔔'}
                        </div>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-white">
                          {notification.message}
                        </p>
                        <p className="text-xs text-indigo-300 mt-1">
                          {new Date(notification.createdAt).toLocaleString()}
                        </p>
                      </div>
                      {!notification.read && (
                        <button
                          onClick={() => markNotificationAsRead(notification._id)}
                          className="ml-4 text-indigo-400 hover:text-indigo-300 transition-colors"
                        >
                          Mark as read
                        </button>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </GlassCard>
          ) : (
            <GlassCard className="p-6 text-center">
              <p className="text-indigo-200">You don't have any notifications yet.</p>
            </GlassCard>
          )}
        </motion.div>
      </motion.div>
    </div>
  );
};

export default Dashboard;
