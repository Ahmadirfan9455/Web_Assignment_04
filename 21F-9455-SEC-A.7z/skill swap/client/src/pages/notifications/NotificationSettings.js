import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';

const NotificationSettings = () => {
  const { user } = useAuth();
  
  // State
  const [settings, setSettings] = useState({
    email: {
      messages: true,
      projectUpdates: true,
      bids: true,
      contracts: true,
      payments: true,
      reviews: true,
      milestones: true,
      marketing: false
    },
    inApp: {
      messages: true,
      projectUpdates: true,
      bids: true,
      contracts: true,
      payments: true,
      reviews: true,
      milestones: true
    },
    pushNotifications: {
      enabled: false,
      messages: true,
      projectUpdates: true,
      bids: true,
      contracts: true,
      payments: true,
      reviews: true,
      milestones: true
    }
  });
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  
  // Fetch user notification settings
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        setLoading(true);
        const { data } = await axios.get('/api/users/notification-settings');
        
        // If settings exist, update state
        if (data) {
          setSettings(data);
        }
        
        setLoading(false);
      } catch (error) {
        console.error('Error fetching notification settings:', error);
        toast.error('Failed to load notification settings');
        setLoading(false);
      }
    };
    
    fetchSettings();
  }, []);
  
  // Handle toggle change
  const handleToggleChange = (category, setting) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [setting]: !prev[category][setting]
      }
    }));
  };
  
  // Handle save settings
  const handleSaveSettings = async () => {
    try {
      setSaving(true);
      
      await axios.put('/api/users/notification-settings', settings);
      
      toast.success('Notification settings saved successfully!');
      setSaving(false);
    } catch (error) {
      console.error('Error saving notification settings:', error);
      toast.error('Failed to save notification settings');
      setSaving(false);
    }
  };
  
  // Toggle switch component
  const ToggleSwitch = ({ enabled, onChange, label, description }) => (
    <div className="flex items-start justify-between py-3">
      <div>
        <h3 className="text-white font-medium">{label}</h3>
        {description && (
          <p className="text-indigo-300 text-sm mt-1">{description}</p>
        )}
      </div>
      <button
        type="button"
        className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
          enabled ? 'bg-indigo-600' : 'bg-gray-700'
        }`}
        onClick={onChange}
      >
        <span className="sr-only">Toggle {label}</span>
        <span
          className={`pointer-events-none relative inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
            enabled ? 'translate-x-5' : 'translate-x-0'
          }`}
        >
          <span
            className={`absolute inset-0 flex h-full w-full items-center justify-center transition-opacity ${
              enabled ? 'opacity-0 duration-100 ease-out' : 'opacity-100 duration-200 ease-in'
            }`}
          >
            <svg className="h-3 w-3 text-gray-400" fill="none" viewBox="0 0 12 12">
              <path
                d="M4 8l2-2m0 0l2-2M6 6L4 4m2 2l2 2"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </span>
          <span
            className={`absolute inset-0 flex h-full w-full items-center justify-center transition-opacity ${
              enabled ? 'opacity-100 duration-200 ease-in' : 'opacity-0 duration-100 ease-out'
            }`}
          >
            <svg className="h-3 w-3 text-indigo-600" fill="currentColor" viewBox="0 0 12 12">
              <path d="M3.707 5.293a1 1 0 00-1.414 1.414l1.414-1.414zM5 8l-.707.707a1 1 0 001.414 0L5 8zm4.707-3.293a1 1 0 00-1.414-1.414l1.414 1.414zm-7.414 2l2 2 1.414-1.414-2-2-1.414 1.414zm3.414 2l4-4-1.414-1.414-4 4 1.414 1.414z" />
            </svg>
          </span>
        </span>
      </button>
    </div>
  );
  
  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-center items-center p-12">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-white">Notification Settings</h1>
          <p className="text-indigo-300">
            Customize how and when you receive notifications
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Email Notifications */}
          <GlassCard className="p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Email Notifications</h2>
            
            <div className="space-y-1 divide-y divide-gray-700">
              <ToggleSwitch
                label="Messages"
                description="Receive emails for new messages"
                enabled={settings.email.messages}
                onChange={() => handleToggleChange('email', 'messages')}
              />
              
              <ToggleSwitch
                label="Project Updates"
                description="Receive emails for project status changes"
                enabled={settings.email.projectUpdates}
                onChange={() => handleToggleChange('email', 'projectUpdates')}
              />
              
              <ToggleSwitch
                label="Bids"
                description="Receive emails for new bids on your projects"
                enabled={settings.email.bids}
                onChange={() => handleToggleChange('email', 'bids')}
              />
              
              <ToggleSwitch
                label="Contracts"
                description="Receive emails for contract updates"
                enabled={settings.email.contracts}
                onChange={() => handleToggleChange('email', 'contracts')}
              />
              
              <ToggleSwitch
                label="Payments"
                description="Receive emails for payment updates"
                enabled={settings.email.payments}
                onChange={() => handleToggleChange('email', 'payments')}
              />
              
              <ToggleSwitch
                label="Reviews"
                description="Receive emails for new reviews"
                enabled={settings.email.reviews}
                onChange={() => handleToggleChange('email', 'reviews')}
              />
              
              <ToggleSwitch
                label="Milestones"
                description="Receive emails for milestone updates"
                enabled={settings.email.milestones}
                onChange={() => handleToggleChange('email', 'milestones')}
              />
              
              <ToggleSwitch
                label="Marketing"
                description="Receive promotional emails and newsletters"
                enabled={settings.email.marketing}
                onChange={() => handleToggleChange('email', 'marketing')}
              />
            </div>
          </GlassCard>
          
          {/* In-App Notifications */}
          <GlassCard className="p-6">
            <h2 className="text-xl font-semibold text-white mb-4">In-App Notifications</h2>
            
            <div className="space-y-1 divide-y divide-gray-700">
              <ToggleSwitch
                label="Messages"
                description="Receive in-app notifications for new messages"
                enabled={settings.inApp.messages}
                onChange={() => handleToggleChange('inApp', 'messages')}
              />
              
              <ToggleSwitch
                label="Project Updates"
                description="Receive in-app notifications for project status changes"
                enabled={settings.inApp.projectUpdates}
                onChange={() => handleToggleChange('inApp', 'projectUpdates')}
              />
              
              <ToggleSwitch
                label="Bids"
                description="Receive in-app notifications for new bids on your projects"
                enabled={settings.inApp.bids}
                onChange={() => handleToggleChange('inApp', 'bids')}
              />
              
              <ToggleSwitch
                label="Contracts"
                description="Receive in-app notifications for contract updates"
                enabled={settings.inApp.contracts}
                onChange={() => handleToggleChange('inApp', 'contracts')}
              />
              
              <ToggleSwitch
                label="Payments"
                description="Receive in-app notifications for payment updates"
                enabled={settings.inApp.payments}
                onChange={() => handleToggleChange('inApp', 'payments')}
              />
              
              <ToggleSwitch
                label="Reviews"
                description="Receive in-app notifications for new reviews"
                enabled={settings.inApp.reviews}
                onChange={() => handleToggleChange('inApp', 'reviews')}
              />
              
              <ToggleSwitch
                label="Milestones"
                description="Receive in-app notifications for milestone updates"
                enabled={settings.inApp.milestones}
                onChange={() => handleToggleChange('inApp', 'milestones')}
              />
            </div>
          </GlassCard>
          
          {/* Push Notifications */}
          <GlassCard className="p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Push Notifications</h2>
            
            <div className="space-y-1 divide-y divide-gray-700">
              <ToggleSwitch
                label="Enable Push Notifications"
                description="Allow browser notifications on your device"
                enabled={settings.pushNotifications.enabled}
                onChange={() => handleToggleChange('pushNotifications', 'enabled')}
              />
              
              {settings.pushNotifications.enabled && (
                <>
                  <ToggleSwitch
                    label="Messages"
                    description="Receive push notifications for new messages"
                    enabled={settings.pushNotifications.messages}
                    onChange={() => handleToggleChange('pushNotifications', 'messages')}
                  />
                  
                  <ToggleSwitch
                    label="Project Updates"
                    description="Receive push notifications for project status changes"
                    enabled={settings.pushNotifications.projectUpdates}
                    onChange={() => handleToggleChange('pushNotifications', 'projectUpdates')}
                  />
                  
                  <ToggleSwitch
                    label="Bids"
                    description="Receive push notifications for new bids on your projects"
                    enabled={settings.pushNotifications.bids}
                    onChange={() => handleToggleChange('pushNotifications', 'bids')}
                  />
                  
                  <ToggleSwitch
                    label="Contracts"
                    description="Receive push notifications for contract updates"
                    enabled={settings.pushNotifications.contracts}
                    onChange={() => handleToggleChange('pushNotifications', 'contracts')}
                  />
                  
                  <ToggleSwitch
                    label="Payments"
                    description="Receive push notifications for payment updates"
                    enabled={settings.pushNotifications.payments}
                    onChange={() => handleToggleChange('pushNotifications', 'payments')}
                  />
                  
                  <ToggleSwitch
                    label="Reviews"
                    description="Receive push notifications for new reviews"
                    enabled={settings.pushNotifications.reviews}
                    onChange={() => handleToggleChange('pushNotifications', 'reviews')}
                  />
                  
                  <ToggleSwitch
                    label="Milestones"
                    description="Receive push notifications for milestone updates"
                    enabled={settings.pushNotifications.milestones}
                    onChange={() => handleToggleChange('pushNotifications', 'milestones')}
                  />
                </>
              )}
            </div>
          </GlassCard>
        </div>
        
        {/* Save Button */}
        <div className="mt-6 flex justify-end">
          <GlowButton
            variant="primary"
            onClick={handleSaveSettings}
            disabled={saving}
          >
            {saving ? 'Saving...' : 'Save Settings'}
          </GlowButton>
        </div>
      </motion.div>
    </div>
  );
};

export default NotificationSettings;
