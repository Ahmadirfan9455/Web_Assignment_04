import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNotification } from '../../hooks/useNotification';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import NotificationItem from '../../components/notifications/NotificationItem';

const NotificationsPage = () => {
  const { 
    notifications, 
    loading, 
    unreadCount, 
    markAllAsRead, 
    deleteAllNotifications,
    fetchNotifications
  } = useNotification();
  
  // State
  const [activeFilter, setActiveFilter] = useState('all'); // 'all', 'unread', or notification type
  const [searchQuery, setSearchQuery] = useState('');
  
  // Refresh notifications on mount
  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);
  
  // Handle mark all as read
  const handleMarkAllAsRead = async () => {
    await markAllAsRead();
  };
  
  // Handle clear all notifications
  const handleClearAll = async () => {
    await deleteAllNotifications();
  };
  
  // Get all notification types
  const getNotificationTypes = () => {
    const types = new Set();
    notifications.forEach(notification => {
      if (notification.type) {
        types.add(notification.type);
      }
    });
    return Array.from(types);
  };
  
  // Filter notifications
  const filteredNotifications = notifications.filter(notification => {
    // Filter by type or read status
    if (activeFilter === 'all') {
      // No filter
    } else if (activeFilter === 'unread') {
      if (notification.read) return false;
    } else if (notification.type !== activeFilter) {
      return false;
    }
    
    // Filter by search query
    if (searchQuery) {
      return notification.message.toLowerCase().includes(searchQuery.toLowerCase());
    }
    
    return true;
  });
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05
      }
    }
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <h1 className="text-2xl font-bold text-white">Notifications</h1>
            <p className="text-indigo-300">
              Stay updated with your latest activities
            </p>
          </div>
          
          <div className="mt-4 md:mt-0 flex space-x-3">
            {unreadCount > 0 && (
              <GlowButton
                variant="secondary"
                onClick={handleMarkAllAsRead}
              >
                Mark All as Read
              </GlowButton>
            )}
            
            {notifications.length > 0 && (
              <GlowButton
                variant="primary"
                onClick={handleClearAll}
              >
                Clear All
              </GlowButton>
            )}
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="md:col-span-1">
            <GlassCard className="p-4">
              <h2 className="text-lg font-medium text-white mb-4">Filters</h2>
              
              <div className="space-y-2">
                <button
                  className={`w-full text-left px-3 py-2 rounded-md ${
                    activeFilter === 'all'
                      ? 'bg-indigo-600 text-white'
                      : 'text-indigo-300 hover:bg-gray-800'
                  }`}
                  onClick={() => setActiveFilter('all')}
                >
                  All Notifications
                </button>
                
                <button
                  className={`w-full text-left px-3 py-2 rounded-md ${
                    activeFilter === 'unread'
                      ? 'bg-indigo-600 text-white'
                      : 'text-indigo-300 hover:bg-gray-800'
                  }`}
                  onClick={() => setActiveFilter('unread')}
                >
                  Unread
                  {unreadCount > 0 && (
                    <span className="ml-2 bg-indigo-900 text-white text-xs px-2 py-0.5 rounded-full">
                      {unreadCount}
                    </span>
                  )}
                </button>
                
                <div className="pt-2 border-t border-gray-700">
                  <h3 className="text-sm font-medium text-indigo-400 mb-2">By Type</h3>
                  
                  {getNotificationTypes().map(type => (
                    <button
                      key={type}
                      className={`w-full text-left px-3 py-2 rounded-md ${
                        activeFilter === type
                          ? 'bg-indigo-600 text-white'
                          : 'text-indigo-300 hover:bg-gray-800'
                      }`}
                      onClick={() => setActiveFilter(type)}
                    >
                      {type.charAt(0).toUpperCase() + type.slice(1)}
                    </button>
                  ))}
                </div>
              </div>
            </GlassCard>
          </div>
          
          {/* Main Content */}
          <div className="md:col-span-3">
            <GlassCard className="p-4">
              {/* Search */}
              <div className="mb-4">
                <div className="relative">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search notifications..."
                    className="w-full px-4 py-2 pl-10 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  />
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                    </svg>
                  </div>
                </div>
              </div>
              
              {/* Notifications List */}
              {loading ? (
                <div className="flex justify-center items-center p-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
                </div>
              ) : filteredNotifications.length > 0 ? (
                <motion.div
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  className="divide-y divide-gray-700"
                >
                  {filteredNotifications.map(notification => (
                    <NotificationItem 
                      key={notification._id} 
                      notification={notification}
                    />
                  ))}
                </motion.div>
              ) : (
                <div className="p-12 text-center">
                  <svg className="w-16 h-16 text-indigo-400 mx-auto mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path>
                  </svg>
                  <p className="text-indigo-300 text-lg">No notifications found</p>
                  {searchQuery && (
                    <p className="text-indigo-400 mt-2">
                      Try adjusting your search or filters
                    </p>
                  )}
                </div>
              )}
            </GlassCard>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default NotificationsPage;
