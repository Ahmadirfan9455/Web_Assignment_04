import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import { useSocket } from '../../hooks/useSocket';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

const Messages = () => {
  const { user } = useAuth();
  const { 
    socket, 
    sendTypingIndicator, 
    isTyping,
    isOnline 
  } = useSocket();
  const navigate = useNavigate();
  const location = useLocation();
  const messageEndRef = useRef(null);
  const messageInputRef = useRef(null);
  
  // Get recipient from query params if available
  const queryParams = new URLSearchParams(location.search);
  const recipientIdFromQuery = queryParams.get('recipient');
  
  // State for conversations and messages
  const [conversations, setConversations] = useState([]);
  const [messages, setMessages] = useState([]);
  const [activeConversation, setActiveConversation] = useState(null);
  const [messageInput, setMessageInput] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredConversations, setFilteredConversations] = useState([]);
  
  // Fetch conversations
  useEffect(() => {
    const fetchConversations = async () => {
      try {
        setIsLoading(true);
        const response = await axios.get('/api/messages');
        
        // Ensure we have valid data
        if (!response.data || !Array.isArray(response.data)) {
          console.log('Invalid conversation data format:', response.data);
          setConversations([]);
          setFilteredConversations([]);
          setIsLoading(false);
          return;
        }
        
        setConversations(response.data);
        setFilteredConversations(response.data);
        
        // If recipient ID is provided in query params, find or create that conversation
        if (recipientIdFromQuery) {
          const existingConversation = response.data.find(
            conv => conv.user && conv.user._id === recipientIdFromQuery
          );
          
          if (existingConversation) {
            setActiveConversation(existingConversation);
            // Load messages for this conversation
            loadMessages(existingConversation.user._id);
          } else {
            // Fetch recipient info
            try {
              const userResponse = await axios.get(`/api/users/${recipientIdFromQuery}`);
              const recipient = userResponse.data;
              
              // Create a new conversation object (not saved to DB yet)
              const newConversation = {
                user: {
                  _id: recipient._id,
                  name: recipient.name,
                  email: recipient.email
                },
                lastMessage: null,
                unreadCount: 0,
                isNew: true
              };
              
              setConversations(prev => [newConversation, ...prev]);
              setFilteredConversations(prev => [newConversation, ...prev]);
              setActiveConversation(newConversation);
            } catch (error) {
              console.error('Error fetching recipient:', error);
              // Don't show error toast to avoid overwhelming the user
            }
          }
        } else if (response.data.length > 0) {
          // Set first conversation as active if no recipient specified
          setActiveConversation(response.data[0]);
          if (response.data[0].user && response.data[0].user._id) {
            loadMessages(response.data[0].user._id);
          }
        }
      } catch (error) {
        console.error('Error fetching conversations:', error);
        // Don't show error toast to avoid overwhelming the user
        setConversations([]);
        setFilteredConversations([]);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchConversations();
  }, [recipientIdFromQuery]);
  
  // Fetch messages for active conversation
  useEffect(() => {
    const fetchMessages = async () => {
      if (!activeConversation || activeConversation.isNew) {
        setMessages([]);
        return;
      }
      
      try {
        const response = await axios.get(`/api/messages/conversations/${activeConversation.user._id}`);
        setMessages(response.data);
        
        // Mark messages as read
        if (activeConversation.unreadCount > 0) {
          await axios.put(`/api/messages/conversations/${activeConversation.user._id}/read`);
          
          // Update conversation in state
          setConversations(prev => 
            prev.map(conv => 
              conv.user._id === activeConversation.user._id 
                ? { ...conv, unreadCount: 0 } 
                : conv
            )
          );
          
          setFilteredConversations(prev => 
            prev.map(conv => 
              conv.user._id === activeConversation.user._id 
                ? { ...conv, unreadCount: 0 } 
                : conv
            )
          );
        }
      } catch (error) {
        console.error('Error fetching messages:', error);
        toast.error('Failed to load messages');
      }
    };
    
    if (activeConversation) {
      fetchMessages();
    }
  }, [activeConversation]);
  
  // Socket event listeners for real-time messaging
  useEffect(() => {
    if (!socket) return;
    
    // Handle incoming message
    const handleNewMessage = (message) => {
      // Check if message belongs to active conversation
      if (activeConversation && 
          (message.conversationId === activeConversation.user._id || 
           message.conversation.user._id === activeConversation.user._id)) {
        
        setMessages(prev => [...prev, message]);
        
        // Mark as read immediately if it's the active conversation
        axios.put(`/api/messages/conversations/${message.conversationId || message.conversation.user._id}/read`)
          .catch(error => console.error('Error marking message as read:', error));
        
        // Update conversation in state
        setConversations(prev => 
          prev.map(conv => 
            conv.user._id === (message.conversationId || message.conversation.user._id)
              ? { 
                  ...conv, 
                  lastMessage: message,
                  unreadCount: 0
                } 
              : conv
          )
        );
        
        setFilteredConversations(prev => 
          prev.map(conv => 
            conv.user._id === (message.conversationId || message.conversation.user._id)
              ? { 
                  ...conv, 
                  lastMessage: message,
                  unreadCount: 0
                } 
              : conv
          )
        );
      } else {
        // Update conversation with unread count
        setConversations(prev => {
          const updatedConversations = prev.map(conv => 
            conv.user._id === (message.conversationId || message.conversation.user._id)
              ? { 
                  ...conv, 
                  lastMessage: message,
                  unreadCount: (conv.unreadCount || 0) + 1
                } 
              : conv
          );
          
          // If conversation doesn't exist yet, add it
          if (!updatedConversations.some(conv => 
              conv.user._id === (message.conversationId || message.conversation.user._id))) {
            
            return [message.conversation, ...updatedConversations];
          }
          
          return updatedConversations;
        });
        
        setFilteredConversations(prev => {
          const updatedConversations = prev.map(conv => 
            conv.user._id === (message.conversationId || message.conversation.user._id)
              ? { 
                  ...conv, 
                  lastMessage: message,
                  unreadCount: (conv.unreadCount || 0) + 1
                } 
              : conv
          );
          
          // If conversation doesn't exist yet, add it
          if (!updatedConversations.some(conv => 
              conv.user._id === (message.conversationId || message.conversation.user._id))) {
            
            return [message.conversation, ...updatedConversations];
          }
          
          return updatedConversations;
        });
      }
    };
    
    socket.on('message', handleNewMessage);
    
    return () => {
      socket.off('message', handleNewMessage);
    };
  }, [socket, activeConversation]);
  
  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messageEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  // Focus input when active conversation changes
  useEffect(() => {
    messageInputRef.current?.focus();
  }, [activeConversation]);
  
  // Filter conversations based on search query
  useEffect(() => {
    if (!searchQuery.trim()) {
      setFilteredConversations(conversations);
      return;
    }
    
    const query = searchQuery.toLowerCase();
    const filtered = conversations.filter(conv => {
      const participantMatch = conv.user && conv.user.name.toLowerCase().includes(query);
      
      const messageMatch = conv.lastMessage && 
        conv.lastMessage.content.toLowerCase().includes(query);
      
      return participantMatch || messageMatch;
    });
    
    setFilteredConversations(filtered);
  }, [searchQuery, conversations]);
  
  // Handle conversation selection
  const handleSelectConversation = (conversation) => {
    setActiveConversation(conversation);
    
    // Clear recipient from URL if it exists
    if (recipientIdFromQuery) {
      navigate('/messages');
    }
  };
  
  // Handle message input change
  const handleMessageChange = (e) => {
    setMessageInput(e.target.value);
    
    // Send typing indicator
    if (activeConversation && !activeConversation.isNew) {
      sendTypingIndicator(activeConversation.user._id, e.target.value.length > 0);
    }
  };
  
  // Send message
  const handleSendMessage = async (e) => {
    e.preventDefault();
    
    if (!messageInput.trim()) return;
    
    try {
      setIsSending(true);
      
      let conversationId = activeConversation.user._id;
      
      // If this is a new conversation, create it first
      if (activeConversation.isNew) {
        const recipientId = activeConversation.user._id;
        const newConvResponse = await axios.post('/api/messages/conversations', {
          recipientId
        });
        
        conversationId = newConvResponse.data.user._id;
        
        // Update the active conversation
        const updatedConversation = {
          ...activeConversation,
          user: {
            _id: conversationId,
            name: activeConversation.user.name,
            email: activeConversation.user.email
          },
          isNew: false
        };
        
        setActiveConversation(updatedConversation);
        
        // Update conversations list
        setConversations(prev => 
          prev.map(conv => 
            conv.user._id === activeConversation.user._id
              ? updatedConversation
              : conv
          )
        );
        
        setFilteredConversations(prev => 
          prev.map(conv => 
            conv.user._id === activeConversation.user._id
              ? updatedConversation
              : conv
          )
        );
      }
      
      // Send message
      const response = await axios.post(`/api/messages/conversations/${conversationId}`, {
        content: messageInput
      });
      
      // Add message to state
      setMessages(prev => [...prev, response.data]);
      
      // Update conversation in state
      const updatedConversation = {
        ...activeConversation,
        lastMessage: response.data,
        updatedAt: new Date().toISOString()
      };
      
      setActiveConversation(updatedConversation);
      
      // Update conversations list and sort by most recent
      setConversations(prev => {
        const updated = prev.map(conv => 
          conv.user._id === updatedConversation.user._id
            ? updatedConversation
            : conv
        );
        
        return updated.sort((a, b) => 
          new Date(b.updatedAt || b.createdAt) - new Date(a.updatedAt || a.createdAt)
        );
      });
      
      setFilteredConversations(prev => {
        const updated = prev.map(conv => 
          conv.user._id === updatedConversation.user._id
            ? updatedConversation
            : conv
        );
        
        return updated.sort((a, b) => 
          new Date(b.updatedAt || b.createdAt) - new Date(a.updatedAt || a.createdAt)
        );
      });
      
      // Clear input
      setMessageInput('');
      
      // Stop typing indicator
      if (!activeConversation.isNew) {
        sendTypingIndicator(conversationId, false);
      }
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error('Failed to send message');
    } finally {
      setIsSending(false);
    }
  };
  
  // Get other participant in conversation
  const getOtherParticipant = (conversation) => {
    if (!conversation || !conversation.user) return null;
    return conversation.user || null;
  };
  
  // Format timestamp
  const formatMessageTime = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffDays = Math.floor((now - date) / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      // Today, show time
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diffDays === 1) {
      // Yesterday
      return 'Yesterday';
    } else if (diffDays < 7) {
      // Within a week, show day name
      return date.toLocaleDateString([], { weekday: 'short' });
    } else {
      // Older, show date
      return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
      },
    },
  };
  
  // Show loading screen while fetching data
  if (isLoading) {
    return <LoadingScreen />;
  }
  
  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8">
      <motion.div
        className="max-w-7xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants} className="mb-8">
          <h1 className="text-3xl font-bold text-white">Messages</h1>
          <p className="text-indigo-200 mt-2">
            Communicate with clients and freelancers in real-time
          </p>
        </motion.div>
        
        <motion.div variants={itemVariants}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-[calc(100vh-250px)] min-h-[500px]">
            {/* Conversations List */}
            <GlassCard className="p-4 md:col-span-1 flex flex-col h-full">
              <div className="mb-4">
                <input
                  type="text"
                  placeholder="Search conversations..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>
              
              <div className="flex-grow overflow-y-auto">
                {filteredConversations.length > 0 ? (
                  <ul className="space-y-2">
                    {filteredConversations.map((conversation) => {
                      const otherParticipant = getOtherParticipant(conversation);
                      if (!otherParticipant) return null;
                      
                      return (
                        <li
                          key={conversation.user._id}
                          onClick={() => handleSelectConversation(conversation)}
                          className={`p-3 rounded-md cursor-pointer transition-colors ${
                            activeConversation && activeConversation.user._id === conversation.user._id
                              ? 'bg-indigo-900/50'
                              : 'hover:bg-gray-800/50'
                          } ${conversation.unreadCount > 0 ? 'bg-indigo-900/20' : ''}`}
                        >
                          <div className="flex items-start">
                            <div className="relative flex-shrink-0 mr-3">
                              <div className="w-10 h-10 bg-indigo-700 rounded-full flex items-center justify-center">
                                <span className="text-white font-medium">
                                  {otherParticipant.name.charAt(0).toUpperCase()}
                                </span>
                              </div>
                              {isOnline(otherParticipant._id) && (
                                <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-gray-900"></span>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex justify-between">
                                <p className="text-sm font-medium text-white truncate">
                                  {otherParticipant.name}
                                </p>
                                {conversation.lastMessage && (
                                  <p className="text-xs text-indigo-300">
                                    {formatMessageTime(conversation.lastMessage.createdAt)}
                                  </p>
                                )}
                              </div>
                              {conversation.lastMessage ? (
                                <p className="text-xs text-indigo-200 truncate">
                                  {conversation.lastMessage.sender === user._id ? 'You: ' : ''}
                                  {conversation.lastMessage.content}
                                </p>
                              ) : (
                                <p className="text-xs text-indigo-300 italic">
                                  No messages yet
                                </p>
                              )}
                            </div>
                            {conversation.unreadCount > 0 && (
                              <div className="ml-2 bg-indigo-600 rounded-full w-5 h-5 flex items-center justify-center">
                                <span className="text-xs text-white font-bold">
                                  {conversation.unreadCount}
                                </span>
                              </div>
                            )}
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-indigo-300 mb-4">No conversations found</p>
                    <Link to="/freelancers">
                      <GlowButton variant="primary" className="px-4 py-2">
                        Find Freelancers
                      </GlowButton>
                    </Link>
                  </div>
                )}
              </div>
            </GlassCard>
            
            {/* Message Area */}
            <GlassCard className="p-4 md:col-span-2 flex flex-col h-full">
              {activeConversation ? (
                <>
                  {/* Conversation Header */}
                  <div className="border-b border-gray-700 pb-3 mb-4">
                    <div className="flex items-center">
                      <div className="relative mr-3">
                        <div className="w-10 h-10 bg-indigo-700 rounded-full flex items-center justify-center">
                          <span className="text-white font-medium">
                            {getOtherParticipant(activeConversation)?.name.charAt(0).toUpperCase()}
                          </span>
                        </div>
                        {isOnline(getOtherParticipant(activeConversation)?._id) && (
                          <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-gray-900"></span>
                        )}
                      </div>
                      <div>
                        <h3 className="text-lg font-medium text-white">
                          {getOtherParticipant(activeConversation)?.name}
                        </h3>
                        <p className="text-xs text-indigo-300">
                          {isOnline(getOtherParticipant(activeConversation)?._id)
                            ? 'Online'
                            : 'Offline'}
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Messages */}
                  <div className="flex-grow overflow-y-auto mb-4 space-y-4">
                    {messages.length > 0 ? (
                      messages.map((message) => (
                        <div
                          key={message._id}
                          className={`flex ${
                            message.sender === user._id ? 'justify-end' : 'justify-start'
                          }`}
                        >
                          <div
                            className={`max-w-[80%] rounded-lg px-4 py-2 ${
                              message.sender === user._id
                                ? 'bg-indigo-600 text-white'
                                : 'bg-gray-800 text-white'
                            }`}
                          >
                            <p>{message.content}</p>
                            <p className="text-xs opacity-70 text-right mt-1">
                              {formatMessageTime(message.createdAt)}
                            </p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8">
                        <p className="text-indigo-300">
                          No messages yet. Start the conversation!
                        </p>
                      </div>
                    )}
                    
                    {/* Typing indicator */}
                    {isTyping(getOtherParticipant(activeConversation)?._id, activeConversation.user._id) && (
                      <div className="flex justify-start">
                        <div className="bg-gray-800 rounded-lg px-4 py-2">
                          <div className="flex space-x-1">
                            <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                            <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                            <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    <div ref={messageEndRef} />
                  </div>
                  
                  {/* Message Input */}
                  <form onSubmit={handleSendMessage} className="flex items-center">
                    <input
                      type="text"
                      ref={messageInputRef}
                      value={messageInput}
                      onChange={handleMessageChange}
                      placeholder="Type a message..."
                      className="flex-grow px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-l-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    />
                    <button
                      type="submit"
                      disabled={isSending || !messageInput.trim()}
                      className="px-4 py-2 bg-indigo-600 text-white rounded-r-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isSending ? (
                        <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                      ) : (
                        <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                        </svg>
                      )}
                    </button>
                  </form>
                </>
              ) : (
                <div className="flex flex-col items-center justify-center h-full">
                  <div className="text-center">
                    <svg className="h-16 w-16 text-indigo-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                    </svg>
                    <h3 className="text-xl font-medium text-white mb-2">Your Messages</h3>
                    <p className="text-indigo-300 mb-6">
                      Select a conversation or start a new one
                    </p>
                    <Link to="/freelancers">
                      <GlowButton variant="primary" className="px-4 py-2">
                        Find Freelancers
                      </GlowButton>
                    </Link>
                  </div>
                </div>
              )}
            </GlassCard>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default Messages;
