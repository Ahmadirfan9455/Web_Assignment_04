import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

const FreelancerDashboard = () => {
  const { user } = useAuth();
  
  // Dashboard data states
  const [projects, setProjects] = useState([]);
  const [bids, setBids] = useState([]);
  const [contracts, setContracts] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [stats, setStats] = useState({
    activeContracts: 0,
    completedProjects: 0,
    totalEarned: 0,
    averageRating: 0,
    bidSuccessRate: 0,
  });
  
  // Loading state
  const [isLoading, setIsLoading] = useState(true);
  
  // Fetch dashboard data
  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setIsLoading(true);
        
        // Fetch projects with active bids
        const projectsResponse = await axios.get('/api/projects/freelancer/bids');
        setProjects(projectsResponse.data);
        
        // Fetch all bids
        const bidsResponse = await axios.get('/api/bids/freelancer');
        setBids(bidsResponse.data);
        
        // Fetch contracts
        const contractsResponse = await axios.get('/api/contracts/freelancer');
        setContracts(contractsResponse.data);
        
        // Fetch notifications
        const notificationsResponse = await axios.get('/api/notifications');
        setNotifications(notificationsResponse.data);
        
        // Fetch stats
        const statsResponse = await axios.get('/api/stats/freelancer');
        setStats(statsResponse.data);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        toast.error('Failed to load dashboard data. Please try again.');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchDashboardData();
  }, []);
  
  // Mark notification as read
  const markNotificationAsRead = async (notificationId) => {
    try {
      await axios.put(`/api/notifications/${notificationId}/read`);
      
      // Update notifications state
      setNotifications((prev) =>
        prev.map((notification) =>
          notification._id === notificationId
            ? { ...notification, read: true }
            : notification
        )
      );
    } catch (error) {
      console.error('Error marking notification as read:', error);
      toast.error('Failed to mark notification as read.');
    }
  };
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
      },
    },
  };
  
  // Show loading screen while fetching data
  if (isLoading) {
    return <LoadingScreen />;
  }
  
  // Get unread notifications count
  const unreadNotificationsCount = notifications.filter(
    (notification) => !notification.read
  ).length;
  
  // Get active contracts
  const activeContracts = contracts.filter(
    (contract) => contract.status === 'active'
  );
  
  // Get pending bids
  const pendingBids = bids.filter(
    (bid) => bid.status === 'pending'
  );
  
  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8">
      <motion.div
        className="max-w-7xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Welcome Section */}
        <motion.div variants={itemVariants} className="mb-8">
          <h1 className="text-3xl font-bold text-white">
            Welcome back, {user?.name}!
          </h1>
          <p className="text-indigo-200 mt-2">
            Here's what's happening with your freelancing business today.
          </p>
        </motion.div>
        
        {/* Stats Section */}
        <motion.div variants={itemVariants} className="mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-indigo-300 mb-2">Active Contracts</h3>
              <p className="text-3xl font-bold text-white">{stats.activeContracts}</p>
            </GlassCard>
            
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-indigo-300 mb-2">Completed Projects</h3>
              <p className="text-3xl font-bold text-white">{stats.completedProjects}</p>
            </GlassCard>
            
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-indigo-300 mb-2">Total Earned</h3>
              <p className="text-3xl font-bold text-white">${stats.totalEarned.toFixed(2)}</p>
            </GlassCard>
            
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-indigo-300 mb-2">Average Rating</h3>
              <div className="flex items-center">
                <p className="text-3xl font-bold text-white mr-2">{stats.averageRating.toFixed(1)}</p>
                <div className="text-yellow-400 text-xl">★</div>
              </div>
            </GlassCard>
            
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-indigo-300 mb-2">Bid Success Rate</h3>
              <p className="text-3xl font-bold text-white">{stats.bidSuccessRate}%</p>
            </GlassCard>
          </div>
        </motion.div>
        
        {/* Quick Actions */}
        <motion.div variants={itemVariants} className="mb-8">
          <h2 className="text-xl font-semibold text-white mb-4">Quick Actions</h2>
          <div className="flex flex-wrap gap-4">
            <GlowButton
              as={Link}
              to="/projects/browse"
              variant="primary"
              className="px-4 py-2"
            >
              Find Projects
            </GlowButton>
            
            <GlowButton
              as={Link}
              to="/freelancer/profile"
              variant="secondary"
              className="px-4 py-2"
            >
              Update Profile
            </GlowButton>
            
            <GlowButton
              as={Link}
              to="/messages"
              variant="tertiary"
              className="px-4 py-2"
            >
              Messages
              {unreadNotificationsCount > 0 && (
                <span className="ml-2 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-indigo-100 bg-indigo-600 rounded-full">
                  {unreadNotificationsCount}
                </span>
              )}
            </GlowButton>
          </div>
        </motion.div>
        
        {/* Active Contracts */}
        <motion.div variants={itemVariants} className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-white">Active Contracts</h2>
            <Link
              to="/freelancer/contracts"
              className="text-indigo-400 hover:text-indigo-300 transition-colors"
            >
              View All
            </Link>
          </div>
          
          {activeContracts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {activeContracts.slice(0, 3).map((contract) => (
                <GlassCard key={contract._id} className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-lg font-medium text-white">{contract.project.title}</h3>
                    <span className="px-2 py-1 text-xs rounded-full bg-green-500/20 text-green-400">
                      Active
                    </span>
                  </div>
                  <p className="text-indigo-200 mb-4 line-clamp-2">{contract.project.description}</p>
                  <div className="flex justify-between items-center mb-4">
                    <div className="text-indigo-300">
                      <span className="font-medium">${contract.amount.toFixed(2)}</span>
                    </div>
                    <div className="text-indigo-300 text-sm">
                      Due: {new Date(contract.dueDate).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="text-sm text-indigo-300">
                      Client: {contract.client.name}
                    </div>
                    <Link
                      to={`/contracts/${contract._id}`}
                      className="text-indigo-400 hover:text-indigo-300 transition-colors"
                    >
                      View Details
                    </Link>
                  </div>
                </GlassCard>
              ))}
            </div>
          ) : (
            <GlassCard className="p-6 text-center">
              <p className="text-indigo-200 mb-4">You don't have any active contracts yet.</p>
              <GlowButton
                as={Link}
                to="/projects/browse"
                variant="primary"
                className="px-4 py-2"
              >
                Find Projects to Bid On
              </GlowButton>
            </GlassCard>
          )}
        </motion.div>
        
        {/* Pending Bids */}
        <motion.div variants={itemVariants} className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-white">Pending Bids</h2>
            <Link
              to="/freelancer/bids"
              className="text-indigo-400 hover:text-indigo-300 transition-colors"
            >
              View All
            </Link>
          </div>
          
          {pendingBids.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-700">
                <thead>
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                      Project
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                      Client
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                      Bid Amount
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                      Project Budget
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                      Submitted
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-indigo-300 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-700">
                  {pendingBids.slice(0, 5).map((bid) => (
                    <tr key={bid._id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        {bid.project.title}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        {bid.project.client.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        ${bid.amount.toFixed(2)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        ${bid.project.budget.toFixed(2)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        {new Date(bid.createdAt).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm">
                        <Link
                          to={`/projects/${bid.project._id}`}
                          className="text-indigo-400 hover:text-indigo-300 transition-colors"
                        >
                          View Project
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <GlassCard className="p-6 text-center">
              <p className="text-indigo-200">You don't have any pending bids.</p>
            </GlassCard>
          )}
        </motion.div>
        
        {/* Recommended Projects */}
        <motion.div variants={itemVariants} className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-white">Recommended Projects</h2>
            <Link
              to="/projects/browse"
              className="text-indigo-400 hover:text-indigo-300 transition-colors"
            >
              Browse All
            </Link>
          </div>
          
          {projects.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.slice(0, 3).map((project) => (
                <GlassCard key={project._id} className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-lg font-medium text-white">{project.title}</h3>
                    <span className="px-2 py-1 text-xs rounded-full bg-green-500/20 text-green-400">
                      Open
                    </span>
                  </div>
                  <p className="text-indigo-200 mb-4 line-clamp-2">{project.description}</p>
                  <div className="flex justify-between items-center mb-4">
                    <div className="text-indigo-300">
                      <span className="font-medium">${project.budget.toFixed(2)}</span>
                    </div>
                    <div className="text-indigo-300 text-sm">
                      {project.bids.length} bids
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.skills.slice(0, 3).map((skill, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 text-xs rounded-full bg-indigo-900/50 text-indigo-300"
                      >
                        {skill}
                      </span>
                    ))}
                    {project.skills.length > 3 && (
                      <span className="px-2 py-1 text-xs rounded-full bg-indigo-900/50 text-indigo-300">
                        +{project.skills.length - 3} more
                      </span>
                    )}
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="text-sm text-indigo-300">
                      Posted: {new Date(project.createdAt).toLocaleDateString()}
                    </div>
                    <Link
                      to={`/projects/${project._id}`}
                      className="text-indigo-400 hover:text-indigo-300 transition-colors"
                    >
                      View Details
                    </Link>
                  </div>
                </GlassCard>
              ))}
            </div>
          ) : (
            <GlassCard className="p-6 text-center">
              <p className="text-indigo-200">No recommended projects available at the moment.</p>
            </GlassCard>
          )}
        </motion.div>
        
        {/* Recent Notifications */}
        <motion.div variants={itemVariants}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-white">Recent Notifications</h2>
            <Link
              to="/notifications"
              className="text-indigo-400 hover:text-indigo-300 transition-colors"
            >
              View All
            </Link>
          </div>
          
          {notifications.length > 0 ? (
            <GlassCard className="p-4">
              <ul className="divide-y divide-gray-700">
                {notifications.slice(0, 5).map((notification) => (
                  <li
                    key={notification._id}
                    className={`py-4 ${!notification.read ? 'bg-indigo-900/20' : ''}`}
                  >
                    <div className="flex items-start">
                      <div className="flex-shrink-0 mr-4">
                        <div className={`p-2 rounded-full ${
                          notification.type === 'message'
                            ? 'bg-blue-500/20 text-blue-400'
                            : notification.type === 'bid'
                            ? 'bg-green-500/20 text-green-400'
                            : notification.type === 'contract'
                            ? 'bg-purple-500/20 text-purple-400'
                            : 'bg-yellow-500/20 text-yellow-400'
                        }`}>
                          {notification.type === 'message' ? '💬' :
                           notification.type === 'bid' ? '💰' :
                           notification.type === 'contract' ? '📝' : '🔔'}
                        </div>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-white">
                          {notification.message}
                        </p>
                        <p className="text-xs text-indigo-300 mt-1">
                          {new Date(notification.createdAt).toLocaleString()}
                        </p>
                      </div>
                      {!notification.read && (
                        <button
                          onClick={() => markNotificationAsRead(notification._id)}
                          className="ml-4 text-indigo-400 hover:text-indigo-300 transition-colors"
                        >
                          Mark as read
                        </button>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </GlassCard>
          ) : (
            <GlassCard className="p-6 text-center">
              <p className="text-indigo-200">You don't have any notifications yet.</p>
            </GlassCard>
          )}
        </motion.div>
      </motion.div>
    </div>
  );
};

export default FreelancerDashboard;
