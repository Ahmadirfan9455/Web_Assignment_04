import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

const PlatformSettings = () => {
  // State
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('general');
  const [settings, setSettings] = useState({
    general: {
      platformName: 'SkillSwap',
      platformLogo: '',
      contactEmail: 'support@skillswap.com',
      maintenanceMode: false,
      allowUserRegistration: true
    },
    fees: {
      platformFeePercentage: 10,
      minimumWithdrawalAmount: 50,
      paymentProcessingFee: 2.9,
      featuredProjectFee: 25
    },
    security: {
      twoFactorAuthRequired: false,
      passwordExpiryDays: 90,
      maxLoginAttempts: 5,
      sessionTimeoutMinutes: 60
    },
    notifications: {
      enableEmailNotifications: true,
      enableInAppNotifications: true,
      adminEmailRecipients: '',
      notificationFrequency: 'immediate'
    },
    content: {
      termsOfService: '',
      privacyPolicy: '',
      aboutUs: '',
      faq: ''
    }
  });

  // Fetch settings
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        setLoading(true);
        const { data } = await axios.get('/api/admin/settings');
        setSettings(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching settings:', error);
        toast.error('Failed to load platform settings');
        setLoading(false);
      }
    };

    fetchSettings();
  }, []);

  // Handle input change
  const handleInputChange = (section, field, value) => {
    setSettings(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value
      }
    }));
  };

  // Handle toggle change
  const handleToggleChange = (section, field) => {
    setSettings(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: !prev[section][field]
      }
    }));
  };

  // Save settings
  const saveSettings = async () => {
    try {
      setSaving(true);
      await axios.put('/api/admin/settings', settings);
      toast.success('Settings saved successfully');
      setSaving(false);
    } catch (error) {
      console.error('Error saving settings:', error);
      toast.error('Failed to save settings');
      setSaving(false);
    }
  };

  // Tab navigation
  const renderTabContent = () => {
    switch (activeTab) {
      case 'general':
        return renderGeneralSettings();
      case 'fees':
        return renderFeesSettings();
      case 'security':
        return renderSecuritySettings();
      case 'notifications':
        return renderNotificationSettings();
      case 'content':
        return renderContentSettings();
      default:
        return renderGeneralSettings();
    }
  };

  // General settings form
  const renderGeneralSettings = () => (
    <div className="space-y-6">
      <div>
        <label className="block text-indigo-300 text-sm font-medium mb-2">
          Platform Name
        </label>
        <input
          type="text"
          value={settings.general.platformName}
          onChange={(e) => handleInputChange('general', 'platformName', e.target.value)}
          className="w-full px-4 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>

      <div>
        <label className="block text-indigo-300 text-sm font-medium mb-2">
          Contact Email
        </label>
        <input
          type="email"
          value={settings.general.contactEmail}
          onChange={(e) => handleInputChange('general', 'contactEmail', e.target.value)}
          className="w-full px-4 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>

      <div className="flex items-center">
        <input
          type="checkbox"
          id="maintenanceMode"
          checked={settings.general.maintenanceMode}
          onChange={() => handleToggleChange('general', 'maintenanceMode')}
          className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-700 rounded bg-gray-900"
        />
        <label htmlFor="maintenanceMode" className="ml-2 block text-indigo-300 text-sm">
          Enable Maintenance Mode
        </label>
      </div>

      <div className="flex items-center">
        <input
          type="checkbox"
          id="allowUserRegistration"
          checked={settings.general.allowUserRegistration}
          onChange={() => handleToggleChange('general', 'allowUserRegistration')}
          className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-700 rounded bg-gray-900"
        />
        <label htmlFor="allowUserRegistration" className="ml-2 block text-indigo-300 text-sm">
          Allow User Registration
        </label>
      </div>
    </div>
  );

  // Fees settings form
  const renderFeesSettings = () => (
    <div className="space-y-6">
      <div>
        <label className="block text-indigo-300 text-sm font-medium mb-2">
          Platform Fee Percentage (%)
        </label>
        <input
          type="number"
          min="0"
          max="100"
          value={settings.fees.platformFeePercentage}
          onChange={(e) => handleInputChange('fees', 'platformFeePercentage', parseFloat(e.target.value))}
          className="w-full px-4 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>

      <div>
        <label className="block text-indigo-300 text-sm font-medium mb-2">
          Minimum Withdrawal Amount ($)
        </label>
        <input
          type="number"
          min="0"
          value={settings.fees.minimumWithdrawalAmount}
          onChange={(e) => handleInputChange('fees', 'minimumWithdrawalAmount', parseFloat(e.target.value))}
          className="w-full px-4 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>

      <div>
        <label className="block text-indigo-300 text-sm font-medium mb-2">
          Payment Processing Fee (%)
        </label>
        <input
          type="number"
          min="0"
          step="0.1"
          value={settings.fees.paymentProcessingFee}
          onChange={(e) => handleInputChange('fees', 'paymentProcessingFee', parseFloat(e.target.value))}
          className="w-full px-4 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>

      <div>
        <label className="block text-indigo-300 text-sm font-medium mb-2">
          Featured Project Fee ($)
        </label>
        <input
          type="number"
          min="0"
          value={settings.fees.featuredProjectFee}
          onChange={(e) => handleInputChange('fees', 'featuredProjectFee', parseFloat(e.target.value))}
          className="w-full px-4 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>
    </div>
  );

  // Security settings form
  const renderSecuritySettings = () => (
    <div className="space-y-6">
      <div className="flex items-center">
        <input
          type="checkbox"
          id="twoFactorAuthRequired"
          checked={settings.security.twoFactorAuthRequired}
          onChange={() => handleToggleChange('security', 'twoFactorAuthRequired')}
          className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-700 rounded bg-gray-900"
        />
        <label htmlFor="twoFactorAuthRequired" className="ml-2 block text-indigo-300 text-sm">
          Require Two-Factor Authentication
        </label>
      </div>

      <div>
        <label className="block text-indigo-300 text-sm font-medium mb-2">
          Password Expiry (Days)
        </label>
        <input
          type="number"
          min="0"
          value={settings.security.passwordExpiryDays}
          onChange={(e) => handleInputChange('security', 'passwordExpiryDays', parseInt(e.target.value))}
          className="w-full px-4 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>

      <div>
        <label className="block text-indigo-300 text-sm font-medium mb-2">
          Maximum Login Attempts
        </label>
        <input
          type="number"
          min="1"
          value={settings.security.maxLoginAttempts}
          onChange={(e) => handleInputChange('security', 'maxLoginAttempts', parseInt(e.target.value))}
          className="w-full px-4 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>

      <div>
        <label className="block text-indigo-300 text-sm font-medium mb-2">
          Session Timeout (Minutes)
        </label>
        <input
          type="number"
          min="1"
          value={settings.security.sessionTimeoutMinutes}
          onChange={(e) => handleInputChange('security', 'sessionTimeoutMinutes', parseInt(e.target.value))}
          className="w-full px-4 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>
    </div>
  );

  // Notification settings form
  const renderNotificationSettings = () => (
    <div className="space-y-6">
      <div className="flex items-center">
        <input
          type="checkbox"
          id="enableEmailNotifications"
          checked={settings.notifications.enableEmailNotifications}
          onChange={() => handleToggleChange('notifications', 'enableEmailNotifications')}
          className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-700 rounded bg-gray-900"
        />
        <label htmlFor="enableEmailNotifications" className="ml-2 block text-indigo-300 text-sm">
          Enable Email Notifications
        </label>
      </div>

      <div className="flex items-center">
        <input
          type="checkbox"
          id="enableInAppNotifications"
          checked={settings.notifications.enableInAppNotifications}
          onChange={() => handleToggleChange('notifications', 'enableInAppNotifications')}
          className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-700 rounded bg-gray-900"
        />
        <label htmlFor="enableInAppNotifications" className="ml-2 block text-indigo-300 text-sm">
          Enable In-App Notifications
        </label>
      </div>

      <div>
        <label className="block text-indigo-300 text-sm font-medium mb-2">
          Admin Email Recipients (comma-separated)
        </label>
        <input
          type="text"
          value={settings.notifications.adminEmailRecipients}
          onChange={(e) => handleInputChange('notifications', 'adminEmailRecipients', e.target.value)}
          className="w-full px-4 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>

      <div>
        <label className="block text-indigo-300 text-sm font-medium mb-2">
          Notification Frequency
        </label>
        <select
          value={settings.notifications.notificationFrequency}
          onChange={(e) => handleInputChange('notifications', 'notificationFrequency', e.target.value)}
          className="w-full px-4 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        >
          <option value="immediate">Immediate</option>
          <option value="hourly">Hourly Digest</option>
          <option value="daily">Daily Digest</option>
          <option value="weekly">Weekly Digest</option>
        </select>
      </div>
    </div>
  );

  // Content settings form
  const renderContentSettings = () => (
    <div className="space-y-6">
      <div>
        <label className="block text-indigo-300 text-sm font-medium mb-2">
          Terms of Service
        </label>
        <textarea
          rows="6"
          value={settings.content.termsOfService}
          onChange={(e) => handleInputChange('content', 'termsOfService', e.target.value)}
          className="w-full px-4 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        ></textarea>
      </div>

      <div>
        <label className="block text-indigo-300 text-sm font-medium mb-2">
          Privacy Policy
        </label>
        <textarea
          rows="6"
          value={settings.content.privacyPolicy}
          onChange={(e) => handleInputChange('content', 'privacyPolicy', e.target.value)}
          className="w-full px-4 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        ></textarea>
      </div>

      <div>
        <label className="block text-indigo-300 text-sm font-medium mb-2">
          About Us
        </label>
        <textarea
          rows="6"
          value={settings.content.aboutUs}
          onChange={(e) => handleInputChange('content', 'aboutUs', e.target.value)}
          className="w-full px-4 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        ></textarea>
      </div>

      <div>
        <label className="block text-indigo-300 text-sm font-medium mb-2">
          FAQ
        </label>
        <textarea
          rows="6"
          value={settings.content.faq}
          onChange={(e) => handleInputChange('content', 'faq', e.target.value)}
          className="w-full px-4 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        ></textarea>
      </div>
    </div>
  );

  // Loading state
  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-white">Platform Settings</h1>
          <p className="text-indigo-300">
            Configure platform-wide settings and preferences
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <GlassCard className="p-4">
              <nav className="space-y-1">
                <button
                  onClick={() => setActiveTab('general')}
                  className={`w-full px-4 py-2 text-left rounded-md ${
                    activeTab === 'general'
                      ? 'bg-indigo-900/50 text-white'
                      : 'text-indigo-300 hover:bg-gray-800/50'
                  }`}
                >
                  General
                </button>
                <button
                  onClick={() => setActiveTab('fees')}
                  className={`w-full px-4 py-2 text-left rounded-md ${
                    activeTab === 'fees'
                      ? 'bg-indigo-900/50 text-white'
                      : 'text-indigo-300 hover:bg-gray-800/50'
                  }`}
                >
                  Fees & Payments
                </button>
                <button
                  onClick={() => setActiveTab('security')}
                  className={`w-full px-4 py-2 text-left rounded-md ${
                    activeTab === 'security'
                      ? 'bg-indigo-900/50 text-white'
                      : 'text-indigo-300 hover:bg-gray-800/50'
                  }`}
                >
                  Security
                </button>
                <button
                  onClick={() => setActiveTab('notifications')}
                  className={`w-full px-4 py-2 text-left rounded-md ${
                    activeTab === 'notifications'
                      ? 'bg-indigo-900/50 text-white'
                      : 'text-indigo-300 hover:bg-gray-800/50'
                  }`}
                >
                  Notifications
                </button>
                <button
                  onClick={() => setActiveTab('content')}
                  className={`w-full px-4 py-2 text-left rounded-md ${
                    activeTab === 'content'
                      ? 'bg-indigo-900/50 text-white'
                      : 'text-indigo-300 hover:bg-gray-800/50'
                  }`}
                >
                  Content
                </button>
              </nav>
            </GlassCard>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <GlassCard className="p-6">
              {renderTabContent()}

              <div className="mt-8 flex justify-end">
                <GlowButton
                  variant="primary"
                  onClick={saveSettings}
                  disabled={saving}
                >
                  {saving ? 'Saving...' : 'Save Settings'}
                </GlowButton>
              </div>
            </GlassCard>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default PlatformSettings;
