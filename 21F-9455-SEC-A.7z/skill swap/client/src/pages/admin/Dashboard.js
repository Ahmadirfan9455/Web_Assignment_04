import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

const AdminDashboard = () => {
  const { user } = useAuth();
  const location = useLocation();
  
  // Dashboard data states
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalProjects: 0,
    totalContracts: 0,
    totalRevenue: 0,
    pendingVerifications: 0,
    activeUsers: 0,
  });
  
  const [recentUsers, setRecentUsers] = useState([]);
  const [recentProjects, setRecentProjects] = useState([]);
  const [recentContracts, setRecentContracts] = useState([]);
  const [pendingVerifications, setPendingVerifications] = useState([]);
  
  // Loading state
  const [isLoading, setIsLoading] = useState(true);
  
  // Fetch dashboard data
  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setIsLoading(true);
        
        // Fetch admin stats
        const statsResponse = await axios.get('/api/admin/stats');
        setStats(statsResponse.data);
        
        // Fetch recent users
        const usersResponse = await axios.get('/api/admin/users/recent');
        setRecentUsers(usersResponse.data);
        
        // Fetch recent projects
        const projectsResponse = await axios.get('/api/admin/projects/recent');
        setRecentProjects(projectsResponse.data);
        
        // Fetch recent contracts
        const contractsResponse = await axios.get('/api/admin/contracts/recent');
        setRecentContracts(contractsResponse.data);
        
        // Fetch pending verifications
        const verificationsResponse = await axios.get('/api/admin/verifications/pending');
        setPendingVerifications(verificationsResponse.data);
      } catch (error) {
        console.error('Error fetching admin dashboard data:', error);
        toast.error('Failed to load dashboard data. Please try again.');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchDashboardData();
  }, []);
  
  // Approve verification
  const approveVerification = async (verificationId) => {
    try {
      await axios.put(`/api/admin/verifications/${verificationId}/approve`);
      
      // Update pending verifications state
      setPendingVerifications((prev) =>
        prev.filter((verification) => verification._id !== verificationId)
      );
      
      // Update stats
      setStats((prev) => ({
        ...prev,
        pendingVerifications: prev.pendingVerifications - 1,
      }));
      
      toast.success('Verification approved successfully.');
    } catch (error) {
      console.error('Error approving verification:', error);
      toast.error('Failed to approve verification. Please try again.');
    }
  };
  
  // Reject verification
  const rejectVerification = async (verificationId) => {
    try {
      await axios.put(`/api/admin/verifications/${verificationId}/reject`);
      
      // Update pending verifications state
      setPendingVerifications((prev) =>
        prev.filter((verification) => verification._id !== verificationId)
      );
      
      // Update stats
      setStats((prev) => ({
        ...prev,
        pendingVerifications: prev.pendingVerifications - 1,
      }));
      
      toast.success('Verification rejected successfully.');
    } catch (error) {
      console.error('Error rejecting verification:', error);
      toast.error('Failed to reject verification. Please try again.');
    }
  };
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
      },
    },
  };
  
  // Show loading screen while fetching data
  if (isLoading) {
    return <LoadingScreen />;
  }
  
  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  return (
    <div className="flex min-h-screen bg-gray-900">
      {/* Admin Sidebar */}
      <motion.div
        initial={{ x: -100, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="w-64 bg-gray-900 border-r border-gray-800 fixed h-full overflow-y-auto"
      >
        <div className="p-6">
          <h2 className="text-2xl font-bold text-white mb-6">SkillSwap</h2>
          
          <nav className="space-y-2">
            <Link
              to="/admin/dashboard"
              className={`flex items-center px-4 py-3 rounded-lg ${location.pathname === '/admin/dashboard' ? 'bg-indigo-900/50 text-white' : 'text-indigo-300 hover:bg-gray-800/50'}`}
            >
              <svg className="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
              </svg>
              <span>Dashboard</span>
            </Link>
            
            <Link
              to="/admin/users"
              className={`flex items-center px-4 py-3 rounded-lg ${location.pathname === '/admin/users' ? 'bg-indigo-900/50 text-white' : 'text-indigo-300 hover:bg-gray-800/50'}`}
            >
              <svg className="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
              </svg>
              <span>User Management</span>
            </Link>
            
            <Link
              to="/admin/projects"
              className={`flex items-center px-4 py-3 rounded-lg ${location.pathname === '/admin/projects' ? 'bg-indigo-900/50 text-white' : 'text-indigo-300 hover:bg-gray-800/50'}`}
            >
              <svg className="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path>
              </svg>
              <span>Project Management</span>
            </Link>
            
            <Link
              to="/admin/contracts"
              className={`flex items-center px-4 py-3 rounded-lg ${location.pathname === '/admin/contracts' ? 'bg-indigo-900/50 text-white' : 'text-indigo-300 hover:bg-gray-800/50'}`}
            >
              <svg className="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
              </svg>
              <span>Contracts</span>
            </Link>
            
            <Link
              to="/admin/analytics"
              className={`flex items-center px-4 py-3 rounded-lg ${location.pathname === '/admin/analytics' ? 'bg-indigo-900/50 text-white' : 'text-indigo-300 hover:bg-gray-800/50'}`}
            >
              <svg className="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
              </svg>
              <span>Analytics</span>
            </Link>
            
            <Link
              to="/admin/notifications"
              className={`flex items-center px-4 py-3 rounded-lg ${location.pathname === '/admin/notifications' ? 'bg-indigo-900/50 text-white' : 'text-indigo-300 hover:bg-gray-800/50'}`}
            >
              <svg className="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path>
              </svg>
              <span>Notifications</span>
            </Link>
            
            <Link
              to="/admin/time-tracking"
              className={`flex items-center px-4 py-3 rounded-lg ${location.pathname === '/admin/time-tracking' ? 'bg-indigo-900/50 text-white' : 'text-indigo-300 hover:bg-gray-800/50'}`}
            >
              <svg className="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
              </svg>
              <span>Time Tracking</span>
            </Link>
            
            <Link
              to="/admin/milestone-tracking"
              className={`flex items-center px-4 py-3 rounded-lg ${location.pathname === '/admin/milestone-tracking' ? 'bg-indigo-900/50 text-white' : 'text-indigo-300 hover:bg-gray-800/50'}`}
            >
              <svg className="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"></path>
              </svg>
              <span>Milestone Tracking</span>
            </Link>
            
            <Link
              to="/admin/settings"
              className={`flex items-center px-4 py-3 rounded-lg ${location.pathname === '/admin/settings' ? 'bg-indigo-900/50 text-white' : 'text-indigo-300 hover:bg-gray-800/50'}`}
            >
              <svg className="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path>
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
              </svg>
              <span>Settings</span>
            </Link>
          </nav>
          
          <div className="mt-10 pt-6 border-t border-gray-800">
            <Link
              to="/"
              className="flex items-center px-4 py-3 rounded-lg text-indigo-300 hover:bg-gray-800/50"
            >
              <svg className="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
              </svg>
              <span>Back to Platform</span>
            </Link>
          </div>
        </div>
      </motion.div>
      
      {/* Main Content */}
      <div className="flex-1 ml-64">
        <div className="py-8 px-4 sm:px-6 lg:px-8">
          <motion.div
            className="max-w-7xl mx-auto"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {/* Welcome Section */}
            <motion.div variants={itemVariants} className="mb-8">
              <h1 className="text-3xl font-bold text-white">
                Admin Dashboard
              </h1>
              <p className="text-indigo-200 mt-2">
                Welcome back, {user?.name}. Here's an overview of the platform.
              </p>
            </motion.div>
            
            {/* Stats Section */}
            <motion.div variants={itemVariants} className="mb-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <GlassCard className="p-6">
                  <h3 className="text-lg font-medium text-indigo-300 mb-2">Total Users</h3>
                  <p className="text-3xl font-bold text-white">{stats.totalUsers}</p>
                  <div className="mt-2 text-sm text-indigo-200">
                    <span className="text-green-400">{stats.activeUsers}</span> active users
                  </div>
                </GlassCard>
                
                <GlassCard className="p-6">
                  <h3 className="text-lg font-medium text-indigo-300 mb-2">Total Projects</h3>
                  <p className="text-3xl font-bold text-white">{stats.totalProjects}</p>
                </GlassCard>
                
                <GlassCard className="p-6">
                  <h3 className="text-lg font-medium text-indigo-300 mb-2">Total Contracts</h3>
                  <p className="text-3xl font-bold text-white">{stats.totalContracts}</p>
                </GlassCard>
                
                <GlassCard className="p-6">
                  <h3 className="text-lg font-medium text-indigo-300 mb-2">Total Revenue</h3>
                  <p className="text-3xl font-bold text-white">${stats.totalRevenue.toFixed(2)}</p>
                </GlassCard>
                
                <GlassCard className="p-6">
                  <h3 className="text-lg font-medium text-indigo-300 mb-2">Pending Verifications</h3>
                  <p className="text-3xl font-bold text-white">{stats.pendingVerifications}</p>
                </GlassCard>
                
                <GlassCard className="p-6 flex items-center justify-center">
                  <GlowButton
                    as={Link}
                    to="/admin/analytics"
                    variant="primary"
                    className="px-4 py-2"
                  >
                    View Full Analytics
                  </GlowButton>
                </GlassCard>
              </div>
            </motion.div>
            
            {/* Admin Navigation Cards */}
            <motion.div variants={itemVariants} className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-white">Admin Navigation</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <GlassCard className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-lg font-medium text-white">Users</h3>
                  </div>
                  <p className="text-indigo-200 mb-4 line-clamp-2">Manage all users on the platform</p>
                  <Link to="/admin/users" className="text-indigo-400 hover:text-indigo-300 transition-colors">
                    View All
                  </Link>
                </GlassCard>
                
                <GlassCard className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-lg font-medium text-white">Projects</h3>
                  </div>
                  <p className="text-indigo-200 mb-4 line-clamp-2">Manage all projects on the platform</p>
                  <Link to="/admin/projects" className="text-indigo-400 hover:text-indigo-300 transition-colors">
                    View All
                  </Link>
                </GlassCard>
                
                <GlassCard className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-lg font-medium text-white">Analytics</h3>
                  </div>
                  <p className="text-indigo-200 mb-4 line-clamp-2">View platform analytics and insights</p>
                  <Link to="/admin/analytics" className="text-indigo-400 hover:text-indigo-300 transition-colors">
                    View All
                  </Link>
                </GlassCard>
                
                <GlassCard className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-lg font-medium text-white">Platform Settings</h3>
                  </div>
                  <p className="text-indigo-200 mb-4 line-clamp-2">Manage platform settings and configurations</p>
                  <Link to="/admin/settings" className="text-indigo-400 hover:text-indigo-300 transition-colors">
                    View All
                  </Link>
                </GlassCard>
                
                <GlassCard className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-lg font-medium text-white">Contracts</h3>
                  </div>
                  <p className="text-indigo-200 mb-4 line-clamp-2">Manage all contracts on the platform</p>
                  <Link to="/admin/contracts" className="text-indigo-400 hover:text-indigo-300 transition-colors">
                    View All
                  </Link>
                </GlassCard>
                
                <GlassCard className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-lg font-medium text-white">Notifications</h3>
                  </div>
                  <p className="text-indigo-200 mb-4 line-clamp-2">Manage notification settings and view all notifications</p>
                  <Link to="/admin/notifications" className="text-indigo-400 hover:text-indigo-300 transition-colors">
                    View All
                  </Link>
                </GlassCard>
              </div>
            </motion.div>
            
            {/* Recent Users */}
            <motion.div variants={itemVariants} className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-white">Recent Users</h2>
                <Link to="/admin/users" className="text-indigo-400 hover:text-indigo-300">
                  View All
                </Link>
              </div>
              
              <GlassCard className="overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-700">
                    <thead className="bg-gray-800/50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                          Name
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                          Email
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                          Role
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                          Joined
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                          Status
                        </th>
                        <th scope="col" className="relative px-6 py-3">
                          <span className="sr-only">Actions</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-700">
                      {recentUsers.map((user) => (
                        <tr key={user._id} className="hover:bg-gray-800/50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="h-10 w-10 flex-shrink-0">
                                <div className="h-10 w-10 rounded-full bg-indigo-600 flex items-center justify-center">
                                  <span className="text-white font-medium">
                                    {user.name.charAt(0).toUpperCase()}
                                  </span>
                                </div>
                              </div>
                              <div className="ml-4">
                                <div className="text-sm font-medium text-white">{user.name}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-indigo-200">{user.email}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-indigo-200 capitalize">{user.role}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-indigo-200">
                            {formatDate(user.createdAt)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              user.isVerified
                                ? 'bg-green-900/50 text-green-300'
                                : 'bg-yellow-900/50 text-yellow-300'
                            }`}>
                              {user.isVerified ? 'Verified' : 'Pending'}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <Link to={`/admin/users/${user._id}`} className="text-indigo-400 hover:text-indigo-300">
                              View
                            </Link>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </GlassCard>
            </motion.div>
            
            {/* Pending Verifications */}
            {pendingVerifications.length > 0 && (
              <motion.div variants={itemVariants} className="mb-8">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-white">Pending Verifications</h2>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {pendingVerifications.map((verification) => (
                    <GlassCard key={verification._id} className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-lg font-medium text-white">{verification.user.name}</h3>
                          <p className="text-indigo-300 text-sm">{verification.user.email}</p>
                        </div>
                        <span className="px-2 py-1 text-xs bg-yellow-900/50 text-yellow-300 rounded-full">
                          Pending
                        </span>
                      </div>
                      
                      <div className="mb-4">
                        <p className="text-indigo-200 text-sm mb-2">
                          <span className="text-indigo-300">Type:</span> {verification.type}
                        </p>
                        <p className="text-indigo-200 text-sm mb-2">
                          <span className="text-indigo-300">Submitted:</span> {formatDate(verification.createdAt)}
                        </p>
                        {verification.documentUrl && (
                          <a
                            href={verification.documentUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-indigo-400 hover:text-indigo-300 text-sm inline-flex items-center"
                          >
                            <span>View Document</span>
                            <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path>
                            </svg>
                          </a>
                        )}
                      </div>
                      
                      <div className="flex space-x-3">
                        <GlowButton
                          variant="primary"
                          size="sm"
                          onClick={() => approveVerification(verification._id)}
                        >
                          Approve
                        </GlowButton>
                        <GlowButton
                          variant="secondary"
                          size="sm"
                          onClick={() => rejectVerification(verification._id)}
                        >
                          Reject
                        </GlowButton>
                      </div>
                    </GlassCard>
                  ))}
                </div>
              </motion.div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
