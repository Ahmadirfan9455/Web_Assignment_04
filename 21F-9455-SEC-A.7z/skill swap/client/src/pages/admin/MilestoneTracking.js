import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import { Link } from 'react-router-dom';
import { getMilestones, getMilestoneStats, getProjects, updateMilestoneStatus, getMilestoneById } from '../../services/milestoneService';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

const MilestoneTracking = () => {
  // State
  const [loading, setLoading] = useState(true);
  const [milestones, setMilestones] = useState([]);
  const [projects, setProjects] = useState([]);
  const [stats, setStats] = useState({
    notStarted: 0,
    inProgress: 0,
    completed: 0,
    approved: 0,
    rejected: 0
  });
  const [filters, setFilters] = useState({
    project: 'all',
    status: 'all',
    sortBy: 'dueDate',
    sortOrder: 'asc'
  });
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 1
  });
  const [selectedMilestone, setSelectedMilestone] = useState(null);
  const [showMilestoneModal, setShowMilestoneModal] = useState(false);
  const [processingAction, setProcessingAction] = useState(false);
  const [milestoneNote, setMilestoneNote] = useState('');
  
  // Fetch milestones
  useEffect(() => {
    const fetchMilestones = async () => {
      try {
        setLoading(true);
        
        // Prepare filter parameters
        const filterParams = {
          sortBy: filters.sortBy,
          sortOrder: filters.sortOrder,
          ...(filters.project !== 'all' && { project: filters.project }),
          ...(filters.status !== 'all' && { status: filters.status })
        };
        
        // Fetch milestones using service
        const milestonesData = await getMilestones(filterParams, pagination.page, pagination.limit);
        setMilestones(milestonesData.milestones);
        setPagination({
          ...pagination,
          total: milestonesData.total,
          totalPages: milestonesData.totalPages
        });
        
        // Fetch milestone stats
        const statsData = await getMilestoneStats();
        setStats(statsData.stats);
        
        // Fetch projects if not already loaded
        if (projects.length === 0) {
          const projectsData = await getProjects();
          setProjects(projectsData.projects);
        }
        
        setLoading(false);
      } catch (error) {
        console.error('Error fetching milestones:', error);
        toast.error('Failed to load milestone data');
        setLoading(false);
      }
    };
    
    fetchMilestones();
  }, [pagination.page, filters, projects.length]);
  
  // Handle filter changes
  const handleFilterChange = (filter, value) => {
    setFilters(prev => ({
      ...prev,
      [filter]: value
    }));
    setPagination(prev => ({
      ...prev,
      page: 1 // Reset to first page on filter change
    }));
  };
  
  // Handle sort
  const handleSort = (field) => {
    setFilters(prev => ({
      ...prev,
      sortBy: field,
      sortOrder: prev.sortBy === field && prev.sortOrder === 'asc' ? 'desc' : 'asc'
    }));
  };
  
  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  // Format currency
  const formatCurrency = (amount) => {
    return `$${parseFloat(amount).toFixed(2)}`;
  };
  
  // Get status color
  const getStatusColor = (status) => {
    switch (status) {
      case 'not_started':
        return 'bg-gray-900/50 text-gray-300';
      case 'in_progress':
        return 'bg-blue-900/50 text-blue-300';
      case 'completed':
        return 'bg-green-900/50 text-green-300';
      case 'approved':
        return 'bg-indigo-900/50 text-indigo-300';
      case 'rejected':
        return 'bg-red-900/50 text-red-300';
      default:
        return 'bg-gray-900/50 text-gray-300';
    }
  };
  
  // Format status text
  const formatStatus = (status) => {
    return status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };
  
  // Handle milestone status update
  const handleUpdateStatus = async (status) => {
    try {
      setProcessingAction(true);
      
      await updateMilestoneStatus(selectedMilestone._id, status, milestoneNote);
      
      // Update local state
      setMilestones(prev => prev.map(milestone => 
        milestone._id === selectedMilestone._id 
          ? { 
              ...milestone, 
              status,
              statusHistory: [...milestone.statusHistory, { status, note: milestoneNote, date: new Date() }] 
            } 
          : milestone
      ));
      
      toast.success(`Milestone status updated to ${formatStatus(status)}`);
      setShowMilestoneModal(false);
      setMilestoneNote('');
    } catch (error) {
      console.error('Error updating milestone status:', error);
      toast.error('Failed to update milestone status');
    } finally {
      setProcessingAction(false);
    }
  };
  
  // View milestone details
  const viewMilestoneDetails = async (milestone) => {
    try {
      // If we need to fetch more detailed milestone data
      const detailedMilestone = await getMilestoneById(milestone._id);
      setSelectedMilestone(detailedMilestone);
      setShowMilestoneModal(true);
    } catch (error) {
      console.error('Error fetching milestone details:', error);
      toast.error('Failed to load milestone details');
      // Fallback to using the milestone data we already have
      setSelectedMilestone(milestone);
      setShowMilestoneModal(true);
    }
  };
  
  // Milestone modal
  const renderMilestoneModal = () => {
    if (!selectedMilestone || !showMilestoneModal) return null;
    
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          className="w-full max-w-3xl max-h-[90vh] overflow-y-auto"
        >
          <GlassCard className="p-6">
            <div className="flex justify-between items-start mb-6">
              <h2 className="text-xl font-semibold text-white">Milestone Details</h2>
              <button
                onClick={() => setShowMilestoneModal(false)}
                className="text-indigo-300 hover:text-indigo-200"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
              </button>
            </div>
            
            <div className="mb-6">
              <h3 className="text-lg font-medium text-white mb-2">{selectedMilestone.title}</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-indigo-300 text-sm">Project</p>
                  <p className="text-white font-medium">{selectedMilestone.project.title}</p>
                </div>
                
                <div>
                  <p className="text-indigo-300 text-sm">Amount</p>
                  <p className="text-white font-medium">{formatCurrency(selectedMilestone.amount)}</p>
                </div>
                
                <div>
                  <p className="text-indigo-300 text-sm">Due Date</p>
                  <p className="text-white font-medium">{formatDate(selectedMilestone.dueDate)}</p>
                </div>
                
                <div>
                  <p className="text-indigo-300 text-sm">Status</p>
                  <p className={`font-medium ${getStatusColor(selectedMilestone.status).split(' ')[1]}`}>
                    {formatStatus(selectedMilestone.status)}
                  </p>
                </div>
              </div>
              
              <div className="mb-4">
                <p className="text-indigo-300 text-sm mb-1">Description</p>
                <p className="text-white">{selectedMilestone.description}</p>
              </div>
              
              {selectedMilestone.deliverables && selectedMilestone.deliverables.length > 0 && (
                <div className="mb-4">
                  <p className="text-indigo-300 text-sm mb-1">Deliverables</p>
                  <ul className="list-disc pl-5 text-white">
                    {selectedMilestone.deliverables.map((deliverable, index) => (
                      <li key={index}>{deliverable}</li>
                    ))}
                  </ul>
                </div>
              )}
              
              {selectedMilestone.statusHistory && selectedMilestone.statusHistory.length > 0 && (
                <div className="mb-4">
                  <p className="text-indigo-300 text-sm mb-2">Status History</p>
                  <div className="space-y-2">
                    {selectedMilestone.statusHistory.map((history, index) => (
                      <div key={index} className="bg-gray-800/50 p-3 rounded-md">
                        <div className="flex justify-between items-center mb-1">
                          <span className={`text-sm px-2 py-0.5 rounded-full ${getStatusColor(history.status)}`}>
                            {formatStatus(history.status)}
                          </span>
                          <span className="text-xs text-indigo-300">{formatDate(history.date)}</span>
                        </div>
                        {history.note && <p className="text-sm text-white">{history.note}</p>}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Status Update Form */}
              {selectedMilestone.status !== 'approved' && (
                <div className="mt-6 border-t border-gray-700 pt-4">
                  <h4 className="text-white font-medium mb-3">Update Status</h4>
                  
                  <div className="mb-4">
                    <label className="block text-indigo-300 text-sm font-medium mb-2">
                      Note (optional)
                    </label>
                    <textarea
                      value={milestoneNote}
                      onChange={(e) => setMilestoneNote(e.target.value)}
                      rows="3"
                      className="w-full px-4 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                      placeholder="Add a note about this status update..."
                    ></textarea>
                  </div>
                  
                  <div className="flex flex-wrap gap-3">
                    {selectedMilestone.status === 'not_started' && (
                      <GlowButton
                        variant="primary"
                        onClick={() => handleUpdateStatus('in_progress')}
                        disabled={processingAction}
                      >
                        {processingAction ? 'Processing...' : 'Mark In Progress'}
                      </GlowButton>
                    )}
                    
                    {selectedMilestone.status === 'in_progress' && (
                      <GlowButton
                        variant="primary"
                        onClick={() => handleUpdateStatus('completed')}
                        disabled={processingAction}
                      >
                        {processingAction ? 'Processing...' : 'Mark Completed'}
                      </GlowButton>
                    )}
                    
                    {selectedMilestone.status === 'completed' && (
                      <>
                        <GlowButton
                          variant="primary"
                          onClick={() => handleUpdateStatus('approved')}
                          disabled={processingAction}
                        >
                          {processingAction ? 'Processing...' : 'Approve Milestone'}
                        </GlowButton>
                        
                        <GlowButton
                          variant="secondary"
                          onClick={() => handleUpdateStatus('rejected')}
                          disabled={processingAction}
                        >
                          {processingAction ? 'Processing...' : 'Reject Milestone'}
                        </GlowButton>
                      </>
                    )}
                    
                    {selectedMilestone.status === 'rejected' && (
                      <GlowButton
                        variant="primary"
                        onClick={() => handleUpdateStatus('in_progress')}
                        disabled={processingAction}
                      >
                        {processingAction ? 'Processing...' : 'Reopen Milestone'}
                      </GlowButton>
                    )}
                  </div>
                </div>
              )}
            </div>
          </GlassCard>
        </motion.div>
      </div>
    );
  };
  
  // Loading state
  if (loading && milestones.length === 0) {
    return <LoadingScreen />;
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      {renderMilestoneModal()}
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <h1 className="text-2xl font-bold text-white">Milestone Tracking</h1>
            <p className="text-indigo-300">
              Monitor and manage project milestones and deliverables
            </p>
          </div>
        </div>
        
        <GlassCard className="p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Project Filter */}
            <div>
              <label className="block text-indigo-300 text-sm font-medium mb-2">
                Project
              </label>
              <select
                value={filters.project}
                onChange={(e) => handleFilterChange('project', e.target.value)}
                className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="all">All Projects</option>
                {projects.map(project => (
                  <option key={project._id} value={project._id}>
                    {project.title}
                  </option>
                ))}
              </select>
            </div>
            
            {/* Status Filter */}
            <div>
              <label className="block text-indigo-300 text-sm font-medium mb-2">
                Status
              </label>
              <select
                value={filters.status}
                onChange={(e) => handleFilterChange('status', e.target.value)}
                className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="all">All Statuses</option>
                <option value="not_started">Not Started</option>
                <option value="in_progress">In Progress</option>
                <option value="completed">Completed</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>
        </GlassCard>
        
        <GlassCard className="p-0 overflow-hidden">
          {/* Milestones Table */}
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-700">
              <thead className="bg-gray-800/50">
                <tr>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('title')}
                  >
                    <div className="flex items-center">
                      <span>Title</span>
                      {filters.sortBy === 'title' && (
                        <svg 
                          className={`w-4 h-4 ml-1 ${filters.sortOrder === 'asc' ? '' : 'transform rotate-180'}`} 
                          fill="none" 
                          stroke="currentColor" 
                          viewBox="0 0 24 24" 
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path>
                        </svg>
                      )}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('project.title')}
                  >
                    <div className="flex items-center">
                      <span>Project</span>
                      {filters.sortBy === 'project.title' && (
                        <svg 
                          className={`w-4 h-4 ml-1 ${filters.sortOrder === 'asc' ? '' : 'transform rotate-180'}`} 
                          fill="none" 
                          stroke="currentColor" 
                          viewBox="0 0 24 24" 
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path>
                        </svg>
                      )}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('amount')}
                  >
                    <div className="flex items-center">
                      <span>Amount</span>
                      {filters.sortBy === 'amount' && (
                        <svg 
                          className={`w-4 h-4 ml-1 ${filters.sortOrder === 'asc' ? '' : 'transform rotate-180'}`} 
                          fill="none" 
                          stroke="currentColor" 
                          viewBox="0 0 24 24" 
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path>
                        </svg>
                      )}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('dueDate')}
                  >
                    <div className="flex items-center">
                      <span>Due Date</span>
                      {filters.sortBy === 'dueDate' && (
                        <svg 
                          className={`w-4 h-4 ml-1 ${filters.sortOrder === 'asc' ? '' : 'transform rotate-180'}`} 
                          fill="none" 
                          stroke="currentColor" 
                          viewBox="0 0 24 24" 
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path>
                        </svg>
                      )}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('status')}
                  >
                    <div className="flex items-center">
                      <span>Status</span>
                      {filters.sortBy === 'status' && (
                        <svg 
                          className={`w-4 h-4 ml-1 ${filters.sortOrder === 'asc' ? '' : 'transform rotate-180'}`} 
                          fill="none" 
                          stroke="currentColor" 
                          viewBox="0 0 24 24" 
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path>
                        </svg>
                      )}
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-indigo-300 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {loading ? (
                  <tr>
                    <td colSpan="6" className="px-6 py-4 text-center">
                      <div className="flex justify-center">
                        <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-indigo-500"></div>
                      </div>
                    </td>
                  </tr>
                ) : milestones.length > 0 ? (
                  milestones.map((milestone) => (
                    <tr key={milestone._id} className="hover:bg-gray-800/50">
                      <td className="px-6 py-4">
                        <div className="text-sm font-medium text-white">
                          {milestone.title}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-indigo-200">{milestone.project.title}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-indigo-200">{formatCurrency(milestone.amount)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-indigo-200">{formatDate(milestone.dueDate)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(milestone.status)}`}>
                          {formatStatus(milestone.status)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button
                          onClick={() => viewMilestoneDetails(milestone)}
                          className="text-indigo-400 hover:text-indigo-300"
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="px-6 py-4 text-center text-indigo-300">
                      No milestones found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          
          {/* Pagination */}
          {pagination.totalPages > 1 && (
            <div className="px-6 py-3 flex items-center justify-between border-t border-gray-700">
              <div>
                <p className="text-sm text-indigo-300">
                  Showing page {pagination.page} of {pagination.totalPages}
                </p>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => setPagination(prev => ({ ...prev, page: Math.max(prev.page - 1, 1) }))}
                  disabled={pagination.page === 1}
                  className={`px-3 py-1 rounded-md ${
                    pagination.page === 1
                      ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                      : 'bg-gray-800 text-indigo-300 hover:bg-gray-700'
                  }`}
                >
                  Previous
                </button>
                <button
                  onClick={() => setPagination(prev => ({ ...prev, page: Math.min(prev.page + 1, prev.totalPages) }))}
                  disabled={pagination.page === pagination.totalPages}
                  className={`px-3 py-1 rounded-md ${
                    pagination.page === pagination.totalPages
                      ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                      : 'bg-gray-800 text-indigo-300 hover:bg-gray-700'
                  }`}
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </GlassCard>
        
        {/* Milestone Summary */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-6">
          <GlassCard className="p-6">
            <h3 className="text-lg font-medium text-white mb-4">Not Started</h3>
            <div className="text-3xl font-bold text-white">
              {stats.notStarted || milestones.filter(milestone => milestone.status === 'not_started').length}
            </div>
            <p className="text-indigo-300 mt-2">Milestones pending</p>
          </GlassCard>
          
          <GlassCard className="p-6">
            <h3 className="text-lg font-medium text-white mb-4">In Progress</h3>
            <div className="text-3xl font-bold text-white">
              {stats.inProgress || milestones.filter(milestone => milestone.status === 'in_progress').length}
            </div>
            <p className="text-indigo-300 mt-2">Milestones being worked on</p>
          </GlassCard>
          
          <GlassCard className="p-6">
            <h3 className="text-lg font-medium text-white mb-4">Completed</h3>
            <div className="text-3xl font-bold text-white">
              {stats.completed || milestones.filter(milestone => milestone.status === 'completed').length}
            </div>
            <p className="text-indigo-300 mt-2">Milestones awaiting approval</p>
          </GlassCard>
          
          <GlassCard className="p-6">
            <h3 className="text-lg font-medium text-white mb-4">Approved</h3>
            <div className="text-3xl font-bold text-white">
              {stats.approved || milestones.filter(milestone => milestone.status === 'approved').length}
            </div>
            <p className="text-indigo-300 mt-2">Milestones completed and approved</p>
          </GlassCard>
        </div>
      </motion.div>
    </div>
  );
};

export default MilestoneTracking;
