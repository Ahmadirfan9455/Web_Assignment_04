import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

const ProjectManagement = () => {
  const { user } = useAuth();
  
  // State
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [sortBy, setSortBy] = useState('createdAt');
  const [sortOrder, setSortOrder] = useState('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [selectedProject, setSelectedProject] = useState(null);
  const [showProjectModal, setShowProjectModal] = useState(false);
  const [processingAction, setProcessingAction] = useState(false);
  const [categories, setCategories] = useState([]);
  
  // Fetch projects
  useEffect(() => {
    const fetchProjects = async () => {
      try {
        setLoading(true);
        
        const params = {
          page: currentPage,
          limit: 10,
          sortBy,
          sortOrder,
          ...(searchQuery && { search: searchQuery }),
          ...(statusFilter !== 'all' && { status: statusFilter }),
          ...(categoryFilter !== 'all' && { category: categoryFilter })
        };
        
        const { data } = await axios.get('/api/admin/projects', { params });
        
        setProjects(data.projects);
        setTotalPages(data.totalPages);
        
        // Fetch categories if not already loaded
        if (categories.length === 0) {
          const { data: categoriesData } = await axios.get('/api/categories');
          setCategories(categoriesData);
        }
        
        setLoading(false);
      } catch (error) {
        console.error('Error fetching projects:', error);
        toast.error('Failed to load projects');
        setLoading(false);
      }
    };
    
    fetchProjects();
  }, [currentPage, sortBy, sortOrder, searchQuery, statusFilter, categoryFilter, categories.length]);
  
  // Handle search
  const handleSearch = (e) => {
    e.preventDefault();
    setCurrentPage(1); // Reset to first page on new search
  };
  
  // Handle sort
  const handleSort = (field) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('asc');
    }
    setCurrentPage(1); // Reset to first page on new sort
  };
  
  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  // Format currency
  const formatCurrency = (amount) => {
    return `$${parseFloat(amount).toFixed(2)}`;
  };
  
  // Handle project action (approve, reject, feature, hide)
  const handleProjectAction = async (action, projectId) => {
    try {
      setProcessingAction(true);
      
      let endpoint;
      let successMessage;
      
      switch (action) {
        case 'approve':
          endpoint = `/api/admin/projects/${projectId}/approve`;
          successMessage = 'Project approved successfully';
          break;
        case 'reject':
          endpoint = `/api/admin/projects/${projectId}/reject`;
          successMessage = 'Project rejected successfully';
          break;
        case 'feature':
          endpoint = `/api/admin/projects/${projectId}/feature`;
          successMessage = 'Project featured successfully';
          break;
        case 'unfeature':
          endpoint = `/api/admin/projects/${projectId}/unfeature`;
          successMessage = 'Project unfeatured successfully';
          break;
        case 'delete':
          endpoint = `/api/admin/projects/${projectId}`;
          successMessage = 'Project deleted successfully';
          break;
        default:
          throw new Error('Invalid action');
      }
      
      if (action === 'delete') {
        await axios.delete(endpoint);
      } else {
        await axios.patch(endpoint);
      }
      
      // Update local state
      if (action === 'delete') {
        setProjects(prev => prev.filter(p => p._id !== projectId));
      } else {
        setProjects(prev => prev.map(p => {
          if (p._id === projectId) {
            if (action === 'approve') {
              return { ...p, status: 'active' };
            } else if (action === 'reject') {
              return { ...p, status: 'rejected' };
            } else if (action === 'feature') {
              return { ...p, featured: true };
            } else if (action === 'unfeature') {
              return { ...p, featured: false };
            }
          }
          return p;
        }));
      }
      
      toast.success(successMessage);
      setShowProjectModal(false);
    } catch (error) {
      console.error(`Error performing ${action} action:`, error);
      toast.error(`Failed to ${action} project. ${error.response?.data?.message || ''}`);
    } finally {
      setProcessingAction(false);
    }
  };
  
  // View project details
  const viewProjectDetails = (project) => {
    setSelectedProject(project);
    setShowProjectModal(true);
  };
  
  // Project modal
  const renderProjectModal = () => {
    if (!selectedProject || !showProjectModal) return null;
    
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          className="w-full max-w-3xl max-h-[90vh] overflow-y-auto"
        >
          <GlassCard className="p-6">
            <div className="flex justify-between items-start mb-6">
              <h2 className="text-xl font-semibold text-white">Project Details</h2>
              <button
                onClick={() => setShowProjectModal(false)}
                className="text-indigo-300 hover:text-indigo-200"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
              </button>
            </div>
            
            <div className="mb-6">
              <h3 className="text-lg font-medium text-white">{selectedProject.title}</h3>
              
              <div className="flex flex-wrap gap-2 mt-2">
                {selectedProject.skills && selectedProject.skills.map((skill, index) => (
                  <span 
                    key={index}
                    className="px-2 py-1 bg-indigo-900/50 rounded-full text-xs text-indigo-300"
                  >
                    {skill}
                  </span>
                ))}
              </div>
              
              <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <p className="text-indigo-300 text-sm">Budget</p>
                  <p className="text-white font-medium">{formatCurrency(selectedProject.budget)}</p>
                </div>
                
                <div>
                  <p className="text-indigo-300 text-sm">Deadline</p>
                  <p className="text-white font-medium">{formatDate(selectedProject.deadline)}</p>
                </div>
                
                <div>
                  <p className="text-indigo-300 text-sm">Status</p>
                  <p className="text-white font-medium capitalize">{selectedProject.status}</p>
                </div>
              </div>
              
              <div className="mt-4">
                <p className="text-indigo-300 text-sm">Description</p>
                <p className="text-white mt-1">{selectedProject.description}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <h3 className="text-indigo-300 text-sm mb-2">Client</h3>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-indigo-700 rounded-full flex items-center justify-center mr-3">
                    <span className="text-white font-medium">
                      {selectedProject.client.name.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <p className="text-white font-medium">{selectedProject.client.name}</p>
                    <p className="text-indigo-300 text-sm">{selectedProject.client.email}</p>
                  </div>
                </div>
              </div>
              
              {selectedProject.selectedFreelancer && (
                <div>
                  <h3 className="text-indigo-300 text-sm mb-2">Selected Freelancer</h3>
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-indigo-700 rounded-full flex items-center justify-center mr-3">
                      <span className="text-white font-medium">
                        {selectedProject.selectedFreelancer.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <p className="text-white font-medium">{selectedProject.selectedFreelancer.name}</p>
                      <p className="text-indigo-300 text-sm">{selectedProject.selectedFreelancer.email}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <div className="mb-6">
              <h3 className="text-indigo-300 text-sm mb-2">Bids ({selectedProject.bidCount || 0})</h3>
              
              {selectedProject.bidCount > 0 ? (
                <Link 
                  to={`/admin/bids/${selectedProject._id}`}
                  className="text-indigo-400 hover:text-indigo-300"
                >
                  View all bids
                </Link>
              ) : (
                <p className="text-indigo-400">No bids yet</p>
              )}
            </div>
            
            <div className="space-y-3 mt-6">
              <div className="flex flex-wrap gap-3">
                {selectedProject.status === 'pending' && (
                  <>
                    <GlowButton
                      variant="primary"
                      onClick={() => handleProjectAction('approve', selectedProject._id)}
                      disabled={processingAction}
                    >
                      {processingAction ? 'Processing...' : 'Approve Project'}
                    </GlowButton>
                    
                    <GlowButton
                      variant="secondary"
                      onClick={() => handleProjectAction('reject', selectedProject._id)}
                      disabled={processingAction}
                    >
                      {processingAction ? 'Processing...' : 'Reject Project'}
                    </GlowButton>
                  </>
                )}
                
                {selectedProject.featured ? (
                  <GlowButton
                    variant="secondary"
                    onClick={() => handleProjectAction('unfeature', selectedProject._id)}
                    disabled={processingAction}
                  >
                    {processingAction ? 'Processing...' : 'Remove Featured'}
                  </GlowButton>
                ) : (
                  <GlowButton
                    variant="secondary"
                    onClick={() => handleProjectAction('feature', selectedProject._id)}
                    disabled={processingAction}
                  >
                    {processingAction ? 'Processing...' : 'Feature Project'}
                  </GlowButton>
                )}
                
                <button
                  className="px-4 py-2 text-red-400 hover:text-red-300 border border-red-800 rounded-md hover:bg-red-900/20 transition-colors"
                  onClick={() => {
                    if (window.confirm('Are you sure you want to delete this project? This action cannot be undone.')) {
                      handleProjectAction('delete', selectedProject._id);
                    }
                  }}
                  disabled={processingAction}
                >
                  {processingAction ? 'Processing...' : 'Delete Project'}
                </button>
              </div>
              
              <div className="mt-4">
                <Link 
                  to={`/projects/${selectedProject._id}`}
                  className="text-indigo-400 hover:text-indigo-300 flex items-center"
                >
                  <span>View Project Page</span>
                  <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path>
                  </svg>
                </Link>
              </div>
            </div>
          </GlassCard>
        </motion.div>
      </div>
    );
  };
  
  // Loading state
  if (loading && projects.length === 0) {
    return <LoadingScreen />;
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      {renderProjectModal()}
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <h1 className="text-2xl font-bold text-white">Project Management</h1>
            <p className="text-indigo-300">
              Manage projects, review submissions, and monitor project activity
            </p>
          </div>
        </div>
        
        <GlassCard className="p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Search */}
            <div className="md:col-span-2">
              <form onSubmit={handleSearch}>
                <div className="relative">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search projects..."
                    className="w-full px-4 py-2 pl-10 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  />
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                    </svg>
                  </div>
                </div>
              </form>
            </div>
            
            {/* Category Filter */}
            <div>
              <select
                value={categoryFilter}
                onChange={(e) => {
                  setCategoryFilter(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="all">All Categories</option>
                {categories.map(category => (
                  <option key={category._id} value={category._id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>
            
            {/* Status Filter */}
            <div>
              <select
                value={statusFilter}
                onChange={(e) => {
                  setStatusFilter(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="active">Active</option>
                <option value="completed">Completed</option>
                <option value="canceled">Canceled</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>
        </GlassCard>
        
        <GlassCard className="p-0 overflow-hidden">
          {/* Projects Table */}
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-700">
              <thead className="bg-gray-800/50">
                <tr>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('title')}
                  >
                    <div className="flex items-center">
                      <span>Title</span>
                      {sortBy === 'title' && (
                        <svg 
                          className={`w-4 h-4 ml-1 ${sortOrder === 'asc' ? '' : 'transform rotate-180'}`} 
                          fill="none" 
                          stroke="currentColor" 
                          viewBox="0 0 24 24" 
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path>
                        </svg>
                      )}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('client.name')}
                  >
                    <div className="flex items-center">
                      <span>Client</span>
                      {sortBy === 'client.name' && (
                        <svg 
                          className={`w-4 h-4 ml-1 ${sortOrder === 'asc' ? '' : 'transform rotate-180'}`} 
                          fill="none" 
                          stroke="currentColor" 
                          viewBox="0 0 24 24" 
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path>
                        </svg>
                      )}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('budget')}
                  >
                    <div className="flex items-center">
                      <span>Budget</span>
                      {sortBy === 'budget' && (
                        <svg 
                          className={`w-4 h-4 ml-1 ${sortOrder === 'asc' ? '' : 'transform rotate-180'}`} 
                          fill="none" 
                          stroke="currentColor" 
                          viewBox="0 0 24 24" 
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path>
                        </svg>
                      )}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('status')}
                  >
                    <div className="flex items-center">
                      <span>Status</span>
                      {sortBy === 'status' && (
                        <svg 
                          className={`w-4 h-4 ml-1 ${sortOrder === 'asc' ? '' : 'transform rotate-180'}`} 
                          fill="none" 
                          stroke="currentColor" 
                          viewBox="0 0 24 24" 
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path>
                        </svg>
                      )}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('createdAt')}
                  >
                    <div className="flex items-center">
                      <span>Created</span>
                      {sortBy === 'createdAt' && (
                        <svg 
                          className={`w-4 h-4 ml-1 ${sortOrder === 'asc' ? '' : 'transform rotate-180'}`} 
                          fill="none" 
                          stroke="currentColor" 
                          viewBox="0 0 24 24" 
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path>
                        </svg>
                      )}
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-indigo-300 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {loading ? (
                  <tr>
                    <td colSpan="6" className="px-6 py-4 text-center">
                      <div className="flex justify-center">
                        <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-indigo-500"></div>
                      </div>
                    </td>
                  </tr>
                ) : projects.length > 0 ? (
                  projects.map((project) => (
                    <tr key={project._id} className="hover:bg-gray-800/50">
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <div className="text-sm font-medium text-white">
                            {project.title}
                            {project.featured && (
                              <span className="ml-2 px-2 py-0.5 text-xs bg-indigo-900/50 text-indigo-300 rounded-full">
                                Featured
                              </span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-indigo-200">{project.client.name}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-indigo-200">{formatCurrency(project.budget)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs rounded-full capitalize ${
                          project.status === 'active' 
                            ? 'bg-green-900/50 text-green-300' 
                            : project.status === 'pending' 
                              ? 'bg-yellow-900/50 text-yellow-300'
                              : project.status === 'completed'
                                ? 'bg-blue-900/50 text-blue-300'
                                : project.status === 'rejected'
                                  ? 'bg-red-900/50 text-red-300'
                                  : 'bg-gray-900/50 text-gray-300'
                        }`}>
                          {project.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-indigo-200">
                        {formatDate(project.createdAt)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button
                          onClick={() => viewProjectDetails(project)}
                          className="text-indigo-400 hover:text-indigo-300"
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="px-6 py-4 text-center text-indigo-300">
                      No projects found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          
          {/* Pagination */}
          {totalPages > 1 && (
            <div className="px-6 py-3 flex items-center justify-between border-t border-gray-700">
              <div>
                <p className="text-sm text-indigo-300">
                  Showing page {currentPage} of {totalPages}
                </p>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className={`px-3 py-1 rounded-md ${
                    currentPage === 1
                      ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                      : 'bg-gray-800 text-indigo-300 hover:bg-gray-700'
                  }`}
                >
                  Previous
                </button>
                <button
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                  className={`px-3 py-1 rounded-md ${
                    currentPage === totalPages
                      ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                      : 'bg-gray-800 text-indigo-300 hover:bg-gray-700'
                  }`}
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </GlassCard>
      </motion.div>
    </div>
  );
};

export default ProjectManagement;
