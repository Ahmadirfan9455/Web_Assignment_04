import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

// Admin sidebar component
const AdminSidebar = ({ activePage }) => {
  return (
    <div className="w-64 bg-gray-900/50 backdrop-blur-md border-r border-gray-800 h-screen fixed left-0 top-0 overflow-y-auto">
      <div className="p-6">
        <h2 className="text-2xl font-bold text-white mb-6">Admin Panel</h2>
        <nav className="space-y-2">
          <Link to="/admin/dashboard" className={`flex items-center px-4 py-3 rounded-lg ${activePage === 'dashboard' ? 'bg-indigo-900/50 text-white' : 'text-indigo-300 hover:bg-gray-800/50 hover:text-white'}`}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 20 20" fill="currentColor">
              <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z" />
            </svg>
            Dashboard
          </Link>
          <Link to="/admin/users" className={`flex items-center px-4 py-3 rounded-lg ${activePage === 'users' ? 'bg-indigo-900/50 text-white' : 'text-indigo-300 hover:bg-gray-800/50 hover:text-white'}`}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 20 20" fill="currentColor">
              <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
            </svg>
            Users
          </Link>
          <Link to="/admin/projects" className={`flex items-center px-4 py-3 rounded-lg ${activePage === 'projects' ? 'bg-indigo-900/50 text-white' : 'text-indigo-300 hover:bg-gray-800/50 hover:text-white'}`}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M3 5a2 2 0 012-2h10a2 2 0 012 2v10a2 2 0 01-2 2H5a2 2 0 01-2-2V5zm11 1H6v8l4-2 4 2V6z" clipRule="evenodd" />
            </svg>
            Projects
          </Link>
          <Link to="/admin/contracts" className={`flex items-center px-4 py-3 rounded-lg ${activePage === 'contracts' ? 'bg-indigo-900/50 text-white' : 'text-indigo-300 hover:bg-gray-800/50 hover:text-white'}`}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
            </svg>
            Contracts
          </Link>
          <Link to="/admin/time-tracking" className={`flex items-center px-4 py-3 rounded-lg ${activePage === 'time-tracking' ? 'bg-indigo-900/50 text-white' : 'text-indigo-300 hover:bg-gray-800/50 hover:text-white'}`}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
            </svg>
            Time Tracking
          </Link>
          <Link to="/admin/milestone-tracking" className={`flex items-center px-4 py-3 rounded-lg ${activePage === 'milestone-tracking' ? 'bg-indigo-900/50 text-white' : 'text-indigo-300 hover:bg-gray-800/50 hover:text-white'}`}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
            </svg>
            Milestone Tracking
          </Link>
          <Link to="/admin/analytics" className={`flex items-center px-4 py-3 rounded-lg ${activePage === 'analytics' ? 'bg-indigo-900/50 text-white' : 'text-indigo-300 hover:bg-gray-800/50 hover:text-white'}`}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 20 20" fill="currentColor">
              <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" />
            </svg>
            Analytics
          </Link>
          <Link to="/admin/settings" className={`flex items-center px-4 py-3 rounded-lg ${activePage === 'settings' ? 'bg-indigo-900/50 text-white' : 'text-indigo-300 hover:bg-gray-800/50 hover:text-white'}`}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
            </svg>
            Settings
          </Link>
        </nav>
      </div>
    </div>
  );
};

const DashboardNew = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeProjects: 0,
    completedProjects: 0,
    totalRevenue: 0,
    pendingVerifications: 0,
    activeContracts: 0,
    pendingTimeEntries: 0,
    pendingMilestones: 0
  });

  // Simulate fetching dashboard data
  useEffect(() => {
    const timer = setTimeout(() => {
      // Mock stats data
      setStats({
        totalUsers: 125,
        activeProjects: 42,
        completedProjects: 87,
        totalRevenue: 24500,
        pendingVerifications: 8,
        activeContracts: 38,
        pendingTimeEntries: 12,
        pendingMilestones: 5
      });
      setLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <div className="flex">
      <AdminSidebar activePage="dashboard" />
      
      <div className="ml-64 flex-1 p-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold text-white">Admin Dashboard</h1>
              <p className="text-indigo-300 mt-2">Welcome back, {user?.name || 'Admin'}</p>
            </div>
            <div className="flex space-x-4">
              <Link to="/admin/settings">
                <GlowButton variant="secondary">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
                  </svg>
                  Settings
                </GlowButton>
              </Link>
              <Link to="/">
                <GlowButton variant="primary">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
                  </svg>
                  Main Site
                </GlowButton>
              </Link>
            </div>
          </div>
          
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-white mb-2">Total Users</h3>
              <div className="text-3xl font-bold text-white">{stats.totalUsers}</div>
              <div className="flex justify-between items-center mt-4">
                <Link to="/admin/users" className="text-indigo-400 hover:text-indigo-300 text-sm">
                  View All Users
                </Link>
                <div className="w-10 h-10 rounded-full bg-indigo-900/50 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-300" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
                  </svg>
                </div>
              </div>
            </GlassCard>
            
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-white mb-2">Active Projects</h3>
              <div className="text-3xl font-bold text-white">{stats.activeProjects}</div>
              <div className="flex justify-between items-center mt-4">
                <Link to="/admin/projects" className="text-indigo-400 hover:text-indigo-300 text-sm">
                  View All Projects
                </Link>
                <div className="w-10 h-10 rounded-full bg-indigo-900/50 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-300" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M3 5a2 2 0 012-2h10a2 2 0 012 2v10a2 2 0 01-2 2H5a2 2 0 01-2-2V5zm11 1H6v8l4-2 4 2V6z" clipRule="evenodd" />
                  </svg>
                </div>
              </div>
            </GlassCard>
            
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-white mb-2">Active Contracts</h3>
              <div className="text-3xl font-bold text-white">{stats.activeContracts}</div>
              <div className="flex justify-between items-center mt-4">
                <Link to="/admin/contracts" className="text-indigo-400 hover:text-indigo-300 text-sm">
                  View All Contracts
                </Link>
                <div className="w-10 h-10 rounded-full bg-indigo-900/50 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-300" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z" clipRule="evenodd" />
                  </svg>
                </div>
              </div>
            </GlassCard>
            
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-white mb-2">Total Revenue</h3>
              <div className="text-3xl font-bold text-white">${stats.totalRevenue.toLocaleString()}</div>
              <div className="flex justify-between items-center mt-4">
                <Link to="/admin/analytics" className="text-indigo-400 hover:text-indigo-300 text-sm">
                  View Analytics
                </Link>
                <div className="w-10 h-10 rounded-full bg-indigo-900/50 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-300" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z" />
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z" clipRule="evenodd" />
                  </svg>
                </div>
              </div>
            </GlassCard>
          </div>
          
          {/* Action Items */}
          <h2 className="text-2xl font-bold text-white mb-6">Action Items</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-white mb-4">Pending Verifications</h3>
              {stats.pendingVerifications > 0 ? (
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-indigo-300">{stats.pendingVerifications} users awaiting verification</span>
                    <span className="px-3 py-1 bg-yellow-900/50 text-yellow-300 rounded-full text-sm">Pending</span>
                  </div>
                  <Link to="/admin/users">
                    <GlowButton variant="secondary" className="w-full">
                      Review Verifications
                    </GlowButton>
                  </Link>
                </div>
              ) : (
                <p className="text-indigo-300">No pending verifications at this time.</p>
              )}
            </GlassCard>
            
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-white mb-4">Pending Time Entries</h3>
              {stats.pendingTimeEntries > 0 ? (
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-indigo-300">{stats.pendingTimeEntries} time entries awaiting approval</span>
                    <span className="px-3 py-1 bg-yellow-900/50 text-yellow-300 rounded-full text-sm">Pending</span>
                  </div>
                  <Link to="/admin/time-tracking">
                    <GlowButton variant="secondary" className="w-full">
                      Review Time Entries
                    </GlowButton>
                  </Link>
                </div>
              ) : (
                <p className="text-indigo-300">No pending time entries at this time.</p>
              )}
            </GlassCard>
            
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-white mb-4">Pending Milestones</h3>
              {stats.pendingMilestones > 0 ? (
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-indigo-300">{stats.pendingMilestones} milestones awaiting approval</span>
                    <span className="px-3 py-1 bg-yellow-900/50 text-yellow-300 rounded-full text-sm">Pending</span>
                  </div>
                  <Link to="/admin/milestone-tracking">
                    <GlowButton variant="secondary" className="w-full">
                      Review Milestones
                    </GlowButton>
                  </Link>
                </div>
              ) : (
                <p className="text-indigo-300">No pending milestones at this time.</p>
              )}
            </GlassCard>
            
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-white mb-4">Platform Settings</h3>
              <p className="text-indigo-300 mb-4">Configure platform settings and preferences.</p>
              <Link to="/admin/settings">
                <GlowButton variant="secondary" className="w-full">
                  Manage Settings
                </GlowButton>
              </Link>
            </GlassCard>
          </div>
          
          {/* Quick Stats */}
          <h2 className="text-2xl font-bold text-white mb-6">Platform Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-white mb-4">Project Statistics</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-indigo-300">Active Projects</span>
                  <span className="text-white font-medium">{stats.activeProjects}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-indigo-300">Completed Projects</span>
                  <span className="text-white font-medium">{stats.completedProjects}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-indigo-300">Total Projects</span>
                  <span className="text-white font-medium">{stats.activeProjects + stats.completedProjects}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-indigo-300">Completion Rate</span>
                  <span className="text-white font-medium">
                    {Math.round((stats.completedProjects / (stats.activeProjects + stats.completedProjects)) * 100)}%
                  </span>
                </div>
              </div>
            </GlassCard>
            
            <GlassCard className="p-6">
              <h3 className="text-lg font-medium text-white mb-4">User Statistics</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-indigo-300">Total Users</span>
                  <span className="text-white font-medium">{stats.totalUsers}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-indigo-300">Freelancers</span>
                  <span className="text-white font-medium">{Math.round(stats.totalUsers * 0.6)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-indigo-300">Clients</span>
                  <span className="text-white font-medium">{Math.round(stats.totalUsers * 0.4)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-indigo-300">New Users (Last 30 Days)</span>
                  <span className="text-white font-medium">{Math.round(stats.totalUsers * 0.15)}</span>
                </div>
              </div>
            </GlassCard>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default DashboardNew;
