import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import { Link } from 'react-router-dom';
import { getTimeEntries, getTimeEntryStats, getActiveProjects, getFreelancers, approveTimeEntry, rejectTimeEntry } from '../../services/timeEntryService';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

const TimeTracking = () => {
  // State
  const [loading, setLoading] = useState(true);
  const [timeEntries, setTimeEntries] = useState([]);
  const [projects, setProjects] = useState([]);
  const [freelancers, setFreelancers] = useState([]);
  const [stats, setStats] = useState({
    pendingApprovals: 0,
    hoursLoggedThisWeek: 0,
    activeFreelancers: 0
  });
  const [filters, setFilters] = useState({
    project: 'all',
    freelancer: 'all',
    status: 'all',
    startDate: '',
    endDate: '',
    sortBy: 'createdAt',
    sortOrder: 'desc'
  });
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 1
  });
  const [selectedTimeEntry, setSelectedTimeEntry] = useState(null);
  const [showTimeEntryModal, setShowTimeEntryModal] = useState(false);
  const [processingAction, setProcessingAction] = useState(false);
  const [approvalNote, setApprovalNote] = useState('');
  const [rejectionReason, setRejectionReason] = useState('');
  
  // Fetch time entries
  useEffect(() => {
    const fetchTimeEntries = async () => {
      try {
        setLoading(true);

        // Prepare filters
        const filterParams = {
          sortBy: filters.sortBy,
          sortOrder: filters.sortOrder,
          ...(filters.project !== 'all' && { project: filters.project }),
          ...(filters.freelancer !== 'all' && { freelancer: filters.freelancer }),
          ...(filters.status !== 'all' && { status: filters.status }),
          ...(filters.startDate && { startDate: filters.startDate }),
          ...(filters.endDate && { endDate: filters.endDate })
        };

        // Fetch time entries using service
        const timeEntriesData = await getTimeEntries(filterParams, pagination.page, pagination.limit);
        setTimeEntries(timeEntriesData.timeEntries);
        setPagination({
          ...pagination,
          total: timeEntriesData.total,
          totalPages: timeEntriesData.totalPages
        });

        // Fetch time entry stats
        const statsData = await getTimeEntryStats();
        setStats(statsData.stats);

        // Fetch projects if not already loaded
        if (projects.length === 0) {
          const projectsData = await getActiveProjects();
          setProjects(projectsData.projects);
        }

        // Fetch freelancers if not already loaded
        if (freelancers.length === 0) {
          const freelancersData = await getFreelancers();
          setFreelancers(freelancersData.freelancers);
        }

        setLoading(false);
      } catch (error) {
        console.error('Error fetching time entries:', error);
        toast.error('Failed to load time entry data');
        setLoading(false);
      }
    };

    fetchTimeEntries();
  }, [pagination.page, filters, projects.length, freelancers.length]);

  // Handle filter changes
  const handleFilterChange = (filter, value) => {
    setFilters(prev => ({
      ...prev,
      [filter]: value
    }));
    setPagination(prev => ({
      ...prev,
      page: 1 // Reset to first page on filter change
    }));
  };
  
  // Format duration (minutes to hours and minutes)
  const formatDuration = (minutes) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
  };
  
  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  // Handle time entry approval
  const handleApproveTimeEntry = async (timeEntryId, note) => {
    try {
      setProcessingAction(true);
      await approveTimeEntry(timeEntryId, note);
      
      // Update local state
      setTimeEntries(prev => prev.map(timeEntry => 
        timeEntry._id === timeEntryId ? { ...timeEntry, status: 'approved' } : timeEntry
      ));
      
      toast.success('Time entry approved successfully');
      setShowTimeEntryModal(false);
      setApprovalNote('');
    } catch (error) {
      console.error('Error approving time entry:', error);
      toast.error('Failed to approve time entry');
    } finally {
      setProcessingAction(false);
    }
  };
  
  // Handle time entry rejection
  const handleRejectTimeEntry = async (timeEntryId, reason) => {
    try {
      if (!reason) {
        toast.error('Please provide a reason for rejection');
        return;
      }
      
      setProcessingAction(true);
      await rejectTimeEntry(timeEntryId, reason);
      
      // Update local state
      setTimeEntries(prev => prev.map(timeEntry => 
        timeEntry._id === timeEntryId ? { ...timeEntry, status: 'rejected', rejectionReason: reason } : timeEntry
      ));
      
      toast.success('Time entry rejected successfully');
      setShowTimeEntryModal(false);
    } catch (error) {
      console.error('Error rejecting time entry:', error);
      toast.error('Failed to reject time entry');
    } finally {
      setProcessingAction(false);
    }
  };
  
  // View time entry details
  const viewTimeEntryDetails = (timeEntry) => {
    setSelectedTimeEntry(timeEntry);
    setShowTimeEntryModal(true);
  };
  
  // Time entry modal
  const renderTimeEntryModal = () => {
    if (!selectedTimeEntry || !showTimeEntryModal) return null;
    
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          className="w-full max-w-2xl max-h-[90vh] overflow-y-auto"
        >
          <GlassCard className="p-6">
            <div className="flex justify-between items-start mb-6">
              <h2 className="text-xl font-semibold text-white">Time Entry Details</h2>
              <button
                onClick={() => setShowTimeEntryModal(false)}
                className="text-indigo-300 hover:text-indigo-200"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
              </button>
            </div>
            
            <div className="mb-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-indigo-300 text-sm">Project</p>
                  <p className="text-white font-medium">{selectedTimeEntry.project.title}</p>
                </div>
                
                <div>
                  <p className="text-indigo-300 text-sm">Freelancer</p>
                  <p className="text-white font-medium">{selectedTimeEntry.user.name}</p>
                </div>
                
                <div>
                  <p className="text-indigo-300 text-sm">Date</p>
                  <p className="text-white font-medium">{formatDate(selectedTimeEntry.date)}</p>
                </div>
                
                <div>
                  <p className="text-indigo-300 text-sm">Duration</p>
                  <p className="text-white font-medium">{formatDuration(selectedTimeEntry.duration)}</p>
                </div>
                
                <div>
                  <p className="text-indigo-300 text-sm">Status</p>
                  <p className={`font-medium capitalize ${
                    selectedTimeEntry.status === 'approved' 
                      ? 'text-green-400' 
                      : selectedTimeEntry.status === 'rejected'
                        ? 'text-red-400'
                        : 'text-yellow-400'
                  }`}>
                    {selectedTimeEntry.status}
                  </p>
                </div>
                
                <div>
                  <p className="text-indigo-300 text-sm">Hourly Rate</p>
                  <p className="text-white font-medium">${selectedTimeEntry.hourlyRate.toFixed(2)}</p>
                </div>
              </div>
              
              <div className="mb-4">
                <p className="text-indigo-300 text-sm mb-1">Description</p>
                <p className="text-white">{selectedTimeEntry.description}</p>
              </div>
              
              {selectedTimeEntry.tasks && selectedTimeEntry.tasks.length > 0 && (
                <div className="mb-4">
                  <p className="text-indigo-300 text-sm mb-1">Tasks Completed</p>
                  <ul className="list-disc pl-5 text-white">
                    {selectedTimeEntry.tasks.map((task, index) => (
                      <li key={index}>{task}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
            
            {selectedTimeEntry.status === 'pending' && (
              <div className="flex flex-col space-y-4">
                <div className="mb-4">
                  <label htmlFor="approvalNote" className="block text-sm font-medium text-indigo-300 mb-1">Note (optional)</label>
                  <textarea
                    id="approvalNote"
                    value={approvalNote}
                    onChange={(e) => setApprovalNote(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    rows="2"
                  />
                </div>
                
                <div className="flex space-x-3">
                  <GlowButton
                    variant="primary"
                    onClick={() => handleApproveTimeEntry(selectedTimeEntry._id, approvalNote)}
                    disabled={processingAction}
                  >
                    {processingAction ? 'Processing...' : 'Approve Entry'}
                  </GlowButton>
                  
                  <GlowButton
                    variant="secondary"
                    onClick={() => {
                      const reason = prompt('Please provide a reason for rejection:');
                      if (reason) handleRejectTimeEntry(selectedTimeEntry._id, reason);
                    }}
                    disabled={processingAction}
                  >
                    {processingAction ? 'Processing...' : 'Reject Entry'}
                  </GlowButton>
                </div>
              </div>
            )}
          </GlassCard>
        </motion.div>
      </div>
    );
  };
  
  // Loading state
  if (loading && timeEntries.length === 0) {
    return <LoadingScreen />;
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      {renderTimeEntryModal()}
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <h1 className="text-2xl font-bold text-white">Time Tracking Management</h1>
            <p className="text-indigo-300">
              Review and approve time entries for hourly projects
            </p>
          </div>
          
          <div className="mt-4 md:mt-0">
            <select
              value={filters.dateRange}
              onChange={(e) => handleFilterChange('dateRange', e.target.value)}
              className="px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="today">Today</option>
              <option value="week">This Week</option>
              <option value="month">This Month</option>
              <option value="all">All Time</option>
            </select>
          </div>
        </div>
        
        <GlassCard className="p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Project Filter */}
            <div>
              <label className="block text-indigo-300 text-sm font-medium mb-2">
                Project
              </label>
              <select
                value={filters.project}
                onChange={(e) => handleFilterChange('project', e.target.value)}
                className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="all">All Projects</option>
                {projects.map(project => (
                  <option key={project._id} value={project._id}>
                    {project.title}
                  </option>
                ))}
              </select>
            </div>
            
            {/* User Filter */}
            <div>
              <label className="block text-indigo-300 text-sm font-medium mb-2">
                Freelancer
              </label>
              <select
                value={filters.user}
                onChange={(e) => handleFilterChange('user', e.target.value)}
                className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="all">All Freelancers</option>
                {users.map(user => (
                  <option key={user._id} value={user._id}>
                    {user.name}
                  </option>
                ))}
              </select>
            </div>
            
            {/* Status Filter */}
            <div>
              <label className="block text-indigo-300 text-sm font-medium mb-2">
                Status
              </label>
              <select
                value={filters.status}
                onChange={(e) => handleFilterChange('status', e.target.value)}
                className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="all">All Statuses</option>
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>
        </GlassCard>
        
        <GlassCard className="p-0 overflow-hidden">
          {/* Time Entries Table */}
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-700">
              <thead className="bg-gray-800/50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                    Project
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                    Freelancer
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                    Date
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                    Duration
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider">
                    Status
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-indigo-300 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {loading ? (
                  <tr>
                    <td colSpan="6" className="px-6 py-4 text-center">
                      <div className="flex justify-center">
                        <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-indigo-500"></div>
                      </div>
                    </td>
                  </tr>
                ) : timeEntries.length > 0 ? (
                  timeEntries.map((entry) => (
                    <tr key={entry._id} className="hover:bg-gray-800/50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-white">
                          {entry.project.title}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-indigo-200">{entry.user.name}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-indigo-200">{formatDate(entry.date)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-indigo-200">{formatDuration(entry.duration)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs rounded-full capitalize ${
                          entry.status === 'approved' 
                            ? 'bg-green-900/50 text-green-300' 
                            : entry.status === 'rejected'
                              ? 'bg-red-900/50 text-red-300'
                              : 'bg-yellow-900/50 text-yellow-300'
                        }`}>
                          {entry.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button
                          onClick={() => viewTimeEntryDetails(entry)}
                          className="text-indigo-400 hover:text-indigo-300"
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="px-6 py-4 text-center text-indigo-300">
                      No time entries found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          
          {/* Pagination */}
          {pagination.totalPages > 1 && (
            <div className="px-6 py-3 flex items-center justify-between border-t border-gray-700">
              <div>
                <p className="text-sm text-indigo-300">
                  Showing page {pagination.page} of {pagination.totalPages}
                </p>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => setPagination(prev => ({ ...prev, page: Math.max(prev.page - 1, 1) }))}
                  disabled={pagination.page === 1}
                  className={`px-3 py-1 rounded-md ${
                    pagination.page === 1
                      ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                      : 'bg-gray-800 text-indigo-300 hover:bg-gray-700'
                  }`}
                >
                  Previous
                </button>
                <button
                  onClick={() => setPagination(prev => ({ ...prev, page: Math.min(prev.page + 1, prev.totalPages) }))}
                  disabled={pagination.page === pagination.totalPages}
                  className={`px-3 py-1 rounded-md ${
                    pagination.page === pagination.totalPages
                      ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                      : 'bg-gray-800 text-indigo-300 hover:bg-gray-700'
                  }`}
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </GlassCard>
        
        {/* Time Tracking Summary */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <GlassCard className="p-6">
            <h3 className="text-lg font-medium text-white mb-4">Pending Approvals</h3>
            <div className="text-3xl font-bold text-white">
              {timeEntries.filter(entry => entry.status === 'pending').length}
            </div>
            <p className="text-indigo-300 mt-2">Time entries awaiting review</p>
          </GlassCard>
          
          <GlassCard className="p-6">
            <h3 className="text-lg font-medium text-white mb-4">Total Hours This Week</h3>
            <div className="text-3xl font-bold text-white">
              {formatDuration(timeEntries.reduce((total, entry) => {
                const entryDate = new Date(entry.date);
                const now = new Date();
                const weekStart = new Date(now.setDate(now.getDate() - now.getDay()));
                weekStart.setHours(0, 0, 0, 0);
                
                return entryDate >= weekStart ? total + entry.duration : total;
              }, 0))}
            </div>
            <p className="text-indigo-300 mt-2">Hours logged this week</p>
          </GlassCard>
          
          <GlassCard className="p-6">
            <h3 className="text-lg font-medium text-white mb-4">Active Freelancers</h3>
            <div className="text-3xl font-bold text-white">
              {new Set(timeEntries.map(entry => entry.user._id)).size}
            </div>
            <p className="text-indigo-300 mt-2">Freelancers with time entries</p>
          </GlassCard>
        </div>
      </motion.div>
    </div>
  );
};

export default TimeTracking;
