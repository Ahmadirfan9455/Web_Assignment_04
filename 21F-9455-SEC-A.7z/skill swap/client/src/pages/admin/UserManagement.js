import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../../components/ui/GlassCard';
import GlowButton from '../../components/ui/GlowButton';
import LoadingScreen from '../../components/ui/LoadingScreen';

const UserManagement = () => {
  const { user } = useAuth();
  
  // State
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortBy, setSortBy] = useState('createdAt');
  const [sortOrder, setSortOrder] = useState('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [selectedUser, setSelectedUser] = useState(null);
  const [showUserModal, setShowUserModal] = useState(false);
  const [processingAction, setProcessingAction] = useState(false);
  
  // Fetch users
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setLoading(true);
        
        const params = {
          page: currentPage,
          limit: 10,
          sortBy: sortBy,
          sortOrder: sortOrder,
          role: roleFilter !== 'all' ? roleFilter : undefined,
          status: statusFilter !== 'all' ? statusFilter : undefined,
          search: searchQuery || undefined
        };
        
        const { data } = await axios.get('/api/admin/users', { params });
        
        setUsers(data.users || []);
        setTotalPages(data.totalPages || 1);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching users:', error);
        toast.error('Failed to load users: ' + (error.response?.data?.message || error.message));
        setLoading(false);
        setUsers([]);
      }
    };
    
    fetchUsers();
  }, [currentPage, sortBy, sortOrder, searchQuery, roleFilter, statusFilter]);
  
  // Handle search
  const handleSearch = (e) => {
    e.preventDefault();
    setCurrentPage(1); // Reset to first page on new search
  };
  
  // Handle sort
  const handleSort = (field) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('asc');
    }
    setCurrentPage(1); // Reset to first page on new sort
  };
  
  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  // Handle user action (verify, suspend, activate, delete)
  const handleUserAction = async (userId, action) => {
    setProcessingAction(true);
    try {
      let endpoint;
      let successMessage;
      
      switch (action) {
        case 'verify':
          endpoint = `/api/admin/users/${userId}/status`;
          successMessage = 'User verified successfully';
          await axios.put(endpoint, { status: 'active' });
          break;
        case 'suspend':
          endpoint = `/api/admin/users/${userId}/status`;
          successMessage = 'User suspended successfully';
          await axios.put(endpoint, { status: 'inactive' });
          break;
        case 'activate':
          endpoint = `/api/admin/users/${userId}/status`;
          successMessage = 'User activated successfully';
          await axios.put(endpoint, { status: 'active' });
          break;
        case 'delete':
          endpoint = `/api/admin/users/${userId}`;
          successMessage = 'User deleted successfully';
          await axios.delete(endpoint);
          break;
        default:
          throw new Error('Invalid action');
      }
      
      // Update local state
      if (action === 'delete') {
        setUsers(prev => prev.filter(u => u._id !== userId));
      } else {
        setUsers(prev => prev.map(u => {
          if (u._id === userId) {
            if (action === 'verify') {
              return { ...u, isVerified: true, status: 'active' };
            } else if (action === 'suspend') {
              return { ...u, status: 'inactive' };
            } else if (action === 'activate') {
              return { ...u, status: 'active' };
            }
          }
          return u;
        }));
      }
      
      toast.success(successMessage);
      setShowUserModal(false);
    } catch (error) {
      console.error(`Error performing ${action} action:`, error);
      toast.error(`Failed to ${action} user. ${error.response?.data?.message || ''}`);
    } finally {
      setProcessingAction(false);
    }
  };
  
  // View user details
  const viewUserDetails = (user) => {
    setSelectedUser(user);
    setShowUserModal(true);
  };
  
  // User modal
  const renderUserModal = () => {
    if (!selectedUser || !showUserModal) return null;
    
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          className="w-full max-w-2xl"
        >
          <GlassCard className="p-6">
            <div className="flex justify-between items-start mb-6">
              <h2 className="text-xl font-semibold text-white">User Details</h2>
              <button
                onClick={() => setShowUserModal(false)}
                className="text-indigo-300 hover:text-indigo-200"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <div className="flex items-center mb-4">
                  <div className="w-16 h-16 bg-indigo-700 rounded-full flex items-center justify-center mr-4">
                    {selectedUser.profileImage ? (
                      <img 
                        src={selectedUser.profileImage} 
                        alt={selectedUser.name} 
                        className="w-16 h-16 rounded-full object-cover"
                      />
                    ) : (
                      <span className="text-white text-2xl font-bold">
                        {selectedUser.name.charAt(0).toUpperCase()}
                      </span>
                    )}
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-white">{selectedUser.name}</h3>
                    <p className="text-indigo-300">{selectedUser.email}</p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div>
                    <p className="text-indigo-300 text-sm">Role</p>
                    <p className="text-white capitalize">{selectedUser.role}</p>
                  </div>
                  
                  <div>
                    <p className="text-indigo-300 text-sm">Status</p>
                    <p className="text-white capitalize">{selectedUser.status}</p>
                  </div>
                  
                  <div>
                    <p className="text-indigo-300 text-sm">Verified</p>
                    <p className="text-white">{selectedUser.isVerified ? 'Yes' : 'No'}</p>
                  </div>
                  
                  <div>
                    <p className="text-indigo-300 text-sm">Joined</p>
                    <p className="text-white">{formatDate(selectedUser.createdAt)}</p>
                  </div>
                </div>
              </div>
              
              <div>
                {selectedUser.role === 'freelancer' && (
                  <div className="mb-4">
                    <p className="text-indigo-300 text-sm mb-1">Skills</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedUser.skills && selectedUser.skills.length > 0 ? (
                        selectedUser.skills.map((skill, index) => (
                          <span 
                            key={index}
                            className="px-2 py-1 bg-indigo-900/50 rounded-full text-xs text-indigo-300"
                          >
                            {skill}
                          </span>
                        ))
                      ) : (
                        <p className="text-indigo-400">No skills listed</p>
                      )}
                    </div>
                  </div>
                )}
                
                <div className="mb-4">
                  <p className="text-indigo-300 text-sm mb-1">Bio</p>
                  <p className="text-white">
                    {selectedUser.bio || 'No bio provided'}
                  </p>
                </div>
                
                <div className="space-y-3 mt-6">
                  {!selectedUser.isVerified && (
                    <GlowButton
                      variant="primary"
                      className="w-full"
                      onClick={() => handleUserAction(selectedUser._id, 'verify')}
                      disabled={processingAction}
                    >
                      {processingAction ? 'Processing...' : 'Verify User'}
                    </GlowButton>
                  )}
                  
                  {selectedUser.status === 'active' ? (
                    <GlowButton
                      variant="secondary"
                      className="w-full"
                      onClick={() => handleUserAction(selectedUser._id, 'suspend')}
                      disabled={processingAction}
                    >
                      {processingAction ? 'Processing...' : 'Suspend User'}
                    </GlowButton>
                  ) : (
                    <GlowButton
                      variant="secondary"
                      className="w-full"
                      onClick={() => handleUserAction(selectedUser._id, 'activate')}
                      disabled={processingAction}
                    >
                      {processingAction ? 'Processing...' : 'Activate User'}
                    </GlowButton>
                  )}
                  
                  <button
                    className="w-full px-4 py-2 text-red-400 hover:text-red-300 border border-red-800 rounded-md hover:bg-red-900/20 transition-colors"
                    onClick={() => {
                      if (window.confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
                        handleUserAction(selectedUser._id, 'delete');
                      }
                    }}
                    disabled={processingAction}
                  >
                    {processingAction ? 'Processing...' : 'Delete User'}
                  </button>
                </div>
              </div>
            </div>
          </GlassCard>
        </motion.div>
      </div>
    );
  };
  
  // Loading state
  if (loading && users.length === 0) {
    return <LoadingScreen />;
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      {renderUserModal()}
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <h1 className="text-2xl font-bold text-white">User Management</h1>
            <p className="text-indigo-300">
              Manage users, verify accounts, and monitor user activity
            </p>
          </div>
        </div>
        
        <GlassCard className="p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Search */}
            <div className="md:col-span-2">
              <form onSubmit={handleSearch}>
                <div className="relative">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search by name or email..."
                    className="w-full px-4 py-2 pl-10 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  />
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                    </svg>
                  </div>
                </div>
              </form>
            </div>
            
            {/* Role Filter */}
            <div>
              <select
                value={roleFilter}
                onChange={(e) => {
                  setRoleFilter(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="all">All Roles</option>
                <option value="client">Clients</option>
                <option value="freelancer">Freelancers</option>
                <option value="admin">Admins</option>
              </select>
            </div>
            
            {/* Status Filter */}
            <div>
              <select
                value={statusFilter}
                onChange={(e) => {
                  setStatusFilter(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="all">All Status</option>
                <option value="active">Active</option>
                <option value="suspended">Suspended</option>
                <option value="pending">Pending</option>
              </select>
            </div>
          </div>
        </GlassCard>
        
        <GlassCard className="p-0 overflow-hidden">
          {/* Users Table */}
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-700">
              <thead className="bg-gray-800/50">
                <tr>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('name')}
                  >
                    <div className="flex items-center">
                      <span>Name</span>
                      {sortBy === 'name' && (
                        <svg 
                          className={`w-4 h-4 ml-1 ${sortOrder === 'asc' ? '' : 'transform rotate-180'}`} 
                          fill="none" 
                          stroke="currentColor" 
                          viewBox="0 0 24 24" 
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path>
                        </svg>
                      )}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('email')}
                  >
                    <div className="flex items-center">
                      <span>Email</span>
                      {sortBy === 'email' && (
                        <svg 
                          className={`w-4 h-4 ml-1 ${sortOrder === 'asc' ? '' : 'transform rotate-180'}`} 
                          fill="none" 
                          stroke="currentColor" 
                          viewBox="0 0 24 24" 
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path>
                        </svg>
                      )}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('role')}
                  >
                    <div className="flex items-center">
                      <span>Role</span>
                      {sortBy === 'role' && (
                        <svg 
                          className={`w-4 h-4 ml-1 ${sortOrder === 'asc' ? '' : 'transform rotate-180'}`} 
                          fill="none" 
                          stroke="currentColor" 
                          viewBox="0 0 24 24" 
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path>
                        </svg>
                      )}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('status')}
                  >
                    <div className="flex items-center">
                      <span>Status</span>
                      {sortBy === 'status' && (
                        <svg 
                          className={`w-4 h-4 ml-1 ${sortOrder === 'asc' ? '' : 'transform rotate-180'}`} 
                          fill="none" 
                          stroke="currentColor" 
                          viewBox="0 0 24 24" 
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path>
                        </svg>
                      )}
                    </div>
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-indigo-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('createdAt')}
                  >
                    <div className="flex items-center">
                      <span>Joined</span>
                      {sortBy === 'createdAt' && (
                        <svg 
                          className={`w-4 h-4 ml-1 ${sortOrder === 'asc' ? '' : 'transform rotate-180'}`} 
                          fill="none" 
                          stroke="currentColor" 
                          viewBox="0 0 24 24" 
                          xmlns="http://www.w3.org/2000/svg"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7"></path>
                        </svg>
                      )}
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-indigo-300 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {loading ? (
                  <tr>
                    <td colSpan="6" className="px-6 py-4 text-center">
                      <div className="flex justify-center">
                        <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-indigo-500"></div>
                      </div>
                    </td>
                  </tr>
                ) : users.length > 0 ? (
                  users.map((user) => (
                    <tr key={user._id} className="hover:bg-gray-800/50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10">
                            <div className="h-10 w-10 rounded-full bg-indigo-700 flex items-center justify-center">
                              {user.profileImage ? (
                                <img 
                                  src={user.profileImage} 
                                  alt={user.name} 
                                  className="h-10 w-10 rounded-full object-cover"
                                />
                              ) : (
                                <span className="text-white font-medium">
                                  {user.name.charAt(0).toUpperCase()}
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-white">
                              {user.name}
                            </div>
                            {!user.isVerified && (
                              <span className="px-2 py-0.5 text-xs bg-yellow-900/50 text-yellow-300 rounded-full">
                                Unverified
                              </span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-indigo-200">{user.email}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="px-2 py-1 text-xs rounded-full capitalize bg-indigo-900/50 text-indigo-300">
                          {user.role}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs rounded-full capitalize ${
                          user.status === 'active' 
                            ? 'bg-green-900/50 text-green-300' 
                            : user.status === 'suspended' 
                              ? 'bg-red-900/50 text-red-300'
                              : 'bg-yellow-900/50 text-yellow-300'
                        }`}>
                          {user.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-indigo-200">
                        {formatDate(user.createdAt)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button
                          onClick={() => viewUserDetails(user)}
                          className="text-indigo-400 hover:text-indigo-300"
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="px-6 py-4 text-center text-indigo-300">
                      No users found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          
          {/* Pagination */}
          {totalPages > 1 && (
            <div className="px-6 py-3 flex items-center justify-between border-t border-gray-700">
              <div>
                <p className="text-sm text-indigo-300">
                  Showing page {currentPage} of {totalPages}
                </p>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className={`px-3 py-1 rounded-md ${
                    currentPage === 1
                      ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                      : 'bg-gray-800 text-indigo-300 hover:bg-gray-700'
                  }`}
                >
                  Previous
                </button>
                <button
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                  className={`px-3 py-1 rounded-md ${
                    currentPage === totalPages
                      ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                      : 'bg-gray-800 text-indigo-300 hover:bg-gray-700'
                  }`}
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </GlassCard>
      </motion.div>
    </div>
  );
};

export default UserManagement;
