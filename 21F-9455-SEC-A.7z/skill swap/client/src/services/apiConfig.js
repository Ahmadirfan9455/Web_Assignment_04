/**
 * API Configuration
 * 
 * This file contains the base configuration for API requests
 * and handles environment-specific settings
 */

// Base API URL - defaults to localhost if not specified in environment
export const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';
console.log('API Base URL:', API_BASE_URL); // Debug log to verify the URL

// Socket URL - defaults to localhost if not specified in environment
export const SOCKET_URL = process.env.REACT_APP_SOCKET_URL || window.location.hostname === 'localhost' 
  ? 'http://localhost:5000'
  : window.location.origin.replace(/^http/, 'ws');
console.log('Socket URL:', SOCKET_URL); // Debug log to verify the URL

// Request timeout in milliseconds
export const REQUEST_TIMEOUT = 30000; // 30 seconds

// Configure axios defaults
import axios from 'axios';

// Set base URL for all requests
axios.defaults.baseURL = API_BASE_URL;

// Set default timeout
axios.defaults.timeout = REQUEST_TIMEOUT;

// Add request interceptor for authentication
axios.interceptors.request.use(
  config => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  error => Promise.reject(error)
);

// Add response interceptor for error handling
axios.interceptors.response.use(
  response => response,
  error => {
    // Handle network errors gracefully
    if (error.code === 'ERR_NETWORK') {
      console.error('Network error - server may be down or unreachable');
      // You can add custom handling here
    }
    return Promise.reject(error);
  }
);

// API endpoints
export const ENDPOINTS = {
  // Auth endpoints
  AUTH: {
    LOGIN: '/auth/login',
    REGISTER: '/auth/signup',
    VERIFY_EMAIL: '/auth/verify',
    FORGOT_PASSWORD: '/auth/forgot-password',
    RESET_PASSWORD: '/auth/reset-password',
    ME: '/auth/me'
  },
  
  // Admin endpoints
  ADMIN: {
    TIME_ENTRIES: '/admin/time-entries',
    TIME_ENTRY_STATS: '/admin/time-entries/stats',
    ACTIVE_PROJECTS: '/admin/time-entries/projects/active',
    FREELANCERS: '/admin/time-entries/users/freelancers',
    MILESTONES: '/admin/milestones',
    MILESTONE_STATS: '/admin/milestones/stats',
    PROJECTS: '/admin/milestones/projects'
  },
  
  // User endpoints
  USER: {
    PROFILE: '/user/profile',
    SETTINGS: '/user/settings'
  },
  
  // Project endpoints
  PROJECTS: {
    LIST: '/projects',
    DETAILS: '/projects'
  },
  
  // Messaging endpoints
  MESSAGES: {
    CONVERSATIONS: '/messages/conversations',
    MESSAGES: '/messages'
  }
};

// Maximum retries for failed requests
export const MAX_RETRIES = 3;
