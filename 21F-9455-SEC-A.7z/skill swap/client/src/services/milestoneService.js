import api from '../utils/api';
import { ENDPOINTS } from './apiConfig';

/**
 * Milestone Service
 * 
 * This service handles all API calls related to milestone tracking functionality
 */

/**
 * Get milestones with filtering and pagination
 * @param {Object} filters - Filter parameters
 * @param {number} page - Page number
 * @param {number} limit - Items per page
 * @returns {Promise} - Promise with milestones data
 */
export const getMilestones = async (filters = {}, page = 1, limit = 10) => {
  const params = {
    page,
    limit,
    ...filters
  };
  
  const response = await api.get('/admin/milestones', { params });
  return response.data;
};

/**
 * Get milestone by ID
 * @param {string} id - Milestone ID
 * @returns {Promise} - Promise with milestone data
 */
export const getMilestoneById = async (id) => {
  const response = await api.get(`/admin/milestones/${id}`);
  return response.data;
};

/**
 * Update milestone status
 * @param {string} id - Milestone ID
 * @param {string} status - New status
 * @param {string} note - Optional note
 * @returns {Promise} - Promise with updated milestone
 */
export const updateMilestoneStatus = async (id, status, note = '') => {
  const response = await api.patch(`/admin/milestones/${id}/status`, { 
    status, 
    note 
  });
  return response.data;
};

/**
 * Get milestone statistics
 * @returns {Promise} - Promise with milestone statistics
 */
export const getMilestoneStats = async () => {
  const response = await api.get('/admin/milestones/stats');
  return response.data;
};

/**
 * Get projects for filtering
 * @returns {Promise} - Promise with projects
 */
export const getProjects = async () => {
  const response = await api.get('/admin/milestones/projects');
  return response.data;
};
