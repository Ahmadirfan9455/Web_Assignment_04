import api from '../utils/api';
import { ENDPOINTS } from './apiConfig';

/**
 * Time Entry Service
 * 
 * This service handles all API calls related to time tracking functionality
 */

/**
 * Get time entries with filtering and pagination
 * @param {Object} filters - Filter parameters
 * @param {number} page - Page number
 * @param {number} limit - Items per page
 * @returns {Promise} - Promise with time entries data
 */
export const getTimeEntries = async (filters = {}, page = 1, limit = 10) => {
  const params = {
    page,
    limit,
    ...filters
  };
  
  const response = await api.get('/admin/time-entries', { params });
  return response.data;
};

/**
 * Get time entry by ID
 * @param {string} id - Time entry ID
 * @returns {Promise} - Promise with time entry data
 */
export const getTimeEntryById = async (id) => {
  const response = await api.get(`/admin/time-entries/${id}`);
  return response.data;
};

/**
 * Approve time entry
 * @param {string} id - Time entry ID
 * @param {string} note - Optional note
 * @returns {Promise} - Promise with updated time entry
 */
export const approveTimeEntry = async (id, note = '') => {
  const response = await api.patch(`/admin/time-entries/${id}/approve`, { note });
  return response.data;
};

/**
 * Reject time entry
 * @param {string} id - Time entry ID
 * @param {string} rejectionReason - Reason for rejection
 * @param {string} note - Optional additional note
 * @returns {Promise} - Promise with updated time entry
 */
export const rejectTimeEntry = async (id, rejectionReason, note = '') => {
  const response = await api.patch(`/admin/time-entries/${id}/reject`, { 
    rejectionReason, 
    note 
  });
  return response.data;
};

/**
 * Get time entry statistics
 * @returns {Promise} - Promise with time entry statistics
 */
export const getTimeEntryStats = async () => {
  const response = await api.get('/admin/time-entries/stats');
  return response.data;
};

/**
 * Get active projects for filtering
 * @returns {Promise} - Promise with active projects
 */
export const getActiveProjects = async () => {
  const response = await api.get('/admin/time-entries/projects/active');
  return response.data;
};

/**
 * Get freelancers for filtering
 * @returns {Promise} - Promise with freelancers
 */
export const getFreelancers = async () => {
  const response = await api.get('/admin/time-entries/users/freelancers');
  return response.data;
};
