import axios from 'axios';
import { API_BASE_URL, ENDPOINTS } from './apiConfig';

/**
 * Authentication Service
 * Handles all authentication related API calls
 */

// Create an axios instance with the base URL and timeout
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000, // 10 seconds timeout
});

// Add request interceptor for authentication
api.interceptors.request.use(
  config => {
    // Add timestamp to prevent caching
    config.params = {
      ...config.params,
      _t: Date.now()
    };
    return config;
  },
  error => Promise.reject(error)
);

// Add response interceptor for error handling
api.interceptors.response.use(
  response => response,
  error => {
    if (error.code === 'ERR_NETWORK') {
      console.error('Network error - server may be down or unreachable');
      error.userMessage = 'Cannot connect to server. Please check your internet connection or try again later.';
    } else if (error.code === 'ECONNABORTED') {
      console.error('Request timeout');
      error.userMessage = 'Request timed out. Please try again.';
    }
    return Promise.reject(error);
  }
);

/**
 * Register a new user
 * @param {Object} userData - User registration data
 * @returns {Promise} - Promise with registration response
 */
export const register = async (userData) => {
  try {
    console.log('Registering user with URL:', `${API_BASE_URL}${ENDPOINTS.AUTH.REGISTER}`);
    const response = await api.post(ENDPOINTS.AUTH.REGISTER, userData);
    return response.data;
  } catch (error) {
    console.error('Registration error in service:', error);
    throw error;
  }
};

/**
 * Login a user
 * @param {Object} credentials - User login credentials
 * @returns {Promise} - Promise with login response
 */
export const login = async (credentials) => {
  try {
    // Try direct API URL first
    try {
      const response = await api.post(ENDPOINTS.AUTH.LOGIN, credentials);
      return response.data;
    } catch (error) {
      if (error.code === 'ERR_NETWORK') {
        // If network error, try alternative URL
        console.log('Trying alternative login URL...');
        const fallbackResponse = await axios.post(`http://localhost:5000/api${ENDPOINTS.AUTH.LOGIN}`, credentials);
        return fallbackResponse.data;
      }
      throw error;
    }
  } catch (error) {
    console.error('Login error in service:', error);
    throw error;
  }
};

/**
 * Get current user profile
 * @param {String} token - JWT token
 * @returns {Promise} - Promise with user data
 */
export const getCurrentUser = async (token) => {
  try {
    const response = await api.get(ENDPOINTS.AUTH.ME, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    return response.data;
  } catch (error) {
    console.error('Get current user error:', error);
    throw error;
  }
};

/**
 * Verify email with token
 * @param {String} token - Email verification token
 * @returns {Promise} - Promise with verification response
 */
export const verifyEmail = async (token) => {
  try {
    const response = await api.get(`${ENDPOINTS.AUTH.VERIFY_EMAIL}/${token}`);
    return response.data;
  } catch (error) {
    console.error('Email verification error:', error);
    throw error;
  }
};

/**
 * Request password reset
 * @param {String} email - User email
 * @returns {Promise} - Promise with reset request response
 */
export const requestPasswordReset = async (email) => {
  try {
    const response = await api.post(ENDPOINTS.AUTH.RESET_PASSWORD_REQUEST, { email });
    return response.data;
  } catch (error) {
    console.error('Password reset request error:', error);
    throw error;
  }
};

/**
 * Reset password with token
 * @param {String} token - Password reset token
 * @param {String} password - New password
 * @returns {Promise} - Promise with reset response
 */
export const resetPassword = async (token, password) => {
  try {
    const response = await api.post(`${ENDPOINTS.AUTH.RESET_PASSWORD}/${token}`, { password });
    return response.data;
  } catch (error) {
    console.error('Password reset error:', error);
    throw error;
  }
};

export default {
  register,
  login,
  getCurrentUser,
  verifyEmail,
  requestPasswordReset,
  resetPassword
};
