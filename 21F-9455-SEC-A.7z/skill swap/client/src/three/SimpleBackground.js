import React from 'react';

/**
 * A simple background component that doesn't use Three.js
 * This is a temporary solution to avoid the BatchedMesh error
 */
const SimpleBackground = () => {
  return (
    <div 
      className="fixed inset-0 -z-10" 
      style={{
        background: 'linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #312e81 100%)',
        overflow: 'hidden'
      }}
    >
      {/* Animated gradient overlay */}
      <div 
        className="absolute inset-0 opacity-30"
        style={{
          background: 'radial-gradient(circle at 50% 50%, rgba(99, 102, 241, 0.8) 0%, rgba(99, 102, 241, 0) 70%)',
          animation: 'pulse 8s ease-in-out infinite alternate'
        }}
      />
      
      {/* Particle effect using CSS */}
      <div className="stars">
        {Array.from({ length: 100 }).map((_, i) => {
          const size = Math.random() * 2 + 1;
          const top = Math.random() * 100;
          const left = Math.random() * 100;
          const animationDuration = Math.random() * 50 + 20;
          
          return (
            <div
              key={i}
              className="absolute rounded-full bg-white opacity-70"
              style={{
                width: `${size}px`,
                height: `${size}px`,
                top: `${top}%`,
                left: `${left}%`,
                boxShadow: '0 0 4px 1px rgba(255, 255, 255, 0.4)',
                animation: `twinkle ${animationDuration}s ease-in-out infinite alternate`
              }}
            />
          );
        })}
      </div>
      
      {/* CSS for animations */}
      <style jsx="true">{`
        @keyframes pulse {
          0% {
            transform: scale(1);
            opacity: 0.3;
          }
          50% {
            transform: scale(1.2);
            opacity: 0.5;
          }
          100% {
            transform: scale(1);
            opacity: 0.3;
          }
        }
        
        @keyframes twinkle {
          0% {
            opacity: 0.2;
            transform: scale(0.8);
          }
          50% {
            opacity: 0.8;
            transform: scale(1.2);
          }
          100% {
            opacity: 0.2;
            transform: scale(0.8);
          }
        }
      `}</style>
    </div>
  );
};

export default SimpleBackground;
