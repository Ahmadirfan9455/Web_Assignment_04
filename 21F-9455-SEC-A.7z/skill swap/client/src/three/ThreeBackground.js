import React, { useRef, useEffect, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { 
  Environment, 
  Float, 
  Sparkles, 
  PerspectiveCamera
} from '@react-three/drei';
import { 
  EffectComposer, 
  Bloom, 
  Vignette
} from '@react-three/postprocessing';
import { BlendFunction } from 'postprocessing';
import * as THREE from 'three';
import { gsap } from 'gsap';

// Using a simplified version to avoid dependency issues with BatchedMesh

// Animated floating particles
const FloatingParticles = ({ count = 100, color = '#6366f1' }) => {
  const mesh = useRef();
  const { viewport } = useThree();
  
  useEffect(() => {
    if (mesh.current) {
      const positions = mesh.current.geometry.attributes.position;
      const scales = mesh.current.geometry.attributes.scale;
      
      for (let i = 0; i < count; i++) {
        const x = (Math.random() - 0.5) * viewport.width * 2;
        const y = (Math.random() - 0.5) * viewport.height * 2;
        const z = (Math.random() - 0.5) * 10;
        
        positions.setXYZ(i, x, y, z);
        scales.setX(i, Math.random() * 0.5 + 0.1);
      }
      
      positions.needsUpdate = true;
      scales.needsUpdate = true;
    }
  }, [count, viewport]);
  
  useFrame(({ clock }) => {
    if (mesh.current) {
      mesh.current.rotation.x = Math.sin(clock.getElapsedTime() * 0.1) * 0.1;
      mesh.current.rotation.y = Math.sin(clock.getElapsedTime() * 0.05) * 0.1;
    }
  });
  
  return (
    <points ref={mesh}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={new Float32Array(count * 3)}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-scale"
          count={count}
          array={new Float32Array(count)}
          itemSize={1}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.1}
        color={color}
        sizeAttenuation
        transparent
        opacity={0.8}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
};

// Animated gradient background
const GradientBackground = () => {
  const mesh = useRef();
  const uniforms = useRef({
    time: { value: 0 },
    colorA: { value: new THREE.Color('#4f46e5') },
    colorB: { value: new THREE.Color('#c026d3') },
    colorC: { value: new THREE.Color('#0d9488') }
  });
  
  useFrame(({ clock }) => {
    if (mesh.current) {
      mesh.current.material.uniforms.time.value = clock.getElapsedTime() * 0.2;
    }
  });
  
  const fragmentShader = `
    uniform float time;
    uniform vec3 colorA;
    uniform vec3 colorB;
    uniform vec3 colorC;
    varying vec2 vUv;
    
    void main() {
      float noise = sin(vUv.x * 10.0 + time) * sin(vUv.y * 10.0 + time) * 0.1;
      vec3 color = mix(
        mix(colorA, colorB, sin(time * 0.3 + vUv.x) * 0.5 + 0.5),
        colorC,
        sin(time * 0.5 + vUv.y) * 0.5 + 0.5 + noise
      );
      gl_FragColor = vec4(color, 1.0);
    }
  `;
  
  const vertexShader = `
    varying vec2 vUv;
    
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `;
  
  return (
    <mesh ref={mesh} position={[0, 0, -10]}>
      <planeGeometry args={[50, 50]} />
      <shaderMaterial
        uniforms={uniforms.current}
        fragmentShader={fragmentShader}
        vertexShader={vertexShader}
      />
    </mesh>
  );
};

// Animated floating logo
const FloatingLogo = () => {
  const mesh = useRef();
  const [texture, setTexture] = useState(null);
  
  useEffect(() => {
    // Load texture manually instead of using useTexture
    const textureLoader = new THREE.TextureLoader();
    textureLoader.load('/logo.png', (loadedTexture) => {
      setTexture(loadedTexture);
    });
  }, []);
  
  useFrame(({ clock }) => {
    if (mesh.current) {
      mesh.current.position.y = Math.sin(clock.getElapsedTime() * 0.5) * 0.2;
      mesh.current.rotation.z = Math.sin(clock.getElapsedTime() * 0.3) * 0.05;
    }
  });
  
  return (
    <Float speed={2} rotationIntensity={0.2} floatIntensity={0.5}>
      <mesh ref={mesh} position={[0, 0, -5]}>
        <planeGeometry args={[3, 3]} />
        <meshBasicMaterial
          map={texture}
          transparent
          opacity={0.7}
          blending={THREE.AdditiveBlending}
        />
      </mesh>
    </Float>
  );
};

// Main Three.js scene
const Scene = () => {
  const { camera } = useThree();
  
  useEffect(() => {
    // Animate camera on mount
    gsap.to(camera.position, {
      z: 5,
      duration: 2,
      ease: 'power2.out'
    });
  }, [camera]);
  
  useFrame(({ mouse, viewport }) => {
    // Subtle camera movement based on mouse position
    const x = (mouse.x * viewport.width) / 100;
    const y = (mouse.y * viewport.height) / 100;
    
    gsap.to(camera.position, {
      x: x,
      y: y,
      duration: 1,
      ease: 'power2.out'
    });
    
    camera.lookAt(0, 0, 0);
  });
  
  return (
    <>
      <PerspectiveCamera makeDefault position={[0, 0, 10]} fov={75} />
      <GradientBackground />
      <FloatingParticles count={200} color="#6366f1" />
      <FloatingParticles count={100} color="#d946ef" />
      <FloatingParticles count={50} color="#14b8a6" />
      <Sparkles count={100} scale={10} size={2} speed={0.3} opacity={0.2} />
      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 10, 5]} intensity={0.5} />
      <Environment preset="night" />
      
      <EffectComposer>
        <Bloom
          intensity={1.5}
          luminanceThreshold={0.2}
          luminanceSmoothing={0.9}
          height={300}
        />
        <Vignette
          offset={0.5}
          darkness={0.5}
          opacity={0.5}
          blendFunction={BlendFunction.NORMAL}
        />
      </EffectComposer>
    </>
  );
};

// Main component to export
const ThreeBackground = () => {
  return (
    <div className="three-canvas-container">
      <Canvas>
        <Scene />
      </Canvas>
    </div>
  );
};

export default ThreeBackground;
