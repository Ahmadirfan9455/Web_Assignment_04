import React, { useState, useEffect } from 'react';
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import GlassCard from '../ui/GlassCard';
import axios from 'axios';

const DashboardAnalytics = ({ userId, role }) => {
  const [analyticsData, setAnalyticsData] = useState({
    projectStats: [],
    earningsData: [],
    categoryDistribution: [],
    isLoading: true,
    error: null
  });

  // Colors for charts
  const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#0088FE', '#00C49F', '#FFBB28'];

  useEffect(() => {
    const fetchAnalyticsData = async () => {
      try {
        // Different endpoints based on user role
        const endpoint = role === 'admin' 
          ? '/api/analytics/platform' 
          : `/api/analytics/user/${userId}`;
        
        const response = await axios.get(endpoint);
        
        setAnalyticsData({
          projectStats: response.data.projectStats || [],
          earningsData: response.data.earningsData || [],
          categoryDistribution: response.data.categoryDistribution || [],
          isLoading: false,
          error: null
        });
      } catch (error) {
        console.error('Error fetching analytics data:', error);
        setAnalyticsData(prev => ({
          ...prev,
          isLoading: false,
          error: 'Failed to load analytics data'
        }));
        
        // Use mock data for demonstration if API fails
        setMockData();
      }
    };
    
    fetchAnalyticsData();
  }, [userId, role]);
  
  // Set mock data for demonstration
  const setMockData = () => {
    const mockProjectStats = [
      { month: 'Jan', completed: 4, active: 2, new: 5 },
      { month: 'Feb', completed: 3, active: 3, new: 4 },
      { month: 'Mar', completed: 5, active: 4, new: 3 },
      { month: 'Apr', completed: 6, active: 3, new: 6 },
      { month: 'May', completed: 4, active: 5, new: 7 },
      { month: 'Jun', completed: 8, active: 4, new: 5 }
    ];
    
    const mockEarningsData = [
      { month: 'Jan', earnings: 1200 },
      { month: 'Feb', earnings: 1800 },
      { month: 'Mar', earnings: 2400 },
      { month: 'Apr', earnings: 1600 },
      { month: 'May', earnings: 3200 },
      { month: 'Jun', earnings: 2800 }
    ];
    
    const mockCategoryDistribution = [
      { name: 'Web Development', value: 35 },
      { name: 'Mobile Apps', value: 25 },
      { name: 'UI/UX Design', value: 15 },
      { name: 'Data Science', value: 10 },
      { name: 'DevOps', value: 8 },
      { name: 'Other', value: 7 }
    ];
    
    setAnalyticsData({
      projectStats: mockProjectStats,
      earningsData: mockEarningsData,
      categoryDistribution: mockCategoryDistribution,
      isLoading: false,
      error: null
    });
  };

  if (analyticsData.isLoading) {
    return (
      <div className="grid gap-6 mb-8">
        {[1, 2, 3].map(i => (
          <GlassCard key={i} className="p-6 animate-pulse">
            <div className="h-40 bg-gray-700/50 rounded"></div>
          </GlassCard>
        ))}
      </div>
    );
  }

  if (analyticsData.error) {
    return (
      <GlassCard className="p-6">
        <div className="text-center text-red-400">
          <p>{analyticsData.error}</p>
          <button 
            onClick={setMockData}
            className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-md text-white"
          >
            Load Demo Data
          </button>
        </div>
      </GlassCard>
    );
  }

  return (
    <div className="grid gap-6 mb-8">
      {/* Project Statistics */}
      <GlassCard className="p-6">
        <h3 className="text-xl font-semibold text-white mb-4">Project Activity</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={analyticsData.projectStats}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#444" />
              <XAxis dataKey="month" stroke="#aaa" />
              <YAxis stroke="#aaa" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'rgba(23, 25, 35, 0.9)', 
                  borderColor: '#555',
                  color: 'white' 
                }} 
              />
              <Legend />
              <Bar dataKey="new" name="New Projects" fill="#8884d8" />
              <Bar dataKey="active" name="Active Projects" fill="#82ca9d" />
              <Bar dataKey="completed" name="Completed Projects" fill="#ffc658" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </GlassCard>

      {/* Earnings Chart */}
      <GlassCard className="p-6">
        <h3 className="text-xl font-semibold text-white mb-4">Earnings Overview</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={analyticsData.earningsData}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#444" />
              <XAxis dataKey="month" stroke="#aaa" />
              <YAxis stroke="#aaa" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'rgba(23, 25, 35, 0.9)', 
                  borderColor: '#555',
                  color: 'white' 
                }}
                formatter={(value) => [`$${value}`, 'Earnings']}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="earnings" 
                name="Earnings ($)" 
                stroke="#8884d8" 
                activeDot={{ r: 8 }}
                strokeWidth={2}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </GlassCard>

      {/* Category Distribution */}
      <GlassCard className="p-6">
        <h3 className="text-xl font-semibold text-white mb-4">Project Categories</h3>
        <div className="h-80 flex items-center justify-center">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={analyticsData.categoryDistribution}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={120}
                fill="#8884d8"
                dataKey="value"
                nameKey="name"
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              >
                {analyticsData.categoryDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'rgba(23, 25, 35, 0.9)', 
                  borderColor: '#555',
                  color: 'white' 
                }}
                formatter={(value) => [`${value}%`, 'Percentage']}
              />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </GlassCard>
    </div>
  );
};

export default DashboardAnalytics;
