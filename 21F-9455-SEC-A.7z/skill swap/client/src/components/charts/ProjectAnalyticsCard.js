import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import GlassCard from '../ui/GlassCard';

/**
 * A reusable analytics card component for displaying project statistics
 * @param {string} title - Card title
 * @param {array} data - Data for the chart
 * @param {array} bars - Configuration for bars to display
 * @param {string} xAxisKey - Key for X-axis data
 */
const ProjectAnalyticsCard = ({ 
  title, 
  data = [], 
  bars = [
    { dataKey: 'value', name: 'Value', color: '#8884d8' }
  ],
  xAxisKey = 'name',
  height = 300
}) => {
  return (
    <GlassCard className="p-6">
      <h3 className="text-xl font-semibold text-white mb-4">{title}</h3>
      <div style={{ height: `${height}px` }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={data}
            margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#444" />
            <XAxis dataKey={xAxisKey} stroke="#aaa" />
            <YAxis stroke="#aaa" />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'rgba(23, 25, 35, 0.9)', 
                borderColor: '#555',
                color: 'white' 
              }} 
            />
            <Legend />
            {bars.map((bar, index) => (
              <Bar 
                key={index}
                dataKey={bar.dataKey} 
                name={bar.name} 
                fill={bar.color} 
                radius={[4, 4, 0, 0]}
              />
            ))}
          </BarChart>
        </ResponsiveContainer>
      </div>
    </GlassCard>
  );
};

export default ProjectAnalyticsCard;
