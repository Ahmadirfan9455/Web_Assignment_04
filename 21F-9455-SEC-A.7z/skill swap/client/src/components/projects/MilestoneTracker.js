import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../ui/GlassCard';
import GlowButton from '../ui/GlowButton';

const MilestoneTracker = ({ projectId, milestones, onMilestoneUpdate }) => {
  const { user } = useAuth();
  const [expandedMilestone, setExpandedMilestone] = useState(null);
  const [submittingMilestone, setSubmittingMilestone] = useState(null);
  const [reviewingMilestone, setReviewingMilestone] = useState(null);
  const [feedback, setFeedback] = useState('');
  const [submissionNote, setSubmissionNote] = useState('');
  const [submissionFiles, setSubmissionFiles] = useState([]);
  
  // Check if user is client or freelancer
  const isClient = user && user.role === 'client';
  const isFreelancer = user && user.role === 'freelancer';
  
  // Toggle milestone expansion
  const toggleMilestone = (milestoneId) => {
    if (expandedMilestone === milestoneId) {
      setExpandedMilestone(null);
    } else {
      setExpandedMilestone(milestoneId);
    }
  };
  
  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'Not set';
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  // Handle file selection
  const handleFileChange = (e) => {
    setSubmissionFiles(Array.from(e.target.files));
  };
  
  // Submit milestone
  const handleSubmitMilestone = async (milestoneId) => {
    if (!submissionNote.trim() && submissionFiles.length === 0) {
      toast.error('Please provide a submission note or attach files');
      return;
    }
    
    try {
      setSubmittingMilestone(milestoneId);
      
      // Create form data for file upload
      const formData = new FormData();
      formData.append('milestoneId', milestoneId);
      formData.append('note', submissionNote);
      
      // Append files if any
      submissionFiles.forEach(file => {
        formData.append('files', file);
      });
      
      // Submit milestone
      await axios.post(`/api/projects/${projectId}/milestones/${milestoneId}/submit`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
      
      toast.success('Milestone submitted successfully!');
      
      // Reset form
      setSubmissionNote('');
      setSubmissionFiles([]);
      setSubmittingMilestone(null);
      
      // Notify parent component
      if (onMilestoneUpdate) {
        onMilestoneUpdate();
      }
    } catch (error) {
      console.error('Error submitting milestone:', error);
      toast.error(error.response?.data?.message || 'Failed to submit milestone. Please try again.');
    } finally {
      setSubmittingMilestone(null);
    }
  };
  
  // Approve milestone
  const handleApproveMilestone = async (milestoneId) => {
    try {
      setReviewingMilestone(milestoneId);
      
      // Approve milestone
      await axios.post(`/api/projects/${projectId}/milestones/${milestoneId}/approve`, {
        feedback
      });
      
      toast.success('Milestone approved successfully!');
      
      // Reset form
      setFeedback('');
      setReviewingMilestone(null);
      
      // Notify parent component
      if (onMilestoneUpdate) {
        onMilestoneUpdate();
      }
    } catch (error) {
      console.error('Error approving milestone:', error);
      toast.error(error.response?.data?.message || 'Failed to approve milestone. Please try again.');
    } finally {
      setReviewingMilestone(null);
    }
  };
  
  // Request revisions
  const handleRequestRevisions = async (milestoneId) => {
    if (!feedback.trim()) {
      toast.error('Please provide feedback for the revisions');
      return;
    }
    
    try {
      setReviewingMilestone(milestoneId);
      
      // Request revisions
      await axios.post(`/api/projects/${projectId}/milestones/${milestoneId}/revisions`, {
        feedback
      });
      
      toast.success('Revision request sent successfully!');
      
      // Reset form
      setFeedback('');
      setReviewingMilestone(null);
      
      // Notify parent component
      if (onMilestoneUpdate) {
        onMilestoneUpdate();
      }
    } catch (error) {
      console.error('Error requesting revisions:', error);
      toast.error(error.response?.data?.message || 'Failed to request revisions. Please try again.');
    } finally {
      setReviewingMilestone(null);
    }
  };
  
  // Get milestone status color
  const getMilestoneStatusColor = (status) => {
    switch (status) {
      case 'pending':
        return 'text-gray-400';
      case 'in_progress':
        return 'text-blue-400';
      case 'submitted':
        return 'text-yellow-400';
      case 'revision_requested':
        return 'text-orange-400';
      case 'approved':
        return 'text-green-400';
      case 'rejected':
        return 'text-red-400';
      default:
        return 'text-gray-400';
    }
  };
  
  // Get milestone status icon
  const getMilestoneStatusIcon = (status) => {
    switch (status) {
      case 'pending':
        return (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
          </svg>
        );
      case 'in_progress':
        return (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
          </svg>
        );
      case 'submitted':
        return (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
          </svg>
        );
      case 'revision_requested':
        return (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
          </svg>
        );
      case 'approved':
        return (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
          </svg>
        );
      case 'rejected':
        return (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
          </svg>
        );
      default:
        return (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
          </svg>
        );
    }
  };
  
  // Format milestone status
  const formatMilestoneStatus = (status) => {
    switch (status) {
      case 'pending':
        return 'Pending';
      case 'in_progress':
        return 'In Progress';
      case 'submitted':
        return 'Submitted';
      case 'revision_requested':
        return 'Revision Requested';
      case 'approved':
        return 'Approved';
      case 'rejected':
        return 'Rejected';
      default:
        return 'Unknown';
    }
  };
  
  // Calculate progress percentage
  const calculateProgress = () => {
    if (!milestones || milestones.length === 0) return 0;
    
    const completedMilestones = milestones.filter(
      milestone => milestone.status === 'approved'
    ).length;
    
    return Math.round((completedMilestones / milestones.length) * 100);
  };
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.3
      }
    }
  };
  
  return (
    <GlassCard className="p-6">
      <h2 className="text-xl font-semibold text-white mb-4">Project Milestones</h2>
      
      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-indigo-300 text-sm">Overall Progress</span>
          <span className="text-indigo-300 text-sm">{calculateProgress()}%</span>
        </div>
        <div className="w-full bg-gray-700 rounded-full h-2.5">
          <div 
            className="bg-indigo-600 h-2.5 rounded-full" 
            style={{ width: `${calculateProgress()}%` }}
          ></div>
        </div>
      </div>
      
      {/* Milestones List */}
      {milestones && milestones.length > 0 ? (
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-4"
        >
          {milestones.map((milestone) => (
            <motion.div key={milestone._id} variants={itemVariants}>
              <div 
                className={`border ${
                  expandedMilestone === milestone._id 
                    ? 'border-indigo-600' 
                    : 'border-gray-700'
                } rounded-lg overflow-hidden`}
              >
                {/* Milestone Header */}
                <div 
                  className={`flex justify-between items-center p-4 cursor-pointer ${
                    expandedMilestone === milestone._id 
                      ? 'bg-indigo-900/30' 
                      : 'hover:bg-gray-800/50'
                  }`}
                  onClick={() => toggleMilestone(milestone._id)}
                >
                  <div className="flex items-center">
                    <div className={`mr-3 ${getMilestoneStatusColor(milestone.status)}`}>
                      {getMilestoneStatusIcon(milestone.status)}
                    </div>
                    <div>
                      <h3 className="text-white font-medium">{milestone.title}</h3>
                      <p className="text-indigo-300 text-sm">
                        Due: {formatDate(milestone.dueDate)}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <span className={`mr-3 text-sm ${getMilestoneStatusColor(milestone.status)}`}>
                      {formatMilestoneStatus(milestone.status)}
                    </span>
                    <svg 
                      className={`w-5 h-5 text-indigo-300 transform transition-transform ${
                        expandedMilestone === milestone._id ? 'rotate-180' : ''
                      }`} 
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24" 
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                    </svg>
                  </div>
                </div>
                
                {/* Milestone Details */}
                {expandedMilestone === milestone._id && (
                  <div className="p-4 border-t border-gray-700">
                    {/* Description */}
                    <div className="mb-4">
                      <h4 className="text-indigo-300 text-sm mb-1">Description</h4>
                      <p className="text-white">{milestone.description}</p>
                    </div>
                    
                    {/* Amount */}
                    <div className="mb-4">
                      <h4 className="text-indigo-300 text-sm mb-1">Payment Amount</h4>
                      <p className="text-white">${milestone.amount.toFixed(2)}</p>
                    </div>
                    
                    {/* Submission Details */}
                    {milestone.submission && (
                      <div className="mb-4 p-3 bg-gray-800/50 rounded-md">
                        <h4 className="text-indigo-300 text-sm mb-2">Submission Details</h4>
                        <p className="text-white mb-2">{milestone.submission.note}</p>
                        
                        {/* Submission Files */}
                        {milestone.submission.files && milestone.submission.files.length > 0 && (
                          <div>
                            <h5 className="text-indigo-300 text-xs mb-1">Attached Files</h5>
                            <div className="space-y-1">
                              {milestone.submission.files.map((file, index) => (
                                <div key={index} className="flex items-center">
                                  <svg className="w-4 h-4 text-indigo-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                                  </svg>
                                  <a 
                                    href={file.url} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="text-indigo-400 hover:text-indigo-300 text-sm"
                                  >
                                    {file.originalName}
                                  </a>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        {/* Submission Date */}
                        <p className="text-indigo-300 text-xs mt-2">
                          Submitted on {formatDate(milestone.submission.submittedAt)}
                        </p>
                      </div>
                    )}
                    
                    {/* Feedback */}
                    {milestone.feedback && (
                      <div className="mb-4 p-3 bg-gray-800/50 rounded-md">
                        <h4 className="text-indigo-300 text-sm mb-1">Client Feedback</h4>
                        <p className="text-white">{milestone.feedback}</p>
                      </div>
                    )}
                    
                    {/* Freelancer Actions */}
                    {isFreelancer && milestone.status !== 'approved' && milestone.status !== 'rejected' && (
                      <div className="mt-4">
                        {milestone.status === 'pending' || milestone.status === 'in_progress' || milestone.status === 'revision_requested' ? (
                          <div>
                            <h4 className="text-indigo-300 text-sm mb-2">Submit Milestone</h4>
                            
                            <div className="mb-3">
                              <textarea
                                value={submissionNote}
                                onChange={(e) => setSubmissionNote(e.target.value)}
                                className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                                rows="3"
                                placeholder="Describe what you've completed..."
                              ></textarea>
                            </div>
                            
                            <div className="mb-3">
                              <label className="block text-indigo-300 text-sm mb-1">
                                Attach Files (Optional)
                              </label>
                              <input
                                type="file"
                                onChange={handleFileChange}
                                multiple
                                className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                              />
                              {submissionFiles.length > 0 && (
                                <p className="text-indigo-300 text-xs mt-1">
                                  {submissionFiles.length} {submissionFiles.length === 1 ? 'file' : 'files'} selected
                                </p>
                              )}
                            </div>
                            
                            <GlowButton
                              variant="primary"
                              className="w-full"
                              onClick={() => handleSubmitMilestone(milestone._id)}
                              disabled={submittingMilestone === milestone._id}
                            >
                              {submittingMilestone === milestone._id ? 'Submitting...' : 'Submit for Review'}
                            </GlowButton>
                          </div>
                        ) : (
                          <p className="text-indigo-300 text-center">
                            Waiting for client review
                          </p>
                        )}
                      </div>
                    )}
                    
                    {/* Client Actions */}
                    {isClient && milestone.status === 'submitted' && (
                      <div className="mt-4">
                        <h4 className="text-indigo-300 text-sm mb-2">Review Submission</h4>
                        
                        <div className="mb-3">
                          <textarea
                            value={feedback}
                            onChange={(e) => setFeedback(e.target.value)}
                            className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                            rows="3"
                            placeholder="Provide feedback on this submission..."
                          ></textarea>
                        </div>
                        
                        <div className="flex space-x-2">
                          <GlowButton
                            variant="secondary"
                            className="flex-1"
                            onClick={() => handleRequestRevisions(milestone._id)}
                            disabled={reviewingMilestone === milestone._id}
                          >
                            Request Revisions
                          </GlowButton>
                          <GlowButton
                            variant="primary"
                            className="flex-1"
                            onClick={() => handleApproveMilestone(milestone._id)}
                            disabled={reviewingMilestone === milestone._id}
                          >
                            Approve & Pay
                          </GlowButton>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </motion.div>
      ) : (
        <p className="text-indigo-300 text-center">No milestones found for this project.</p>
      )}
    </GlassCard>
  );
};

export default MilestoneTracker;
