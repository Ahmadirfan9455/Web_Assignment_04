import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';

const GlowButton = ({
  children,
  className = '',
  variant = 'primary',
  size = 'md',
  disabled = false,
  onClick,
  ...props
}) => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const buttonRef = useRef(null);
  
  // Define variants
  const variants = {
    primary: 'from-primary-500 via-primary-600 to-primary-700',
    secondary: 'from-secondary-500 via-secondary-600 to-secondary-700',
    accent: 'from-accent-500 via-accent-600 to-accent-700',
    gradient: 'from-primary-500 via-secondary-500 to-accent-500',
  };
  
  // Define sizes
  const sizes = {
    sm: 'px-3 py-1.5 text-sm',
    md: 'px-5 py-2.5 text-base',
    lg: 'px-7 py-3 text-lg',
  };
  
  // Update mouse position relative to button
  const handleMouseMove = (e) => {
    if (buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      setMousePosition({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      });
    }
  };
  
  // Framer motion variants
  const buttonVariants = {
    initial: {
      scale: 1,
      boxShadow: '0 0 0 rgba(99, 102, 241, 0)',
    },
    hover: {
      scale: 1.02,
      boxShadow: '0 0 20px rgba(99, 102, 241, 0.5)',
      transition: {
        duration: 0.2,
        ease: 'easeInOut',
      },
    },
    tap: {
      scale: 0.98,
      boxShadow: '0 0 5px rgba(99, 102, 241, 0.3)',
      transition: {
        duration: 0.1,
      },
    },
    disabled: {
      opacity: 0.6,
      scale: 1,
      boxShadow: 'none',
    },
  };
  
  // Clean up effect
  useEffect(() => {
    return () => {
      setMousePosition({ x: 0, y: 0 });
    };
  }, []);
  
  return (
    <motion.button
      ref={buttonRef}
      className={`relative overflow-hidden rounded-lg font-medium transition-all duration-300 ${sizes[size]} ${className}`}
      variants={buttonVariants}
      initial="initial"
      whileHover={disabled ? "disabled" : "hover"}
      whileTap={disabled ? "disabled" : "tap"}
      animate={disabled ? "disabled" : "initial"}
      onClick={disabled ? undefined : onClick}
      onMouseMove={disabled ? undefined : handleMouseMove}
      disabled={disabled}
      {...props}
    >
      {/* Background gradient */}
      <div className={`absolute inset-0 bg-gradient-to-r ${variants[variant]} opacity-90`}></div>
      
      {/* Glow effect on hover */}
      <motion.div
        className="absolute inset-0 bg-white rounded-lg opacity-0"
        animate={{
          opacity: mousePosition.x ? 0.15 : 0,
          background: `radial-gradient(circle at ${mousePosition.x}px ${mousePosition.y}px, rgba(255, 255, 255, 0.8) 0%, rgba(255, 255, 255, 0) 60%)`,
        }}
        transition={{ duration: 0.3 }}
      />
      
      {/* Button content */}
      <div className="relative z-10 text-white font-medium">
        {children}
      </div>
    </motion.button>
  );
};

export default GlowButton;
