import React, { useState, useEffect } from 'react';
import Modal from './Modal';
import GlowButton from './GlowButton';

/**
 * A reusable quick edit modal component for inline editing
 * @param {boolean} isOpen - Whether the modal is open
 * @param {function} onClose - Function to call when the modal is closed
 * @param {function} onSave - Function to call when the form is submitted
 * @param {string} title - Modal title
 * @param {object} initialData - Initial form data
 * @param {array} fields - Array of field configurations
 * @param {boolean} isLoading - Whether the save action is loading
 */
const QuickEditModal = ({
  isOpen,
  onClose,
  onSave,
  title = 'Edit',
  initialData = {},
  fields = [],
  isLoading = false
}) => {
  const [formData, setFormData] = useState(initialData);

  // Reset form data when initialData changes
  useEffect(() => {
    setFormData(initialData);
  }, [initialData]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  // Render form field based on field type
  const renderField = (field) => {
    const { name, label, type = 'text', options = [], placeholder = '', required = false } = field;

    switch (type) {
      case 'textarea':
        return (
          <textarea
            id={name}
            name={name}
            value={formData[name] || ''}
            onChange={handleChange}
            placeholder={placeholder}
            required={required}
            rows={4}
            className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        );
      case 'select':
        return (
          <select
            id={name}
            name={name}
            value={formData[name] || ''}
            onChange={handleChange}
            required={required}
            className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">Select {label}</option>
            {options.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        );
      case 'checkbox':
        return (
          <div className="flex items-center">
            <input
              id={name}
              name={name}
              type="checkbox"
              checked={formData[name] || false}
              onChange={handleChange}
              className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-700 bg-gray-900 rounded"
            />
            <label htmlFor={name} className="ml-2 block text-sm text-gray-200">
              {label}
            </label>
          </div>
        );
      default:
        return (
          <input
            id={name}
            name={name}
            type={type}
            value={formData[name] || ''}
            onChange={handleChange}
            placeholder={placeholder}
            required={required}
            className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        );
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={title}>
      <form onSubmit={handleSubmit}>
        <div className="space-y-4">
          {fields.map((field) => (
            <div key={field.name} className="space-y-1">
              {field.type !== 'checkbox' && (
                <label htmlFor={field.name} className="block text-sm font-medium text-gray-200">
                  {field.label}
                  {field.required && <span className="text-red-500 ml-1">*</span>}
                </label>
              )}
              {renderField(field)}
              {field.description && (
                <p className="text-xs text-gray-400">{field.description}</p>
              )}
            </div>
          ))}
        </div>

        <div className="mt-6 flex justify-end space-x-3">
          <GlowButton type="button" variant="secondary" onClick={onClose} disabled={isLoading}>
            Cancel
          </GlowButton>
          <GlowButton type="submit" variant="primary" disabled={isLoading}>
            {isLoading ? (
              <span className="flex items-center">
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Saving...
              </span>
            ) : (
              'Save Changes'
            )}
          </GlowButton>
        </div>
      </form>
    </Modal>
  );
};

export default QuickEditModal;
