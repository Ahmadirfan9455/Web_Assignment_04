import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import Particles from 'react-particles';
import { loadSlim } from 'tsparticles-slim';

const LoadingScreen = () => {
  const particlesInit = async (engine) => {
    await loadSlim(engine);
  };

  // GSAP-like animation sequence using Framer Motion
  const containerVariants = {
    initial: { opacity: 0 },
    animate: { 
      opacity: 1,
      transition: { 
        duration: 0.5,
        when: 'beforeChildren',
        staggerChildren: 0.2
      }
    },
    exit: { 
      opacity: 0,
      transition: { 
        duration: 0.5,
        when: 'afterChildren',
        staggerChildren: 0.1,
        staggerDirection: -1
      }
    }
  };

  const itemVariants = {
    initial: { y: 20, opacity: 0 },
    animate: { 
      y: 0, 
      opacity: 1,
      transition: { 
        duration: 0.5,
        ease: [0.43, 0.13, 0.23, 0.96]
      }
    },
    exit: { 
      y: -20, 
      opacity: 0,
      transition: { 
        duration: 0.3,
        ease: [0.43, 0.13, 0.23, 0.96]
      }
    }
  };

  const logoVariants = {
    initial: { scale: 0.8, opacity: 0 },
    animate: { 
      scale: 1, 
      opacity: 1,
      transition: { 
        duration: 0.7,
        ease: [0.43, 0.13, 0.23, 0.96]
      }
    },
    pulse: {
      scale: [1, 1.05, 1],
      opacity: [1, 0.8, 1],
      transition: {
        duration: 2,
        ease: "easeInOut",
        repeat: Infinity,
      }
    }
  };

  const particlesOptions = {
    background: {
      color: {
        value: "transparent",
      },
    },
    particles: {
      color: {
        value: ["#6366f1", "#d946ef", "#14b8a6"],
      },
      move: {
        direction: "none",
        enable: true,
        outModes: {
          default: "bounce",
        },
        random: true,
        speed: 1,
        straight: false,
      },
      number: {
        density: {
          enable: true,
          area: 800,
        },
        value: 40,
      },
      opacity: {
        value: 0.5,
      },
      shape: {
        type: "circle",
      },
      size: {
        value: { min: 1, max: 3 },
      },
    },
  };

  return (
    <motion.div 
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-dark-500"
      variants={containerVariants}
      initial="initial"
      animate="animate"
      exit="exit"
    >
      <Particles
        className="absolute inset-0 z-0"
        init={particlesInit}
        options={particlesOptions}
      />
      
      <div className="z-10 flex flex-col items-center justify-center">
        {/* Logo */}
        <motion.div
          className="w-24 h-24 mb-8 glass-card flex items-center justify-center overflow-hidden"
          style={{ borderRadius: '20px' }}
          variants={logoVariants}
          animate={["animate", "pulse"]}
        >
          <span className="text-4xl font-display font-bold glow-text">SS</span>
        </motion.div>
        
        {/* Loading text */}
        <motion.h2 
          className="text-2xl font-display font-semibold text-white mb-4"
          variants={itemVariants}
        >
          <span className="glow-text">SkillSwap</span>
        </motion.h2>
        
        {/* Loading message */}
        <motion.p 
          className="text-gray-300 mb-8"
          variants={itemVariants}
        >
          Loading amazing talents...
        </motion.p>
        
        {/* Loading spinner */}
        <motion.div 
          className="relative w-16 h-16"
          variants={itemVariants}
        >
          <div className="absolute inset-0 rounded-full border-t-2 border-primary-500 animate-spin"></div>
          <div className="absolute inset-1 rounded-full border-r-2 border-secondary-500 animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1s' }}></div>
          <div className="absolute inset-2 rounded-full border-b-2 border-accent-500 animate-spin" style={{ animationDuration: '1.5s' }}></div>
          <div className="absolute inset-0 rounded-full opacity-30 shadow-glow animate-pulse-slow"></div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default LoadingScreen;
