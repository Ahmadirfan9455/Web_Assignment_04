import React from 'react';
import { motion } from 'framer-motion';

const GlassCard = ({ 
  children, 
  className = '', 
  glowColor = 'primary', 
  hoverEffect = true, 
  clickEffect = true,
  ...props 
}) => {
  // Define glow color based on prop
  const glowColorMap = {
    primary: 'shadow-glow-primary',
    secondary: 'shadow-glow-secondary',
    accent: 'shadow-glow-accent',
    none: ''
  };
  
  const glowClass = glowColorMap[glowColor] || glowColorMap.primary;
  
  // Framer motion variants
  const cardVariants = {
    initial: { 
      opacity: 0,
      y: 20
    },
    animate: { 
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
        ease: [0.25, 0.1, 0.25, 1]
      }
    },
    hover: hoverEffect ? { 
      y: -5,
      boxShadow: glowColor !== 'none' ? '0 10px 25px rgba(99, 102, 241, 0.4)' : 'none',
      transition: {
        duration: 0.3,
        ease: [0.25, 0.1, 0.25, 1]
      }
    } : {},
    tap: clickEffect ? { 
      scale: 0.98,
      transition: {
        duration: 0.1
      }
    } : {}
  };

  return (
    <motion.div
      className={`glass-card ${className}`}
      variants={cardVariants}
      initial="initial"
      animate="animate"
      whileHover="hover"
      whileTap="tap"
      {...props}
    >
      {children}
    </motion.div>
  );
};

export default GlassCard;
