import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../ui/GlassCard';
import GlowButton from '../ui/GlowButton';

const ReviewCard = ({ review, onResponseAdded }) => {
  const { user } = useAuth();
  
  // Response form state
  const [showResponseForm, setShowResponseForm] = useState(false);
  const [responseText, setResponseText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Format date
  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  // Submit response
  const handleSubmitResponse = async (e) => {
    e.preventDefault();
    
    if (!responseText.trim()) {
      toast.error('Please enter a response');
      return;
    }
    
    try {
      setIsSubmitting(true);
      
      // Submit response
      await axios.post(`/api/reviews/${review._id}/response`, {
        content: responseText,
      });
      
      toast.success('Response submitted successfully!');
      
      // Reset form
      setResponseText('');
      setShowResponseForm(false);
      
      // Notify parent component
      if (onResponseAdded) {
        onResponseAdded();
      }
    } catch (error) {
      console.error('Error submitting response:', error);
      toast.error(error.response?.data?.message || 'Failed to submit response. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Render stars
  const renderStars = (rating) => {
    return (
      <div className="flex">
        {[1, 2, 3, 4, 5].map((star) => (
          <svg
            key={star}
            className={`w-5 h-5 ${
              rating >= star ? 'text-yellow-400' : 'text-gray-600'
            }`}
            fill="currentColor"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
        ))}
      </div>
    );
  };
  
  // Check if user can respond to this review
  const canRespond = () => {
    // Only freelancers can respond to reviews about them
    return (
      user && 
      user.role === 'freelancer' && 
      review.freelancer._id === user._id && 
      !review.response
    );
  };
  
  return (
    <GlassCard className="p-6">
      <div className="flex items-start">
        <div className="flex-shrink-0 mr-4">
          <div className="w-12 h-12 bg-indigo-700 rounded-full flex items-center justify-center">
            <span className="text-white font-medium">
              {review.client.name.charAt(0).toUpperCase()}
            </span>
          </div>
        </div>
        
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-lg font-medium text-white">
                {review.client.name}
              </h3>
              <div className="flex items-center mt-1">
                {renderStars(review.rating)}
                <span className="ml-2 text-indigo-300 text-sm">
                  {review.rating} {review.rating === 1 ? 'Star' : 'Stars'}
                </span>
              </div>
            </div>
            <span className="text-indigo-300 text-sm">
              {formatDate(review.createdAt)}
            </span>
          </div>
          
          <div className="mt-3">
            <p className="text-white">{review.comment}</p>
          </div>
          
          {review.project && (
            <div className="mt-3 text-sm">
              <span className="text-indigo-300">Project: </span>
              <span className="text-indigo-200">{review.project.title}</span>
            </div>
          )}
          
          {/* Freelancer Response */}
          {review.response && (
            <div className="mt-4 pl-4 border-l-2 border-indigo-600">
              <div className="flex items-start">
                <div className="flex-shrink-0 mr-3">
                  <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-medium">
                      {review.freelancer.name.charAt(0).toUpperCase()}
                    </span>
                  </div>
                </div>
                <div>
                  <div className="flex items-center">
                    <h4 className="text-indigo-400 font-medium">
                      {review.freelancer.name}
                    </h4>
                    <span className="ml-2 text-indigo-300 text-xs">
                      {formatDate(review.response.createdAt)}
                    </span>
                  </div>
                  <p className="text-indigo-200 mt-1">{review.response.content}</p>
                </div>
              </div>
            </div>
          )}
          
          {/* Response Form */}
          {canRespond() && (
            <div className="mt-4">
              {showResponseForm ? (
                <form onSubmit={handleSubmitResponse}>
                  <textarea
                    value={responseText}
                    onChange={(e) => setResponseText(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    rows="3"
                    placeholder="Write your response to this review..."
                    required
                  ></textarea>
                  
                  <div className="flex justify-end mt-2 space-x-2">
                    <button
                      type="button"
                      onClick={() => setShowResponseForm(false)}
                      className="px-4 py-2 border border-gray-700 rounded-md text-indigo-300 hover:bg-gray-800 transition-colors"
                    >
                      Cancel
                    </button>
                    <GlowButton
                      type="submit"
                      variant="primary"
                      className="px-4 py-2"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? 'Submitting...' : 'Submit Response'}
                    </GlowButton>
                  </div>
                </form>
              ) : (
                <button
                  onClick={() => setShowResponseForm(true)}
                  className="text-indigo-400 hover:text-indigo-300 transition-colors"
                >
                  Respond to this review
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </GlassCard>
  );
};

export default ReviewCard;
