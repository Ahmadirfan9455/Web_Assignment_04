import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import GlassCard from '../ui/GlassCard';
import GlowButton from '../ui/GlowButton';

const ReviewForm = ({ contractId, freelancerId, onReviewSubmitted }) => {
  // Form state
  const [formData, setFormData] = useState({
    rating: 0,
    comment: '',
    privateNote: '',
  });
  
  // UI states
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hoverRating, setHoverRating] = useState(0);
  
  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };
  
  // Handle rating selection
  const handleRatingClick = (rating) => {
    setFormData(prev => ({
      ...prev,
      rating,
    }));
  };
  
  // Handle rating hover
  const handleRatingHover = (rating) => {
    setHoverRating(rating);
  };
  
  // Handle rating hover leave
  const handleRatingLeave = () => {
    setHoverRating(0);
  };
  
  // Submit review
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate form
    if (formData.rating === 0) {
      toast.error('Please select a rating');
      return;
    }
    
    if (!formData.comment.trim()) {
      toast.error('Please provide a review comment');
      return;
    }
    
    try {
      setIsSubmitting(true);
      
      // Submit review
      await axios.post(`/api/reviews`, {
        contractId,
        freelancerId,
        rating: formData.rating,
        comment: formData.comment,
        privateNote: formData.privateNote,
      });
      
      toast.success('Review submitted successfully!');
      
      // Reset form
      setFormData({
        rating: 0,
        comment: '',
        privateNote: '',
      });
      
      // Notify parent component
      if (onReviewSubmitted) {
        onReviewSubmitted();
      }
    } catch (error) {
      console.error('Error submitting review:', error);
      toast.error(error.response?.data?.message || 'Failed to submit review. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <GlassCard className="p-6">
      <h2 className="text-xl font-semibold text-white mb-4">Rate Your Experience</h2>
      
      <form onSubmit={handleSubmit}>
        {/* Rating Stars */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-indigo-300 mb-2">
            Rating <span className="text-red-400">*</span>
          </label>
          <div 
            className="flex items-center space-x-1"
            onMouseLeave={handleRatingLeave}
          >
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => handleRatingClick(star)}
                onMouseEnter={() => handleRatingHover(star)}
                className="focus:outline-none transition-transform hover:scale-110"
              >
                <svg
                  className={`w-8 h-8 ${
                    (hoverRating || formData.rating) >= star
                      ? 'text-yellow-400'
                      : 'text-gray-600'
                  }`}
                  fill="currentColor"
                  viewBox="0 0 20 20"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              </button>
            ))}
            
            <span className="ml-2 text-indigo-300">
              {formData.rating > 0 ? (
                <span>
                  {formData.rating} {formData.rating === 1 ? 'Star' : 'Stars'}
                </span>
              ) : (
                <span className="text-gray-500">Select Rating</span>
              )}
            </span>
          </div>
        </div>
        
        {/* Review Comment */}
        <div className="mb-6">
          <label htmlFor="comment" className="block text-sm font-medium text-indigo-300 mb-2">
            Review Comment <span className="text-red-400">*</span>
          </label>
          <textarea
            id="comment"
            name="comment"
            value={formData.comment}
            onChange={handleChange}
            rows="4"
            className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="Share your experience working with this freelancer..."
            required
          ></textarea>
        </div>
        
        {/* Private Note */}
        <div className="mb-6">
          <label htmlFor="privateNote" className="block text-sm font-medium text-indigo-300 mb-2">
            Private Note (Optional)
          </label>
          <textarea
            id="privateNote"
            name="privateNote"
            value={formData.privateNote}
            onChange={handleChange}
            rows="2"
            className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="This note will only be visible to you and the platform administrators..."
          ></textarea>
          <p className="mt-1 text-xs text-indigo-300">
            This note will not be shared with the freelancer.
          </p>
        </div>
        
        {/* Submit Button */}
        <div className="flex justify-end">
          <GlowButton
            type="submit"
            variant="primary"
            className="px-6 py-2"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Submitting...' : 'Submit Review'}
          </GlowButton>
        </div>
      </form>
    </GlassCard>
  );
};

export default ReviewForm;
