import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNotification } from '../../hooks/useNotification';
import NotificationList from './NotificationList';
import GlassCard from '../ui/GlassCard';

const NotificationBell = () => {
  const { unreadCount } = useNotification();
  const [isOpen, setIsOpen] = useState(false);
  const bellRef = useRef(null);
  const dropdownRef = useRef(null);
  
  // Toggle notification dropdown
  const toggleNotifications = () => {
    setIsOpen(prev => !prev);
  };
  
  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        isOpen && 
        bellRef.current && 
        dropdownRef.current && 
        !bellRef.current.contains(event.target) && 
        !dropdownRef.current.contains(event.target)
      ) {
        setIsOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);
  
  // Bell animation variants
  const bellVariants = {
    initial: { rotate: 0 },
    ring: {
      rotate: [0, 15, -15, 10, -10, 5, -5, 0],
      transition: {
        duration: 0.6,
        ease: "easeInOut",
        times: [0, 0.1, 0.3, 0.4, 0.5, 0.6, 0.8, 1]
      }
    }
  };
  
  // Dropdown animation variants
  const dropdownVariants = {
    hidden: { 
      opacity: 0,
      y: -20,
      scale: 0.95
    },
    visible: { 
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 30
      }
    },
    exit: { 
      opacity: 0,
      y: -20,
      scale: 0.95,
      transition: {
        duration: 0.2
      }
    }
  };
  
  return (
    <div className="relative">
      {/* Bell Icon */}
      <motion.button
        ref={bellRef}
        onClick={toggleNotifications}
        className="relative p-2 text-indigo-300 hover:text-white focus:outline-none"
        variants={bellVariants}
        initial="initial"
        animate={unreadCount > 0 ? "ring" : "initial"}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
      >
        <svg 
          className="w-6 h-6" 
          fill="none" 
          stroke="currentColor" 
          viewBox="0 0 24 24" 
          xmlns="http://www.w3.org/2000/svg"
        >
          <path 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            strokeWidth="2" 
            d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
          ></path>
        </svg>
        
        {/* Notification Badge */}
        {unreadCount > 0 && (
          <motion.span 
            className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-red-500 rounded-full"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
          >
            {unreadCount > 99 ? '99+' : unreadCount}
          </motion.span>
        )}
      </motion.button>
      
      {/* Notification Dropdown */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            ref={dropdownRef}
            className="absolute right-0 mt-2 w-80 z-50"
            variants={dropdownVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
          >
            <GlassCard className="p-0 overflow-hidden">
              <NotificationList onClose={() => setIsOpen(false)} />
            </GlassCard>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default NotificationBell;
