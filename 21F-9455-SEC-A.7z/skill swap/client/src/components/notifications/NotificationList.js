import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { useNotification } from '../../hooks/useNotification';
import NotificationItem from './NotificationItem';
import GlowButton from '../ui/GlowButton';

const NotificationList = ({ onClose }) => {
  const { 
    notifications, 
    loading, 
    unreadCount, 
    markAllAsRead, 
    deleteAllNotifications,
    fetchNotifications
  } = useNotification();
  
  // Handle mark all as read
  const handleMarkAllAsRead = async () => {
    await markAllAsRead();
  };
  
  // Handle clear all notifications
  const handleClearAll = async () => {
    await deleteAllNotifications();
  };
  
  // Refresh notifications
  const handleRefresh = async () => {
    await fetchNotifications();
  };
  
  // Animation variants
  const listVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05
      }
    }
  };
  
  return (
    <div className="max-h-[80vh] flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-gray-700 flex justify-between items-center">
        <h3 className="text-lg font-medium text-white">
          Notifications
          {unreadCount > 0 && (
            <span className="ml-2 text-sm bg-indigo-600 text-white px-2 py-0.5 rounded-full">
              {unreadCount} new
            </span>
          )}
        </h3>
        
        <div className="flex space-x-2">
          <button 
            onClick={handleRefresh}
            className="text-indigo-300 hover:text-indigo-200 p-1"
            title="Refresh"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
            </svg>
          </button>
          
          {unreadCount > 0 && (
            <button 
              onClick={handleMarkAllAsRead}
              className="text-indigo-300 hover:text-indigo-200 p-1"
              title="Mark all as read"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
              </svg>
            </button>
          )}
          
          {notifications.length > 0 && (
            <button 
              onClick={handleClearAll}
              className="text-indigo-300 hover:text-indigo-200 p-1"
              title="Clear all"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
              </svg>
            </button>
          )}
        </div>
      </div>
      
      {/* Notification List */}
      <div className="overflow-y-auto flex-1">
        {loading ? (
          <div className="flex justify-center items-center p-6">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-indigo-500"></div>
          </div>
        ) : notifications.length > 0 ? (
          <motion.div
            variants={listVariants}
            initial="hidden"
            animate="visible"
            className="divide-y divide-gray-700"
          >
            {notifications.map(notification => (
              <NotificationItem 
                key={notification._id} 
                notification={notification}
                onClose={onClose}
              />
            ))}
          </motion.div>
        ) : (
          <div className="p-6 text-center">
            <svg className="w-12 h-12 text-indigo-400 mx-auto mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path>
            </svg>
            <p className="text-indigo-300">No notifications yet</p>
          </div>
        )}
      </div>
      
      {/* Footer */}
      <div className="p-3 border-t border-gray-700 text-center">
        <Link to="/notifications" onClick={onClose}>
          <GlowButton variant="secondary" className="w-full py-1.5">
            View All Notifications
          </GlowButton>
        </Link>
      </div>
    </div>
  );
};

export default NotificationList;
