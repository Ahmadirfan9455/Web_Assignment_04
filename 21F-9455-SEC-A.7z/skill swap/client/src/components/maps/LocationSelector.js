import React, { useState, useCallback, useEffect } from 'react';
import { GoogleMap, Marker, useJsApiLoader } from '@react-google-maps/api';

const containerStyle = {
  width: '100%',
  height: '400px',
  borderRadius: '0.5rem'
};

// Default center (can be customized by parent component)
const defaultCenter = {
  lat: 40.7128,
  lng: -74.0060 // New York
};

const LocationSelector = ({ 
  onLocationSelect, 
  initialLocation = null, 
  googleMapsApiKey = "AIzaSyBk2TxVQIo-_GjqH5csD-PMHuhIK-QdjoE" 
}) => {
  // Load Google Maps API
  const { isLoaded, loadError } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey,
    libraries: ['places']
  });

  // State for the map and marker
  const [map, setMap] = useState(null);
  const [marker, setMarker] = useState(initialLocation || defaultCenter);
  const [address, setAddress] = useState('');

  // Initialize geocoder when map is loaded
  const [geocoder, setGeocoder] = useState(null);
  
  useEffect(() => {
    if (isLoaded && !geocoder) {
      setGeocoder(new window.google.maps.Geocoder());
    }
  }, [isLoaded, geocoder]);

  // Update the marker position when initialLocation changes
  useEffect(() => {
    if (initialLocation) {
      setMarker(initialLocation);
      if (geocoder) {
        // Reverse geocode to get address
        geocoder.geocode({ location: initialLocation }, (results, status) => {
          if (status === "OK" && results[0]) {
            setAddress(results[0].formatted_address);
          }
        });
      }
    }
  }, [initialLocation, geocoder]);

  // When map loads
  const onLoad = useCallback((map) => {
    setMap(map);
  }, []);

  // When map unmounts
  const onUnmount = useCallback(() => {
    setMap(null);
  }, []);

  // Handle map click to place marker
  const handleMapClick = (event) => {
    const newLocation = {
      lat: event.latLng.lat(),
      lng: event.latLng.lng()
    };
    
    setMarker(newLocation);
    
    // Get address from coordinates (reverse geocoding)
    if (geocoder) {
      geocoder.geocode({ location: newLocation }, (results, status) => {
        if (status === "OK" && results[0]) {
          setAddress(results[0].formatted_address);
        }
      });
    }
    
    // Pass location to parent component
    if (onLocationSelect) {
      onLocationSelect(newLocation, address);
    }
  };

  // Handle search by address
  const handleAddressSearch = () => {
    if (geocoder && address) {
      geocoder.geocode({ address }, (results, status) => {
        if (status === "OK" && results[0]) {
          const location = results[0].geometry.location;
          const newLocation = {
            lat: location.lat(),
            lng: location.lng()
          };
          
          setMarker(newLocation);
          map.panTo(newLocation);
          
          // Pass location to parent component
          if (onLocationSelect) {
            onLocationSelect(newLocation, address);
          }
        } else {
          console.error("Geocode was not successful for the following reason: " + status);
        }
      });
    }
  };

  // Show loading, error, or map
  if (loadError) {
    return <div className="p-4 text-red-500">Error loading maps</div>;
  }

  if (!isLoaded) {
    return <div className="p-4">Loading maps...</div>;
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex gap-2">
        <input
          type="text"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          placeholder="Search for a location"
          className="flex-1 px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400"
        />
        <button
          onClick={handleAddressSearch}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-md text-white"
        >
          Search
        </button>
      </div>
      
      <GoogleMap
        mapContainerStyle={containerStyle}
        center={marker || defaultCenter}
        zoom={13}
        onClick={handleMapClick}
        onLoad={onLoad}
        onUnmount={onUnmount}
        options={{
          styles: [
            { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
            { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
            { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
            {
              featureType: "administrative.locality",
              elementType: "labels.text.fill",
              stylers: [{ color: "#d59563" }],
            },
            {
              featureType: "poi",
              elementType: "labels.text.fill",
              stylers: [{ color: "#d59563" }],
            },
            {
              featureType: "poi.park",
              elementType: "geometry",
              stylers: [{ color: "#263c3f" }],
            },
            {
              featureType: "poi.park",
              elementType: "labels.text.fill",
              stylers: [{ color: "#6b9a76" }],
            },
            {
              featureType: "road",
              elementType: "geometry",
              stylers: [{ color: "#38414e" }],
            },
            {
              featureType: "road",
              elementType: "geometry.stroke",
              stylers: [{ color: "#212a37" }],
            },
            {
              featureType: "road",
              elementType: "labels.text.fill",
              stylers: [{ color: "#9ca5b3" }],
            },
            {
              featureType: "road.highway",
              elementType: "geometry",
              stylers: [{ color: "#746855" }],
            },
            {
              featureType: "road.highway",
              elementType: "geometry.stroke",
              stylers: [{ color: "#1f2835" }],
            },
            {
              featureType: "road.highway",
              elementType: "labels.text.fill",
              stylers: [{ color: "#f3d19c" }],
            },
            {
              featureType: "transit",
              elementType: "geometry",
              stylers: [{ color: "#2f3948" }],
            },
            {
              featureType: "transit.station",
              elementType: "labels.text.fill",
              stylers: [{ color: "#d59563" }],
            },
            {
              featureType: "water",
              elementType: "geometry",
              stylers: [{ color: "#17263c" }],
            },
            {
              featureType: "water",
              elementType: "labels.text.fill",
              stylers: [{ color: "#515c6d" }],
            },
            {
              featureType: "water",
              elementType: "labels.text.stroke",
              stylers: [{ color: "#17263c" }],
            },
          ],
        }}
      >
        {marker && <Marker position={marker} />}
      </GoogleMap>
      
      {marker && (
        <div className="mt-2 text-sm text-indigo-300">
          <p>Latitude: {marker.lat.toFixed(6)}</p>
          <p>Longitude: {marker.lng.toFixed(6)}</p>
          {address && <p>Address: {address}</p>}
        </div>
      )}
    </div>
  );
};

export default LocationSelector;
