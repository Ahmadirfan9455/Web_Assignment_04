import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../../hooks/useAuth';
import GlowButton from '../ui/GlowButton';
import { toast } from 'react-toastify';

// Icons
import { 
  HomeIcon, 
  UserIcon, 
  BriefcaseIcon, 
  ChatBubbleLeftRightIcon,
  DocumentTextIcon,
  ChartBarIcon,
  Bars3Icon,
  XMarkIcon,
  ArrowRightOnRectangleIcon
} from '@heroicons/react/24/outline';

const Navbar = () => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeLink, setActiveLink] = useState('');

  // Handle scroll effect for glass navbar
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Set active link based on current location
  useEffect(() => {
    setActiveLink(location.pathname);
  }, [location]);

  // Handle logout
  const handleLogout = async () => {
    try {
      await logout();
      toast.success('Logged out successfully!');
    } catch (error) {
      toast.error('Failed to logout. Please try again.');
    }
  };

  // Navigation links based on user role
  const getNavLinks = () => {
    const commonLinks = [
      { name: 'Home', path: '/', icon: HomeIcon },
      { name: 'Freelancers', path: '/freelancers', icon: UserIcon },
    ];

    const authLinks = user ? [
      { name: 'Dashboard', path: '/dashboard', icon: ChartBarIcon },
      { name: 'Projects', path: '/projects', icon: BriefcaseIcon },
      { name: 'Messages', path: '/messages', icon: ChatBubbleLeftRightIcon },
      { name: 'Contracts', path: '/contracts', icon: DocumentTextIcon },
    ] : [];

    const adminLinks = user && user.role === 'admin' ? [
      { name: 'Admin', path: '/admin', icon: ChartBarIcon },
    ] : [];

    return [...commonLinks, ...authLinks, ...adminLinks];
  };

  // Animation variants
  const navVariants = {
    hidden: { opacity: 0, y: -20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { 
        duration: 0.5,
        ease: [0.43, 0.13, 0.23, 0.96]
      }
    }
  };

  const mobileMenuVariants = {
    hidden: { 
      opacity: 0,
      x: '100%',
      transition: {
        duration: 0.3,
        ease: [0.43, 0.13, 0.23, 0.96]
      }
    },
    visible: { 
      opacity: 1,
      x: 0,
      transition: {
        duration: 0.5,
        ease: [0.43, 0.13, 0.23, 0.96],
        staggerChildren: 0.1,
        when: 'beforeChildren'
      }
    }
  };

  const linkVariants = {
    hidden: { opacity: 0, x: 20 },
    visible: { 
      opacity: 1, 
      x: 0,
      transition: { 
        duration: 0.3,
        ease: [0.43, 0.13, 0.23, 0.96]
      }
    }
  };

  const logoVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: { 
      opacity: 1, 
      scale: 1,
      transition: { 
        duration: 0.5,
        ease: [0.43, 0.13, 0.23, 0.96]
      }
    },
    hover: {
      scale: 1.05,
      transition: { 
        duration: 0.3,
        ease: [0.43, 0.13, 0.23, 0.96]
      }
    }
  };

  return (
    <>
      <motion.nav 
        className={`fixed top-0 left-0 right-0 z-40 py-4 px-6 transition-all duration-300 ${
          scrolled ? 'glass-card bg-opacity-70' : 'bg-transparent'
        }`}
        variants={navVariants}
        initial="hidden"
        animate="visible"
      >
        <div className="container mx-auto flex justify-between items-center">
          {/* Logo */}
          <motion.div 
            className="flex items-center"
            variants={logoVariants}
            whileHover="hover"
          >
            <Link to="/" className="flex items-center">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-primary-500 via-secondary-500 to-accent-500 flex items-center justify-center mr-2">
                <span className="text-white font-display font-bold text-xl">SS</span>
              </div>
              <span className="text-white font-display font-bold text-xl">SkillSwap</span>
            </Link>
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {getNavLinks().map((link) => (
              <motion.div
                key={link.path}
                className="relative px-1"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Link 
                  to={link.path}
                  className={`px-4 py-2 rounded-lg flex items-center transition-all duration-300 ${
                    activeLink === link.path 
                      ? 'text-white bg-white/10' 
                      : 'text-gray-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <link.icon className="w-5 h-5 mr-1" />
                  <span>{link.name}</span>
                </Link>
                {activeLink === link.path && (
                  <motion.div 
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-primary-500 via-secondary-500 to-accent-500"
                    layoutId="activeNavIndicator"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.3 }}
                  />
                )}
              </motion.div>
            ))}

            {/* Auth Buttons */}
            <div className="ml-4 flex items-center space-x-3">
              {user ? (
                <>
                  <Link to="/profile">
                    <motion.div 
                      className="w-10 h-10 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500 flex items-center justify-center overflow-hidden border-2 border-white/20"
                      whileHover={{ scale: 1.1, borderColor: 'rgba(255, 255, 255, 0.5)' }}
                      whileTap={{ scale: 0.95 }}
                    >
                      {user.profileImage ? (
                        <img 
                          src={user.profileImage} 
                          alt={user.name} 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span className="text-white font-medium">
                          {user.name?.charAt(0) || 'U'}
                        </span>
                      )}
                    </motion.div>
                  </Link>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={handleLogout}
                    className="text-gray-300 hover:text-white"
                  >
                    <ArrowRightOnRectangleIcon className="w-6 h-6" />
                  </motion.button>
                </>
              ) : (
                <>
                  <Link to="/login">
                    <GlowButton variant="primary" size="sm">
                      Login
                    </GlowButton>
                  </Link>
                  <Link to="/register">
                    <GlowButton variant="gradient" size="sm">
                      Register
                    </GlowButton>
                  </Link>
                </>
              )}
            </div>
          </div>

          {/* Mobile Menu Button */}
          <motion.button
            className="md:hidden text-white"
            onClick={() => setIsOpen(!isOpen)}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            {isOpen ? (
              <XMarkIcon className="w-7 h-7" />
            ) : (
              <Bars3Icon className="w-7 h-7" />
            )}
          </motion.button>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed inset-0 z-30 md:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            {/* Backdrop */}
            <motion.div 
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setIsOpen(false)}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            />

            {/* Menu */}
            <motion.div 
              className="absolute top-0 right-0 w-3/4 h-full glass-card py-20 px-6"
              variants={mobileMenuVariants}
              initial="hidden"
              animate="visible"
              exit="hidden"
            >
              <div className="flex flex-col space-y-4">
                {getNavLinks().map((link) => (
                  <motion.div
                    key={link.path}
                    variants={linkVariants}
                    whileHover={{ x: 5 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Link 
                      to={link.path}
                      className={`px-4 py-3 rounded-lg flex items-center transition-all duration-300 ${
                        activeLink === link.path 
                          ? 'text-white bg-white/10 glow-border' 
                          : 'text-gray-300 hover:text-white hover:bg-white/5'
                      }`}
                      onClick={() => setIsOpen(false)}
                    >
                      <link.icon className="w-5 h-5 mr-3" />
                      <span>{link.name}</span>
                    </Link>
                  </motion.div>
                ))}

                {/* Auth Buttons */}
                <motion.div 
                  className="pt-4 mt-4 border-t border-white/10"
                  variants={linkVariants}
                >
                  {user ? (
                    <div className="flex items-center justify-between">
                      <Link 
                        to="/profile"
                        className="flex items-center"
                        onClick={() => setIsOpen(false)}
                      >
                        <div className="w-10 h-10 rounded-full bg-gradient-to-r from-primary-500 to-secondary-500 flex items-center justify-center overflow-hidden mr-3">
                          {user.profileImage ? (
                            <img 
                              src={user.profileImage} 
                              alt={user.name} 
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <span className="text-white font-medium">
                              {user.name?.charAt(0) || 'U'}
                            </span>
                          )}
                        </div>
                        <div>
                          <p className="text-white font-medium">{user.name}</p>
                          <p className="text-gray-400 text-sm">{user.role}</p>
                        </div>
                      </Link>
                      <button
                        onClick={() => {
                          handleLogout();
                          setIsOpen(false);
                        }}
                        className="text-gray-300 hover:text-white p-2"
                      >
                        <ArrowRightOnRectangleIcon className="w-6 h-6" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex flex-col space-y-3">
                      <Link 
                        to="/login"
                        onClick={() => setIsOpen(false)}
                        className="w-full"
                      >
                        <GlowButton variant="primary" className="w-full">
                          Login
                        </GlowButton>
                      </Link>
                      <Link 
                        to="/register"
                        onClick={() => setIsOpen(false)}
                        className="w-full"
                      >
                        <GlowButton variant="gradient" className="w-full">
                          Register
                        </GlowButton>
                      </Link>
                    </div>
                  )}
                </motion.div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Navbar;
