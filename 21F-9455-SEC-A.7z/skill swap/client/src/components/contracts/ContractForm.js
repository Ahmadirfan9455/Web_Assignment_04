import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../ui/GlassCard';
import GlowButton from '../ui/GlowButton';

const ContractForm = ({ projectId, onContractCreated }) => {
  const { user } = useAuth();
  
  // State
  const [formData, setFormData] = useState({
    startDate: '',
    endDate: '',
    amount: '',
    terms: '',
    paymentSchedule: 'milestone', // 'milestone' or 'fixed'
    milestones: []
  });
  
  const [project, setProject] = useState(null);
  const [freelancer, setFreelancer] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [milestoneCount, setMilestoneCount] = useState(1);
  
  // Fetch project data
  useEffect(() => {
    const fetchProjectData = async () => {
      try {
        setIsLoading(true);
        
        // Fetch project details
        const { data } = await axios.get(`/api/projects/${projectId}`);
        setProject(data);
        
        // Set default amount to project budget
        setFormData(prev => ({
          ...prev,
          amount: data.budget.toString()
        }));
        
        // Fetch freelancer details if there's a selected freelancer
        if (data.selectedFreelancer) {
          const { data: freelancerData } = await axios.get(`/api/users/${data.selectedFreelancer}`);
          setFreelancer(freelancerData);
        }
        
        setIsLoading(false);
      } catch (error) {
        console.error('Error fetching project data:', error);
        toast.error('Failed to load project data');
        setIsLoading(false);
      }
    };
    
    fetchProjectData();
  }, [projectId]);
  
  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Handle milestone input change
  const handleMilestoneChange = (index, field, value) => {
    const updatedMilestones = [...formData.milestones];
    
    if (!updatedMilestones[index]) {
      updatedMilestones[index] = {
        title: '',
        description: '',
        amount: '',
        dueDate: ''
      };
    }
    
    updatedMilestones[index][field] = value;
    
    setFormData(prev => ({
      ...prev,
      milestones: updatedMilestones
    }));
  };
  
  // Add milestone
  const addMilestone = () => {
    setMilestoneCount(prev => prev + 1);
  };
  
  // Remove milestone
  const removeMilestone = (index) => {
    const updatedMilestones = [...formData.milestones];
    updatedMilestones.splice(index, 1);
    
    setFormData(prev => ({
      ...prev,
      milestones: updatedMilestones
    }));
    
    setMilestoneCount(prev => prev - 1);
  };
  
  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.startDate) {
      toast.error('Please select a start date');
      return;
    }
    
    if (!formData.endDate) {
      toast.error('Please select an end date');
      return;
    }
    
    if (new Date(formData.startDate) >= new Date(formData.endDate)) {
      toast.error('End date must be after start date');
      return;
    }
    
    if (!formData.amount || isNaN(formData.amount) || parseFloat(formData.amount) <= 0) {
      toast.error('Please enter a valid contract amount');
      return;
    }
    
    if (!formData.terms.trim()) {
      toast.error('Please provide contract terms');
      return;
    }
    
    // Validate milestones if payment schedule is milestone-based
    if (formData.paymentSchedule === 'milestone') {
      // Check if we have at least one milestone
      if (formData.milestones.length === 0) {
        toast.error('Please add at least one milestone');
        return;
      }
      
      // Validate each milestone
      let totalMilestoneAmount = 0;
      
      for (let i = 0; i < formData.milestones.length; i++) {
        const milestone = formData.milestones[i];
        
        if (!milestone || !milestone.title || !milestone.title.trim()) {
          toast.error(`Please provide a title for milestone ${i + 1}`);
          return;
        }
        
        if (!milestone.description || !milestone.description.trim()) {
          toast.error(`Please provide a description for milestone ${i + 1}`);
          return;
        }
        
        if (!milestone.amount || isNaN(milestone.amount) || parseFloat(milestone.amount) <= 0) {
          toast.error(`Please provide a valid amount for milestone ${i + 1}`);
          return;
        }
        
        if (!milestone.dueDate) {
          toast.error(`Please provide a due date for milestone ${i + 1}`);
          return;
        }
        
        totalMilestoneAmount += parseFloat(milestone.amount);
      }
      
      // Check if milestone amounts add up to contract amount
      if (Math.abs(totalMilestoneAmount - parseFloat(formData.amount)) > 0.01) {
        toast.error(`The sum of milestone amounts (${totalMilestoneAmount.toFixed(2)}) must equal the contract amount (${parseFloat(formData.amount).toFixed(2)})`);
        return;
      }
    }
    
    try {
      setIsSubmitting(true);
      
      // Create contract
      const { data } = await axios.post('/api/contracts', {
        projectId,
        freelancerId: project.selectedFreelancer,
        startDate: formData.startDate,
        endDate: formData.endDate,
        amount: parseFloat(formData.amount),
        terms: formData.terms,
        paymentSchedule: formData.paymentSchedule,
        milestones: formData.milestones.map(milestone => ({
          ...milestone,
          amount: parseFloat(milestone.amount)
        }))
      });
      
      toast.success('Contract created successfully!');
      
      // Notify parent component
      if (onContractCreated) {
        onContractCreated(data);
      }
    } catch (error) {
      console.error('Error creating contract:', error);
      toast.error(error.response?.data?.message || 'Failed to create contract. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Loading state
  if (isLoading) {
    return (
      <GlassCard className="p-6">
        <div className="flex justify-center items-center h-40">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
        </div>
      </GlassCard>
    );
  }
  
  // Check if project has a selected freelancer
  if (!project.selectedFreelancer) {
    return (
      <GlassCard className="p-6">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-white mb-2">No Freelancer Selected</h2>
          <p className="text-indigo-300 mb-4">
            You need to select a freelancer for this project before creating a contract.
          </p>
          <GlowButton
            variant="primary"
            onClick={() => window.location.href = `/projects/${projectId}`}
          >
            Go to Project Details
          </GlowButton>
        </div>
      </GlassCard>
    );
  }
  
  return (
    <GlassCard className="p-6">
      <h2 className="text-xl font-semibold text-white mb-4">Create Contract</h2>
      
      {/* Project and Freelancer Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <h3 className="text-indigo-300 text-sm mb-2">Project</h3>
          <p className="text-white font-medium">{project.title}</p>
          <p className="text-indigo-300 text-sm mt-1">Budget: ${project.budget.toFixed(2)}</p>
        </div>
        
        <div>
          <h3 className="text-indigo-300 text-sm mb-2">Freelancer</h3>
          {freelancer ? (
            <div className="flex items-center">
              <div className="w-10 h-10 bg-indigo-700 rounded-full flex items-center justify-center mr-3">
                <span className="text-white font-medium">
                  {freelancer.name.charAt(0).toUpperCase()}
                </span>
              </div>
              <div>
                <p className="text-white font-medium">{freelancer.name}</p>
                <p className="text-indigo-300 text-sm">{freelancer.email}</p>
              </div>
            </div>
          ) : (
            <p className="text-indigo-300">Loading freelancer details...</p>
          )}
        </div>
      </div>
      
      <form onSubmit={handleSubmit}>
        {/* Contract Dates */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label htmlFor="startDate" className="block text-sm font-medium text-indigo-300 mb-2">
              Start Date <span className="text-red-400">*</span>
            </label>
            <input
              type="date"
              id="startDate"
              name="startDate"
              value={formData.startDate}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              required
            />
          </div>
          
          <div>
            <label htmlFor="endDate" className="block text-sm font-medium text-indigo-300 mb-2">
              End Date <span className="text-red-400">*</span>
            </label>
            <input
              type="date"
              id="endDate"
              name="endDate"
              value={formData.endDate}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              required
            />
          </div>
        </div>
        
        {/* Contract Amount */}
        <div className="mb-4">
          <label htmlFor="amount" className="block text-sm font-medium text-indigo-300 mb-2">
            Contract Amount ($) <span className="text-red-400">*</span>
          </label>
          <input
            type="number"
            id="amount"
            name="amount"
            value={formData.amount}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="0.00"
            min="0"
            step="0.01"
            required
          />
        </div>
        
        {/* Payment Schedule */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-indigo-300 mb-2">
            Payment Schedule <span className="text-red-400">*</span>
          </label>
          <div className="flex space-x-4">
            <label className="inline-flex items-center">
              <input
                type="radio"
                name="paymentSchedule"
                value="fixed"
                checked={formData.paymentSchedule === 'fixed'}
                onChange={handleChange}
                className="form-radio h-4 w-4 text-indigo-600 transition duration-150 ease-in-out"
              />
              <span className="ml-2 text-white">Fixed Payment</span>
            </label>
            
            <label className="inline-flex items-center">
              <input
                type="radio"
                name="paymentSchedule"
                value="milestone"
                checked={formData.paymentSchedule === 'milestone'}
                onChange={handleChange}
                className="form-radio h-4 w-4 text-indigo-600 transition duration-150 ease-in-out"
              />
              <span className="ml-2 text-white">Milestone-based</span>
            </label>
          </div>
        </div>
        
        {/* Milestones (if milestone-based) */}
        {formData.paymentSchedule === 'milestone' && (
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-indigo-300 text-sm">Milestones</h3>
              <button
                type="button"
                onClick={addMilestone}
                className="text-indigo-400 hover:text-indigo-300 text-sm flex items-center"
              >
                <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                </svg>
                Add Milestone
              </button>
            </div>
            
            {Array.from({ length: milestoneCount }).map((_, index) => (
              <div key={index} className="border border-gray-700 rounded-md p-4 mb-4">
                <div className="flex justify-between items-center mb-3">
                  <h4 className="text-white font-medium">Milestone {index + 1}</h4>
                  {index > 0 && (
                    <button
                      type="button"
                      onClick={() => removeMilestone(index)}
                      className="text-red-400 hover:text-red-300 text-sm"
                    >
                      Remove
                    </button>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                  <div>
                    <label className="block text-sm font-medium text-indigo-300 mb-1">
                      Title <span className="text-red-400">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.milestones[index]?.title || ''}
                      onChange={(e) => handleMilestoneChange(index, 'title', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                      placeholder="Milestone title"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-indigo-300 mb-1">
                      Amount ($) <span className="text-red-400">*</span>
                    </label>
                    <input
                      type="number"
                      value={formData.milestones[index]?.amount || ''}
                      onChange={(e) => handleMilestoneChange(index, 'amount', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                      placeholder="0.00"
                      min="0"
                      step="0.01"
                      required
                    />
                  </div>
                </div>
                
                <div className="mb-3">
                  <label className="block text-sm font-medium text-indigo-300 mb-1">
                    Description <span className="text-red-400">*</span>
                  </label>
                  <textarea
                    value={formData.milestones[index]?.description || ''}
                    onChange={(e) => handleMilestoneChange(index, 'description', e.target.value)}
                    rows="2"
                    className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="Describe what needs to be completed for this milestone..."
                    required
                  ></textarea>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-indigo-300 mb-1">
                    Due Date <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="date"
                    value={formData.milestones[index]?.dueDate || ''}
                    onChange={(e) => handleMilestoneChange(index, 'dueDate', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                    required
                  />
                </div>
              </div>
            ))}
          </div>
        )}
        
        {/* Contract Terms */}
        <div className="mb-6">
          <label htmlFor="terms" className="block text-sm font-medium text-indigo-300 mb-2">
            Contract Terms <span className="text-red-400">*</span>
          </label>
          <textarea
            id="terms"
            name="terms"
            value={formData.terms}
            onChange={handleChange}
            rows="6"
            className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="Specify the terms and conditions of this contract..."
            required
          ></textarea>
          <p className="mt-1 text-xs text-indigo-300">
            Include details about scope of work, deliverables, payment terms, intellectual property rights, etc.
          </p>
        </div>
        
        {/* Submit Button */}
        <div className="flex justify-end">
          <GlowButton
            type="submit"
            variant="primary"
            className="px-6 py-2"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Creating Contract...' : 'Create Contract'}
          </GlowButton>
        </div>
      </form>
    </GlassCard>
  );
};

export default ContractForm;
