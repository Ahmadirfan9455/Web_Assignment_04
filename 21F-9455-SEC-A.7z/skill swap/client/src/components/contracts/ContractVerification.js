import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import GlassCard from '../ui/GlassCard';
import GlowButton from '../ui/GlowButton';

const ContractVerification = () => {
  // State
  const [contractId, setContractId] = useState('');
  const [contractHash, setContractHash] = useState('');
  const [verificationResult, setVerificationResult] = useState(null);
  const [isVerifying, setIsVerifying] = useState(false);
  
  // Handle input change
  const handleContractIdChange = (e) => {
    setContractId(e.target.value);
    // Reset verification result when input changes
    setVerificationResult(null);
  };
  
  // Handle hash input change
  const handleHashChange = (e) => {
    setContractHash(e.target.value);
    // Reset verification result when input changes
    setVerificationResult(null);
  };
  
  // Handle verification
  const handleVerify = async (e) => {
    e.preventDefault();
    
    if (!contractId.trim()) {
      toast.error('Please enter a contract ID');
      return;
    }
    
    if (!contractHash.trim()) {
      toast.error('Please enter a contract hash');
      return;
    }
    
    try {
      setIsVerifying(true);
      
      // Verify contract
      const { data } = await axios.post('/api/contracts/verify', {
        contractId,
        hash: contractHash
      });
      
      setVerificationResult(data);
      
      if (data.valid) {
        toast.success('Contract verified successfully!');
      } else {
        toast.error('Contract verification failed!');
      }
    } catch (error) {
      console.error('Error verifying contract:', error);
      toast.error(error.response?.data?.message || 'Failed to verify contract. Please try again.');
      
      setVerificationResult({
        valid: false,
        message: error.response?.data?.message || 'Failed to verify contract'
      });
    } finally {
      setIsVerifying(false);
    }
  };
  
  return (
    <GlassCard className="p-6">
      <h2 className="text-xl font-semibold text-white mb-4">Verify Contract Integrity</h2>
      
      <p className="text-indigo-300 mb-6">
        Verify the integrity of a contract by providing its ID and hash. This ensures the contract has not been tampered with.
      </p>
      
      <form onSubmit={handleVerify}>
        <div className="mb-4">
          <label htmlFor="contractId" className="block text-sm font-medium text-indigo-300 mb-2">
            Contract ID <span className="text-red-400">*</span>
          </label>
          <input
            type="text"
            id="contractId"
            value={contractId}
            onChange={handleContractIdChange}
            className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="Enter contract ID"
            required
          />
        </div>
        
        <div className="mb-6">
          <label htmlFor="contractHash" className="block text-sm font-medium text-indigo-300 mb-2">
            Contract Hash (SHA-256) <span className="text-red-400">*</span>
          </label>
          <input
            type="text"
            id="contractHash"
            value={contractHash}
            onChange={handleHashChange}
            className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="Enter SHA-256 hash"
            required
          />
          <p className="mt-1 text-xs text-indigo-300">
            The SHA-256 hash can be found in the contract details page.
          </p>
        </div>
        
        <div className="flex justify-end">
          <GlowButton
            type="submit"
            variant="primary"
            className="px-6 py-2"
            disabled={isVerifying}
          >
            {isVerifying ? 'Verifying...' : 'Verify Contract'}
          </GlowButton>
        </div>
      </form>
      
      {/* Verification Result */}
      {verificationResult && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className={`mt-6 p-4 rounded-md ${
            verificationResult.valid
              ? 'bg-green-900/30 border border-green-700'
              : 'bg-red-900/30 border border-red-700'
          }`}
        >
          <div className="flex items-start">
            <div className="flex-shrink-0">
              {verificationResult.valid ? (
                <svg className="w-5 h-5 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                </svg>
              ) : (
                <svg className="w-5 h-5 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
              )}
            </div>
            <div className="ml-3">
              <h3 className={`text-lg font-medium ${
                verificationResult.valid ? 'text-green-400' : 'text-red-400'
              }`}>
                {verificationResult.valid ? 'Verification Successful' : 'Verification Failed'}
              </h3>
              <div className="mt-2 text-sm text-white">
                <p>{verificationResult.message}</p>
              </div>
              
              {verificationResult.valid && verificationResult.contract && (
                <div className="mt-4">
                  <h4 className="text-indigo-300 text-sm mb-2">Contract Details</h4>
                  <p className="text-white">
                    <span className="text-indigo-300">Project: </span>
                    {verificationResult.contract.project.title}
                  </p>
                  <p className="text-white">
                    <span className="text-indigo-300">Client: </span>
                    {verificationResult.contract.client.name}
                  </p>
                  <p className="text-white">
                    <span className="text-indigo-300">Freelancer: </span>
                    {verificationResult.contract.freelancer.name}
                  </p>
                  <p className="text-white">
                    <span className="text-indigo-300">Created: </span>
                    {new Date(verificationResult.contract.createdAt).toLocaleDateString()}
                  </p>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      )}
    </GlassCard>
  );
};

export default ContractVerification;
