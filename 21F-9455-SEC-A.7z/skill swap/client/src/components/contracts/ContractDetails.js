import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useAuth } from '../../hooks/useAuth';
import GlassCard from '../ui/GlassCard';
import GlowButton from '../ui/GlowButton';

const ContractDetails = ({ contract, onContractUpdate }) => {
  const { user } = useAuth();
  
  // State
  const [showSignModal, setShowSignModal] = useState(false);
  const [signature, setSignature] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Check if user is client or freelancer
  const isClient = user && user.role === 'client';
  const isFreelancer = user && user.role === 'freelancer';
  
  // Check if user can sign the contract
  const canSignContract = () => {
    if (!user || !contract) return false;
    
    if (isClient && !contract.clientSignedAt) {
      return true;
    }
    
    if (isFreelancer && !contract.freelancerSignedAt) {
      return true;
    }
    
    return false;
  };
  
  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'Not set';
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  // Format date with time
  const formatDateTime = (dateString) => {
    if (!dateString) return 'Not signed';
    const options = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  // Get contract status
  const getContractStatus = () => {
    if (!contract) return 'Unknown';
    
    if (contract.clientSignedAt && contract.freelancerSignedAt) {
      return 'Active';
    } else if (contract.clientSignedAt || contract.freelancerSignedAt) {
      return 'Partially Signed';
    } else {
      return 'Pending Signatures';
    }
  };
  
  // Get contract status color
  const getContractStatusColor = () => {
    const status = getContractStatus();
    
    switch (status) {
      case 'Active':
        return 'text-green-400';
      case 'Partially Signed':
        return 'text-yellow-400';
      case 'Pending Signatures':
        return 'text-indigo-400';
      case 'Completed':
        return 'text-blue-400';
      case 'Terminated':
        return 'text-red-400';
      default:
        return 'text-gray-400';
    }
  };
  
  // Handle signature input change
  const handleSignatureChange = (e) => {
    setSignature(e.target.value);
  };
  
  // Handle contract signing
  const handleSignContract = async () => {
    if (!signature.trim()) {
      toast.error('Please provide your signature');
      return;
    }
    
    try {
      setIsSubmitting(true);
      
      // Sign contract
      await axios.post(`/api/contracts/${contract._id}/sign`, {
        signature,
        userRole: user.role
      });
      
      toast.success('Contract signed successfully!');
      
      // Close modal
      setShowSignModal(false);
      setSignature('');
      
      // Notify parent component
      if (onContractUpdate) {
        onContractUpdate();
      }
    } catch (error) {
      console.error('Error signing contract:', error);
      toast.error(error.response?.data?.message || 'Failed to sign contract. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Render signature modal
  const renderSignatureModal = () => {
    if (!showSignModal) return null;
    
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          className="w-full max-w-md"
        >
          <GlassCard className="p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Sign Contract</h2>
            
            <p className="text-indigo-300 mb-4">
              By signing this contract, you agree to all terms and conditions outlined in the contract.
              This action cannot be undone.
            </p>
            
            <div className="mb-4">
              <label htmlFor="signature" className="block text-sm font-medium text-indigo-300 mb-2">
                Your Signature <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                id="signature"
                value={signature}
                onChange={handleSignatureChange}
                className="w-full px-3 py-2 border border-gray-700 bg-gray-900/50 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="Type your full name"
                required
              />
              <p className="mt-1 text-xs text-indigo-300">
                Type your full legal name as your electronic signature.
              </p>
            </div>
            
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => {
                  setShowSignModal(false);
                  setSignature('');
                }}
                className="px-4 py-2 border border-gray-700 rounded-md text-indigo-300 hover:bg-gray-800 transition-colors"
              >
                Cancel
              </button>
              
              <GlowButton
                variant="primary"
                onClick={handleSignContract}
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Signing...' : 'Sign Contract'}
              </GlowButton>
            </div>
          </GlassCard>
        </motion.div>
      </div>
    );
  };
  
  if (!contract) {
    return (
      <GlassCard className="p-6">
        <p className="text-indigo-300 text-center">Contract not found.</p>
      </GlassCard>
    );
  }
  
  return (
    <>
      {renderSignatureModal()}
      
      <GlassCard className="p-6">
        {/* Contract Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
          <div>
            <h2 className="text-xl font-semibold text-white">Contract</h2>
            <p className="text-indigo-300 text-sm">
              ID: {contract._id}
            </p>
          </div>
          
          <div className="mt-2 md:mt-0 flex items-center">
            <span className={`${getContractStatusColor()} font-medium`}>
              {getContractStatus()}
            </span>
            
            {canSignContract() && (
              <GlowButton
                variant="primary"
                className="ml-4"
                onClick={() => setShowSignModal(true)}
              >
                Sign Contract
              </GlowButton>
            )}
          </div>
        </div>
        
        {/* Project Details */}
        <div className="mb-6">
          <h3 className="text-indigo-300 text-sm mb-2">Project</h3>
          <p className="text-white font-medium">{contract.project.title}</p>
          <p className="text-indigo-300 text-sm mt-1">{contract.project.description}</p>
        </div>
        
        {/* Parties */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <h3 className="text-indigo-300 text-sm mb-2">Client</h3>
            <div className="flex items-center">
              <div className="w-10 h-10 bg-indigo-700 rounded-full flex items-center justify-center mr-3">
                <span className="text-white font-medium">
                  {contract.client.name.charAt(0).toUpperCase()}
                </span>
              </div>
              <div>
                <p className="text-white font-medium">{contract.client.name}</p>
                <p className="text-indigo-300 text-sm">{contract.client.email}</p>
              </div>
            </div>
            
            {contract.clientSignedAt && (
              <div className="mt-2 text-green-400 text-sm flex items-center">
                <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                </svg>
                Signed on {formatDateTime(contract.clientSignedAt)}
              </div>
            )}
          </div>
          
          <div>
            <h3 className="text-indigo-300 text-sm mb-2">Freelancer</h3>
            <div className="flex items-center">
              <div className="w-10 h-10 bg-indigo-700 rounded-full flex items-center justify-center mr-3">
                <span className="text-white font-medium">
                  {contract.freelancer.name.charAt(0).toUpperCase()}
                </span>
              </div>
              <div>
                <p className="text-white font-medium">{contract.freelancer.name}</p>
                <p className="text-indigo-300 text-sm">{contract.freelancer.email}</p>
              </div>
            </div>
            
            {contract.freelancerSignedAt && (
              <div className="mt-2 text-green-400 text-sm flex items-center">
                <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                </svg>
                Signed on {formatDateTime(contract.freelancerSignedAt)}
              </div>
            )}
          </div>
        </div>
        
        {/* Contract Details */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div>
            <h3 className="text-indigo-300 text-sm mb-1">Contract Amount</h3>
            <p className="text-white font-medium">${contract.amount.toFixed(2)}</p>
          </div>
          
          <div>
            <h3 className="text-indigo-300 text-sm mb-1">Start Date</h3>
            <p className="text-white font-medium">{formatDate(contract.startDate)}</p>
          </div>
          
          <div>
            <h3 className="text-indigo-300 text-sm mb-1">End Date</h3>
            <p className="text-white font-medium">{formatDate(contract.endDate)}</p>
          </div>
        </div>
        
        {/* Payment Schedule */}
        <div className="mb-6">
          <h3 className="text-indigo-300 text-sm mb-2">Payment Schedule</h3>
          <p className="text-white font-medium capitalize">
            {contract.paymentSchedule === 'fixed' ? 'Fixed Payment' : 'Milestone-based'}
          </p>
        </div>
        
        {/* Contract Terms */}
        <div className="mb-6">
          <h3 className="text-indigo-300 text-sm mb-2">Contract Terms</h3>
          <div className="bg-gray-900/50 p-4 rounded-md border border-gray-700">
            <p className="text-white whitespace-pre-line">{contract.terms}</p>
          </div>
        </div>
        
        {/* Milestones (if milestone-based) */}
        {contract.paymentSchedule === 'milestone' && contract.milestones && contract.milestones.length > 0 && (
          <div className="mb-6">
            <h3 className="text-indigo-300 text-sm mb-2">Milestones</h3>
            
            <div className="space-y-3">
              {contract.milestones.map((milestone, index) => (
                <div key={milestone._id} className="bg-gray-900/50 p-4 rounded-md border border-gray-700">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="text-white font-medium">{milestone.title}</h4>
                      <p className="text-indigo-300 text-sm mt-1">{milestone.description}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-medium">${milestone.amount.toFixed(2)}</p>
                      <p className="text-indigo-300 text-sm">Due: {formatDate(milestone.dueDate)}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Contract Hash */}
        {contract.contractHash && (
          <div className="mb-6">
            <h3 className="text-indigo-300 text-sm mb-2">Contract Hash (SHA-256)</h3>
            <div className="bg-gray-900/50 p-3 rounded-md border border-gray-700 overflow-x-auto">
              <p className="text-indigo-300 font-mono text-xs">{contract.contractHash}</p>
            </div>
            <p className="mt-1 text-xs text-indigo-300">
              This hash ensures the integrity of the contract. Any changes to the contract will invalidate this hash.
            </p>
          </div>
        )}
        
        {/* Contract History */}
        {contract.history && contract.history.length > 0 && (
          <div>
            <h3 className="text-indigo-300 text-sm mb-2">Contract History</h3>
            
            <div className="space-y-3">
              {contract.history.map((event, index) => (
                <div key={index} className="flex items-start">
                  <div className="flex-shrink-0 w-10 flex justify-center">
                    <div className="h-full flex flex-col items-center">
                      <div className="w-2 h-2 rounded-full bg-indigo-500"></div>
                      {index !== contract.history.length - 1 && (
                        <div className="w-0.5 h-full bg-indigo-500/30 mt-1"></div>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex-1">
                    <p className="text-white">{event.description}</p>
                    <p className="text-indigo-300 text-sm">{formatDateTime(event.timestamp)}</p>
                    {event.ipAddress && (
                      <p className="text-indigo-300 text-xs">IP: {event.ipAddress}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </GlassCard>
    </>
  );
};

export default ContractDetails;
