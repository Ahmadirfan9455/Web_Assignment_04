import React, { createContext, useState, useEffect, useCallback } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from '../hooks/useAuth';
import { toast } from 'react-toastify';
import { SOCKET_URL } from '../services/apiConfig';

// Create socket context
export const SocketContext = createContext();

export const SocketProvider = ({ children }) => {
  const { user, token } = useAuth();
  const [socket, setSocket] = useState(null);
  const [onlineUsers, setOnlineUsers] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [typingUsers, setTypingUsers] = useState({});

  // Connect to socket server
  const connect = useCallback(() => {
    // Disconnect any existing socket first
    if (socket) {
      socket.disconnect();
    }

    // Create socket connection with auth token
    const socketInstance = io(SOCKET_URL, {
      auth: {
        token
      },
      query: {
        token
      },
      transports: ['websocket', 'polling'],
      reconnectionAttempts: 10,
      reconnectionDelay: 1000,
      timeout: 20000,
      autoConnect: true,
      forceNew: true
    });

    // Set socket instance
    setSocket(socketInstance);

    // Socket connection events
    socketInstance.on('connect', () => {
      console.log('Socket connected');
    });

    socketInstance.on('connect_error', (error) => {
      console.error('Socket connection error:', error.message);
      // Don't show toast notification for socket connection errors
      // This prevents the annoying message about real-time services
    });

    // Handle disconnect
    socketInstance.on('disconnect', () => {
      console.log('Socket disconnected');
      // Try to reconnect after a delay
      setTimeout(() => {
        if (socketInstance) {
          socketInstance.connect();
        }
      }, 3000);
    });

    // Handle online users
    socketInstance.on('onlineUsers', (users) => {
      setOnlineUsers(users);
    });

    // Handle notifications
    socketInstance.on('notification', (notification) => {
      // Add notification to state
      setNotifications((prev) => [notification, ...prev]);
      
      // Show toast notification
      toast(notification.message, {
        type: getNotificationToastType(notification.type),
        icon: getNotificationIcon(notification.type)
      });
    });

    // Handle typing indicators
    socketInstance.on('typing', ({ userId, conversationId, isTyping }) => {
      setTypingUsers((prev) => ({
        ...prev,
        [conversationId]: isTyping 
          ? [...(prev[conversationId] || []), userId].filter((id, index, self) => self.indexOf(id) === index)
          : (prev[conversationId] || []).filter(id => id !== userId)
      }));
    });

    // Real-time bid events
    socketInstance.on('bid:new', ({ projectId, bid, freelancerId }) => {
      toast.success('A new bid was submitted!', { icon: '💰' });
      if (typeof window !== 'undefined' && window.dispatchEvent) {
        window.dispatchEvent(new CustomEvent('bid:new', { detail: { projectId, bid, freelancerId } }));
      }
    });
    socketInstance.on('bid:updated', ({ projectId, bid, freelancerId }) => {
      toast.info('A bid was updated.', { icon: '🔄' });
      if (typeof window !== 'undefined' && window.dispatchEvent) {
        window.dispatchEvent(new CustomEvent('bid:updated', { detail: { projectId, bid, freelancerId } }));
      }
    });
    socketInstance.on('bid:accepted', ({ projectId, bid, freelancerId }) => {
      toast.success('A bid was accepted!', { icon: '✅' });
      if (typeof window !== 'undefined' && window.dispatchEvent) {
        window.dispatchEvent(new CustomEvent('bid:accepted', { detail: { projectId, bid, freelancerId } }));
      }
    });
    socketInstance.on('bid:rejected', ({ projectId, bid, freelancerId }) => {
      toast.error('A bid was rejected.', { icon: '❌' });
      if (typeof window !== 'undefined' && window.dispatchEvent) {
        window.dispatchEvent(new CustomEvent('bid:rejected', { detail: { projectId, bid, freelancerId } }));
      }
    });
    socketInstance.on('bid:countered', ({ projectId, bid, freelancerId }) => {
      toast.info('A bid received a counter offer.', { icon: '🤝' });
      if (typeof window !== 'undefined' && window.dispatchEvent) {
        window.dispatchEvent(new CustomEvent('bid:countered', { detail: { projectId, bid, freelancerId } }));
      }
    });

    // Real-time messaging
    socketInstance.on('message:new', (message) => {
      toast.info('New message received!', { icon: '💬' });
      if (typeof window !== 'undefined' && window.dispatchEvent) {
        window.dispatchEvent(new CustomEvent('message:new', { detail: { message } }));
      }
    });

    // Handle project updates
    socketInstance.on('projectUpdate', ({ project, updateType }) => {
      // Show toast notification for project updates
      const messages = {
        'status': `Project status updated to: ${project.status}`,
        'milestone': 'Project milestone updated',
        'payment': 'Project payment processed',
        'message': 'New project message received'
      };
      
      toast.info(messages[updateType] || 'Project updated', {
        icon: '📋'
      });
    });

    // Handle contract updates
    socketInstance.on('contractUpdate', ({ contract, updateType }) => {
      // Show toast notification for contract updates
      const messages = {
        'created': 'New contract created',
        'signed': 'Contract has been signed',
        'updated': 'Contract has been updated',
        'completed': 'Contract has been completed'
      };
      
      toast.info(messages[updateType] || 'Contract updated', {
        icon: '📝'
      });
    });

    return () => {
      socketInstance.disconnect();
    };
  }, [user, token]);

  // Disconnect from socket server
  const disconnect = useCallback(() => {
    if (socket) {
      socket.disconnect();
      setSocket(null);
    }
  }, [socket]);

  // Send typing indicator
  const sendTypingIndicator = useCallback((conversationId, isTyping) => {
    if (socket) {
      socket.emit('typing', { conversationId, isTyping });
    }
  }, [socket]);

  // Mark notification as read
  const markNotificationAsRead = useCallback((notificationId) => {
    if (socket) {
      socket.emit('markNotificationAsRead', { notificationId });
      
      // Update local state
      setNotifications((prev) => 
        prev.map((notification) => 
          notification._id === notificationId 
            ? { ...notification, read: true } 
            : notification
        )
      );
    }
  }, [socket]);

  // Clear notifications
  const clearNotifications = useCallback(() => {
    if (socket) {
      socket.emit('clearNotifications');
      setNotifications([]);
    }
  }, [socket]);

  // Helper function to get notification toast type
  const getNotificationToastType = (type) => {
    const types = {
      'message': 'info',
      'bid': 'success',
      'project': 'info',
      'contract': 'info',
      'payment': 'success',
      'system': 'default',
      'warning': 'warning',
      'error': 'error'
    };
    
    return types[type] || 'default';
  };

  // Helper function to get notification icon
  const getNotificationIcon = (type) => {
    const icons = {
      'message': '💬',
      'bid': '💰',
      'project': '📋',
      'contract': '📝',
      'payment': '💵',
      'system': '🔔',
      'warning': '⚠️',
      'error': '❌'
    };
    
    return icons[type] || '🔔';
  };

  // Connect to socket when user is authenticated
  useEffect(() => {
    if (user && !socket) {
      connect();
    }
    
    // Disconnect when user logs out
    if (!user && socket) {
      disconnect();
    }
    
    // Cleanup on unmount
    return () => {
      if (socket) {
        disconnect();
      }
    };
  }, [user, socket, connect, disconnect]);

  return (
    <SocketContext.Provider
      value={{
        socket,
        onlineUsers,
        notifications,
        typingUsers,
        connect,
        disconnect,
        sendTypingIndicator,
        markNotificationAsRead,
        clearNotifications,
        isOnline: (userId) => onlineUsers.includes(userId),
        isTyping: (userId, conversationId) => typingUsers[conversationId]?.includes(userId) || false,
      }}
    >
      {children}
    </SocketContext.Provider>
  );
};

export default SocketContext;
