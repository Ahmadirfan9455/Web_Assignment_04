import React, { createContext, useState, useEffect } from 'react';
import { jwtDecode } from 'jwt-decode';
import axios from 'axios';
import { toast } from 'react-toastify';
import * as authService from '../services/authService';

// Create auth context
export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [token, setToken] = useState(localStorage.getItem('token'));

  // Initialize auth state
  useEffect(() => {
    const initializeAuth = async () => {
      if (token) {
        try {
          // Set default axios auth header
          axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
          
          // Decode token to get user info
          const decoded = jwtDecode(token);
          
          // Check if token is expired
          if (decoded.exp * 1000 < Date.now()) {
            // Token expired, logout user
            logout();
            toast.error('Your session has expired. Please login again.');
          } else {
            try {
              // Get user data from API
              const response = await axios.get('/api/auth/me');
              setUser(response.data);
            } catch (apiError) {
              // Handle API error gracefully - use decoded data as fallback
              console.warn('Could not fetch user data from API, using token data as fallback');
              setUser({
                _id: decoded.id || decoded._id,
                name: decoded.name,
                email: decoded.email,
                role: decoded.role
              });
            }
          }
        } catch (error) {
          console.error('Authentication error:', error);
          logout();
          toast.error('Authentication failed. Please login again.');
        }
      }
      
      setIsLoading(false);
    };

    initializeAuth();
  }, [token]);

  // Login function
  const login = async (email, password) => {
    setIsLoading(true);
    
    try {
      // Use the authService instead of direct axios call
      const data = await authService.login({ email, password });
      
      // Set token in localStorage
      localStorage.setItem('token', data.token);
      setToken(data.token);
      
      // Set default axios auth header
      axios.defaults.headers.common['Authorization'] = `Bearer ${data.token}`;
      
      // Set user in state
      setUser({
        _id: data._id,
        name: data.name,
        email: data.email,
        role: data.role,
      });
      
      toast.success('Login successful!');
      return data;
    } catch (error) {
      console.error('Login error:', error);
      
      // Provide user-friendly error messages
      if (error.userMessage) {
        toast.error(error.userMessage);
      } else if (error.response) {
        // Server responded with an error
        const errorMessage = error.response.data?.message || 'Login failed. Please check your credentials.';
        toast.error(errorMessage);
      } else if (error.code === 'ERR_NETWORK') {
        toast.error('Cannot connect to server. Please check your internet connection or try again later.');
      } else {
        toast.error('Login failed. Please try again.');
      }
      
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Register function
  const register = async (userData) => {
    setIsLoading(true);
    
    try {
      // Use the authService instead of direct axios call
      const data = await authService.register(userData);
      const { message } = data;
      
      toast.success(message || 'Registration successful! Please verify your email.');
      return data;
    } catch (error) {
      console.error('Registration error:', error);
      const errorMessage = error.response?.data?.message || 'Registration failed. Please try again.';
      toast.error(errorMessage);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Logout function
  const logout = () => {
    // Remove token from localStorage
    localStorage.removeItem('token');
    
    // Remove token from axios headers
    delete axios.defaults.headers.common['Authorization'];
    
    // Clear user and token from state
    setUser(null);
    setToken(null);
    
    toast.info('You have been logged out.');
  };

  // Update user profile
  const updateUser = async (profileData) => {
    try {
      setIsLoading(true);
      
      // Get current token
      const currentToken = localStorage.getItem('token');
      if (!currentToken) {
        toast.error('You must be logged in to update your profile');
        return false;
      }
      
      // Call API to update user profile
      const response = await axios.put('/api/auth/profile', profileData);
      
      if (response.data) {
        // Update user in state with the returned data
        setUser(prev => ({
          ...prev,
          ...response.data,
          // Preserve role if not returned in the response
          role: response.data.role || prev.role
        }));
        
        toast.success('Profile updated successfully');
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Error updating user profile:', error);
      toast.error(error.response?.data?.message || 'Failed to update profile. Please try again.');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  // Verify email function
  const verifyEmail = async (token) => {
    setIsLoading(true);
    
    try {
      // Use the authService instead of direct axios call
      const data = await authService.verifyEmail(token);
      toast.success('Email verified successfully! You can now login.');
      return data;
    } catch (error) {
      console.error('Email verification error:', error);
      const errorMessage = error.response?.data?.message || 'Email verification failed. Please try again.';
      toast.error(errorMessage);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Reset password request function
  const requestPasswordReset = async (email) => {
    setIsLoading(true);
    
    try {
      const response = await axios.post('/api/auth/forgot-password', { email });
      toast.success('Password reset link sent to your email!');
      return response.data;
    } catch (error) {
      console.error('Password reset request error:', error);
      const errorMessage = error.response?.data?.message || 'Failed to request password reset. Please try again.';
      toast.error(errorMessage);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Reset password function
  const resetPassword = async (token, password) => {
    setIsLoading(true);
    
    try {
      const response = await axios.post(`/api/auth/reset-password/${token}`, { password });
      toast.success('Password reset successful! You can now login with your new password.');
      return response.data;
    } catch (error) {
      console.error('Password reset error:', error);
      const errorMessage = error.response?.data?.message || 'Failed to reset password. Please try again.';
      toast.error(errorMessage);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Update user role
  const updateUserRole = async (newRole) => {
    try {
      setIsLoading(true);
      
      // Get current token
      const currentToken = localStorage.getItem('token');
      if (!currentToken) {
        toast.error('You must be logged in to update your role');
        return false;
      }
      
      // Call API to update user role
      const response = await axios.put('/api/auth/update-role', { role: newRole });
      
      if (response.data.success) {
        // Update user in state
        setUser(prev => ({ ...prev, role: newRole }));
        
        // If a new token is returned, update it
        if (response.data.token) {
          localStorage.setItem('token', response.data.token);
          setToken(response.data.token);
          axios.defaults.headers.common['Authorization'] = `Bearer ${response.data.token}`;
        }
        
        toast.success(`Your role has been updated to ${newRole}`);
        
        // Force refresh user data from server
        try {
          const userResponse = await axios.get('/api/auth/me');
          if (userResponse.data) {
            setUser(userResponse.data);
          }
        } catch (refreshError) {
          console.error('Error refreshing user data:', refreshError);
          // Continue even if refresh fails
        }
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Error updating user role:', error);
      toast.error(error.response?.data?.message || 'Failed to update role. Please try again.');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isLoading,
        login,
        register,
        logout,
        updateUser,
        verifyEmail,
        requestPasswordReset,
        resetPassword,
        updateUserRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
