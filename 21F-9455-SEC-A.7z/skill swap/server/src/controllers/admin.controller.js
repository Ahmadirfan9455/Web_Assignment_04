import { User, Freelancer, Client } from '../models/user.model.js';
import Project from '../models/project.model.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import { sendVerificationNotification } from '../services/notification.service.js';

/**
 * @desc    Get all freelancers pending verification
 * @route   GET /api/admin/freelancers/pending
 * @access  Private (Admin only)
 */
export const getPendingFreelancers = asyncHandler(async (req, res) => {
  const freelancers = await Freelancer.find({ verified: false })
    .populate({
      path: 'user',
      select: 'name email isVerified',
    });

  res.json(freelancers);
});

/**
 * @desc    Verify a freelancer
 * @route   PUT /api/admin/freelancers/:id/verify
 * @access  Private (Admin only)
 */
export const verifyFreelancer = asyncHandler(async (req, res) => {
  const { verificationLevel } = req.body;
  const freelancerId = req.params.id;

  const freelancer = await Freelancer.findById(freelancerId);

  if (!freelancer) {
    res.status(404);
    throw new Error('Freelancer not found');
  }

  // Update verification status
  freelancer.verified = true;
  freelancer.verificationLevel = verificationLevel || 'Verified';
  await freelancer.save();

  // Send notification to freelancer
  await sendVerificationNotification(
    freelancer.user,
    'freelancer',
    'approved'
  );

  res.json({
    message: 'Freelancer verified successfully',
    freelancer,
  });
});

/**
 * @desc    Reject a freelancer verification
 * @route   PUT /api/admin/freelancers/:id/reject
 * @access  Private (Admin only)
 */
export const rejectFreelancer = asyncHandler(async (req, res) => {
  const { reason } = req.body;
  const freelancerId = req.params.id;

  const freelancer = await Freelancer.findById(freelancerId);

  if (!freelancer) {
    res.status(404);
    throw new Error('Freelancer not found');
  }

  // Update verification status
  freelancer.verified = false;
  freelancer.verificationLevel = 'Basic';
  await freelancer.save();

  // Send notification to freelancer
  await sendVerificationNotification(
    freelancer.user,
    'freelancer',
    'rejected',
    reason
  );

  res.json({
    message: 'Freelancer verification rejected',
    freelancer,
  });
});

/**
 * @desc    Get platform analytics
 * @route   GET /api/admin/analytics
 * @access  Private (Admin only)
 */
export const getPlatformAnalytics = asyncHandler(async (req, res) => {
  // Get user counts
  const totalUsers = await User.countDocuments();
  const clientCount = await User.countDocuments({ role: 'client' });
  const freelancerCount = await User.countDocuments({ role: 'freelancer' });
  const verifiedFreelancers = await Freelancer.countDocuments({ verified: true });

  // Get project counts
  const totalProjects = await Project.countDocuments();
  const openProjects = await Project.countDocuments({ status: 'open' });
  const inProgressProjects = await Project.countDocuments({ status: 'in-progress' });
  const completedProjects = await Project.countDocuments({ status: 'completed' });

  // Get bid analytics
  const projects = await Project.find();
  const totalBids = projects.reduce((sum, project) => sum + project.bids.length, 0);
  const avgBidsPerProject = totalProjects > 0 ? totalBids / totalProjects : 0;

  // Get user growth (last 6 months)
  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

  const userGrowth = await User.aggregate([
    {
      $match: {
        createdAt: { $gte: sixMonthsAgo },
      },
    },
    {
      $group: {
        _id: {
          month: { $month: '$createdAt' },
          year: { $year: '$createdAt' },
        },
        count: { $sum: 1 },
      },
    },
    {
      $sort: {
        '_id.year': 1,
        '_id.month': 1,
      },
    },
  ]);

  // Get popular skills
  const freelancers = await Freelancer.find();
  const skillsCount = {};

  freelancers.forEach((freelancer) => {
    freelancer.skills.forEach((skill) => {
      skillsCount[skill] = (skillsCount[skill] || 0) + 1;
    });
  });

  const popularSkills = Object.entries(skillsCount)
    .map(([skill, count]) => ({ skill, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  res.json({
    users: {
      total: totalUsers,
      clients: clientCount,
      freelancers: freelancerCount,
      verifiedFreelancers,
      growth: userGrowth,
    },
    projects: {
      total: totalProjects,
      open: openProjects,
      inProgress: inProgressProjects,
      completed: completedProjects,
    },
    bids: {
      total: totalBids,
      avgPerProject: avgBidsPerProject,
    },
    skills: popularSkills,
  });
});

/**
 * @desc    Get document verification requests
 * @route   GET /api/admin/documents
 * @access  Private (Admin only)
 */
export const getDocumentVerifications = asyncHandler(async (req, res) => {
  const freelancers = await Freelancer.find({
    verificationDocuments: { $exists: true, $ne: [] },
    verified: false,
  }).populate({
    path: 'user',
    select: 'name email',
  });

  res.json(freelancers);
});

/**
 * @desc    Verify document
 * @route   PUT /api/admin/documents/:id/verify
 * @access  Private (Admin only)
 */
export const verifyDocument = asyncHandler(async (req, res) => {
  const freelancerId = req.params.id;

  const freelancer = await Freelancer.findById(freelancerId);

  if (!freelancer) {
    res.status(404);
    throw new Error('Freelancer not found');
  }

  // Update document verification status
  freelancer.verified = true;
  await freelancer.save();

  // Send notification to freelancer
  await sendVerificationNotification(
    freelancer.user,
    'document',
    'approved'
  );

  res.json({
    message: 'Document verified successfully',
    freelancer,
  });
});

/**
 * @desc    Get all users with pagination and filtering
 * @route   GET /api/admin/users
 * @access  Private/Admin
 */
export const getAllUsers = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const skip = (page - 1) * limit;
  
  // Filtering
  const filter = {};
  if (req.query.role && req.query.role !== 'all') filter.role = req.query.role;
  if (req.query.status && req.query.status !== 'all') filter.status = req.query.status;
  if (req.query.isVerified === 'true') filter.isVerified = true;
  if (req.query.isVerified === 'false') filter.isVerified = false;
  
  if (req.query.search) {
    filter.$or = [
      { name: { $regex: req.query.search, $options: 'i' } },
      { email: { $regex: req.query.search, $options: 'i' } },
    ];
  }
  
  // Sorting
  const sortField = req.query.sortBy || 'createdAt';
  const sortOrder = req.query.sortOrder === 'asc' ? 1 : -1;
  const sort = { [sortField]: sortOrder };
  
  try {
    // Execute query
    const users = await User.find(filter)
      .select('-password')
      .sort(sort)
      .skip(skip)
      .limit(limit);
    
    // Get total count for pagination
    const total = await User.countDocuments(filter);
    
    res.json({
      users,
      totalUsers: total,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      limit
    });
  } catch (error) {
    console.error('Error in getAllUsers:', error);
    res.status(500).json({
      message: 'Failed to fetch users',
      error: error.message
    });
  }
});

/**
 * @desc    Get user by ID
 * @route   GET /api/admin/users/:id
 * @access  Private/Admin
 */
export const getUserById = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id).select('-password');
  
  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }
  
  // Get role-specific profile data
  let profileData = null;
  if (user.role === 'freelancer') {
    profileData = await Freelancer.findOne({ user: user._id });
  } else if (user.role === 'client') {
    profileData = await Client.findOne({ user: user._id });
  }
  
  res.json({
    ...user._doc,
    profileData,
  });
});

/**
 * @desc    Update user status (active/inactive/banned)
 * @route   PUT /api/admin/users/:id/status
 * @access  Private/Admin
 */
export const updateUserStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;
  
  if (!['active', 'inactive', 'banned'].includes(status)) {
    res.status(400);
    throw new Error('Invalid status value');
  }
  
  const user = await User.findById(req.params.id);
  
  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }
  
  // Update user status
  user.status = status;
  
  // If setting to active, also verify the user if not already verified
  if (status === 'active' && !user.isVerified) {
    user.isVerified = true;
  }
  
  await user.save();
  
  // Send notification if appropriate
  if (status === 'active' && user.role === 'freelancer') {
    try {
      // Find or create freelancer profile if needed
      let freelancer = await Freelancer.findOne({ user: user._id });
      if (!freelancer) {
        freelancer = await Freelancer.create({ user: user._id });
      }
      
      // Send notification
      await sendVerificationNotification(user.email, user.name);
    } catch (error) {
      console.error('Error sending verification notification:', error);
      // Continue even if notification fails
    }
  }
  
  res.json({
    success: true,
    message: `User status updated to ${status}`,
    user: {
      ...user._doc,
      password: undefined
    }
  });
});

/**
 * @desc    Delete user
 * @route   DELETE /api/admin/users/:id
 * @access  Private/Admin
 */
export const deleteUser = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  
  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }
  
  // Don't allow deleting other admins
  if (user.role === 'admin' && user._id.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Cannot delete another admin user');
  }
  
  await user.remove();
  
  res.json({
    message: 'User deleted successfully',
  });
});
