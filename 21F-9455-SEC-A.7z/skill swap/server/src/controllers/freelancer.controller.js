import { Freelancer } from '../models/user.model.js';
import { asyncHandler } from '../middleware/errorHandler.js';

/**
 * @desc    Search freelancers with filtering
 * @route   GET /api/freelancers/search
 * @access  Public
 */
export const searchFreelancers = asyncHandler(async (req, res) => {
  const {
    skills,
    minRating,
    verified,
    minRate,
    maxRate,
    page = 1,
    limit = 12,
    sort = 'rating',
    order = 'desc',
  } = req.query;

  const query = {};

  // Skills filter (array or comma-separated string)
  if (skills) {
    const skillsArray = Array.isArray(skills)
      ? skills
      : skills.split(',').map(s => s.trim());
    query.skills = { $all: skillsArray };
  }

  // Rating filter
  if (minRating) {
    query.rating = { $gte: Number(minRating) };
  }

  // Verification filter
  if (verified !== undefined) {
    query.verified = verified === 'true';
  }

  // Hourly rate filter
  if (minRate || maxRate) {
    query.hourlyRate = {};
    if (minRate) query.hourlyRate.$gte = Number(minRate);
    if (maxRate) query.hourlyRate.$lte = Number(maxRate);
  }

  // Pagination & sorting
  const skip = (Number(page) - 1) * Number(limit);
  const sortObj = {};
  sortObj[sort] = order === 'asc' ? 1 : -1;

  // Query freelancers
  const [total, freelancers] = await Promise.all([
    Freelancer.countDocuments(query),
    Freelancer.find(query)
      .sort(sortObj)
      .skip(skip)
      .limit(Number(limit))
      .populate('user', 'name email isVerified'),
  ]);

  res.json({
    total,
    page: Number(page),
    limit: Number(limit),
    freelancers,
  });
});
