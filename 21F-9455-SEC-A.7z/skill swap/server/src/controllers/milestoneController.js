import Milestone from '../models/Milestone.js';
import Project from '../models/project.model.js';
import mongoose from 'mongoose';
import { catchAsync } from '../utils/errorHandlers.js';
import AppError from '../utils/appError.js';

/**
 * Get all milestones with filtering and pagination
 * @route GET /api/admin/milestones
 * @access Private (Admin)
 */
const getMilestones = catchAsync(async (req, res) => {
  const { 
    page = 1, 
    limit = 10, 
    project, 
    status, 
    sortBy = 'dueDate',
    sortOrder = 'asc'
  } = req.query;
  
  // Build filter object
  const filter = {};
  
  if (project && project !== 'all') {
    filter.project = mongoose.Types.ObjectId(project);
  }
  
  if (status && status !== 'all') {
    filter.status = status;
  }
  
  // Build sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'asc' ? 1 : -1;
  
  // Calculate pagination
  const skip = (parseInt(page) - 1) * parseInt(limit);
  
  // Execute query with pagination
  const milestones = await Milestone.find(filter)
    .sort(sort)
    .skip(skip)
    .limit(parseInt(limit))
    .populate('project', 'title client')
    .populate({
      path: 'statusHistory.updatedBy',
      select: 'name email role'
    });
  
  // Get total count for pagination
  const total = await Milestone.countDocuments(filter);
  
  // Calculate total pages
  const totalPages = Math.ceil(total / parseInt(limit));
  
  res.status(200).json({
    status: 'success',
    results: milestones.length,
    page: parseInt(page),
    limit: parseInt(limit),
    total,
    totalPages,
    milestones
  });
});

/**
 * Get milestone by ID
 * @route GET /api/admin/milestones/:id
 * @access Private (Admin)
 */
const getMilestoneById = catchAsync(async (req, res, next) => {
  const milestone = await Milestone.findById(req.params.id)
    .populate('project', 'title client')
    .populate({
      path: 'statusHistory.updatedBy',
      select: 'name email role'
    });
  
  if (!milestone) {
    return next(new AppError('Milestone not found', 404));
  }
  
  res.status(200).json({
    status: 'success',
    milestone
  });
});

/**
 * Update milestone status
 * @route PATCH /api/admin/milestones/:id/status
 * @access Private (Admin)
 */
const updateMilestoneStatus = catchAsync(async (req, res, next) => {
  const { status, note } = req.body;
  
  // Validate status
  const validStatuses = ['not_started', 'in_progress', 'completed', 'approved', 'rejected'];
  if (!validStatuses.includes(status)) {
    return next(new AppError('Invalid status value', 400));
  }
  
  // Find milestone
  const milestone = await Milestone.findById(req.params.id);
  
  if (!milestone) {
    return next(new AppError('Milestone not found', 404));
  }
  
  // Validate status transition
  const validTransitions = {
    'not_started': ['in_progress'],
    'in_progress': ['completed', 'not_started'],
    'completed': ['approved', 'rejected', 'in_progress'],
    'rejected': ['in_progress'],
    'approved': [] // Cannot change status once approved
  };
  
  if (milestone.status === 'approved') {
    return next(new AppError('Cannot change status of an approved milestone', 400));
  }
  
  if (!validTransitions[milestone.status].includes(status)) {
    return next(new AppError(`Cannot transition from ${milestone.status} to ${status}`, 400));
  }
  
  // Update milestone
  milestone.status = status;
  
  // Add to status history
  milestone.statusHistory.push({
    status,
    note: note || `Milestone status updated to ${status}`,
    updatedBy: req.user._id,
    date: new Date()
  });
  
  await milestone.save();
  
  // Emit socket event for real-time updates
  if (req.io) {
    // Notify project stakeholders
    req.io.to(`project_${milestone.project}`).emit('milestone:statusUpdated', {
      milestoneId: milestone._id,
      status,
      projectId: milestone.project
    });
  }
  
  res.status(200).json({
    status: 'success',
    message: 'Milestone status updated successfully',
    milestone
  });
});

/**
 * Get milestone statistics
 * @route GET /api/admin/milestones/stats
 * @access Private (Admin)
 */
const getMilestoneStats = catchAsync(async (req, res) => {
  // Get counts by status
  const statusCounts = await Milestone.aggregate([
    {
      $group: {
        _id: '$status',
        count: { $sum: 1 }
      }
    }
  ]);
  
  // Get upcoming milestones (due in the next 7 days)
  const now = new Date();
  const nextWeek = new Date(now);
  nextWeek.setDate(now.getDate() + 7);
  
  const upcomingMilestones = await Milestone.countDocuments({
    dueDate: { $gte: now, $lte: nextWeek },
    status: { $nin: ['approved', 'rejected'] }
  });
  
  // Get overdue milestones
  const overdueMilestones = await Milestone.countDocuments({
    dueDate: { $lt: now },
    status: { $nin: ['approved', 'rejected'] }
  });
  
  // Get total milestone value by status
  const valueByStatus = await Milestone.aggregate([
    {
      $group: {
        _id: '$status',
        totalValue: { $sum: '$amount' }
      }
    }
  ]);
  
  res.status(200).json({
    status: 'success',
    stats: {
      statusCounts: statusCounts.reduce((obj, item) => {
        obj[item._id] = item.count;
        return obj;
      }, {}),
      upcomingMilestones,
      overdueMilestones,
      valueByStatus: valueByStatus.reduce((obj, item) => {
        obj[item._id] = item.totalValue;
        return obj;
      }, {})
    }
  });
});

/**
 * Get projects for filtering
 * @route GET /api/admin/projects
 * @access Private (Admin)
 */
const getProjects = catchAsync(async (req, res) => {
  const projects = await Project.find()
    .select('_id title client status')
    .sort({ createdAt: -1 });
  
  res.status(200).json({
    status: 'success',
    results: projects.length,
    projects
  });
});

export {
  getMilestones,
  getMilestoneById,
  updateMilestoneStatus,
  getMilestoneStats,
  getProjects
};
