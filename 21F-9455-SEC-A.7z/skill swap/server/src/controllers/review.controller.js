/**
 * Review Controller
 * 
 * Handles review and rating functionality for freelancers:
 * - Creating reviews
 * - Getting reviews for a freelancer
 * - Responding to reviews
 * - Filtering and sorting reviews
 */

import Review from '../models/review.model.js';
import Project from '../models/project.model.js';
import { Freelancer } from '../models/user.model.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import { emitToUser } from '../services/socket.service.js';

/**
 * @desc    Create a review for a freelancer
 * @route   POST /api/reviews/:projectId
 * @access  Private (Client only - project owner)
 */
export const createReview = asyncHandler(async (req, res) => {
  const { rating, comment } = req.body;
  const projectId = req.params.projectId;

  // Find project
  const project = await Project.findById(projectId);

  if (!project) {
    res.status(404);
    throw new Error('Project not found');
  }

  // Check if user is project owner
  if (project.client.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to review this project');
  }

  // Check if project is completed
  if (project.status !== 'completed') {
    res.status(400);
    throw new Error('Cannot review a project that is not completed');
  }

  // Check if freelancer is assigned to project
  if (!project.assignedFreelancer) {
    res.status(400);
    throw new Error('No freelancer assigned to this project');
  }

  // Check if review already exists
  const existingReview = await Review.findOne({
    project: projectId,
    client: req.user._id,
  });

  if (existingReview) {
    res.status(400);
    throw new Error('You have already reviewed this project');
  }

  // Create review
  const review = await Review.create({
    project: projectId,
    client: req.user._id,
    freelancer: project.assignedFreelancer,
    rating,
    comment,
  });

  // Update freelancer's average rating
  const freelancer = await Freelancer.findOne({ user: project.assignedFreelancer });
  
  if (freelancer) {
    // Get all reviews for this freelancer
    const reviews = await Review.find({ freelancer: project.assignedFreelancer });
    
    // Calculate average rating
    const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0);
    const avgRating = reviews.length > 0 ? totalRating / reviews.length : 0;
    
    // Update freelancer's rating
    freelancer.rating = avgRating;
    await freelancer.save();
  }

  // Notify freelancer of new review via Socket.io
  emitToUser(project.assignedFreelancer.toString(), 'newReview', {
    reviewId: review._id,
    projectId,
    clientId: req.user._id,
    rating,
  });

  res.status(201).json(review);
});

/**
 * @desc    Get all reviews for a freelancer
 * @route   GET /api/reviews/freelancer/:freelancerId
 * @access  Public
 */
export const getFreelancerReviews = asyncHandler(async (req, res) => {
  const freelancerId = req.params.freelancerId;

  // Build filter object
  const filter = { freelancer: freelancerId };
  
  // Filter by rating
  if (req.query.rating) {
    filter.rating = Number(req.query.rating);
  }

  // Sort options
  let sort = {};
  
  if (req.query.sort === 'latest') {
    sort = { createdAt: -1 };
  } else if (req.query.sort === 'oldest') {
    sort = { createdAt: 1 };
  } else if (req.query.sort === 'highest') {
    sort = { rating: -1 };
  } else if (req.query.sort === 'lowest') {
    sort = { rating: 1 };
  } else {
    // Default sort by latest
    sort = { createdAt: -1 };
  }

  // Pagination
  const page = Number(req.query.page) || 1;
  const limit = Number(req.query.limit) || 10;
  const skip = (page - 1) * limit;

  // Get reviews
  const reviews = await Review.find(filter)
    .populate('client', 'name email profileImage')
    .populate('project', 'title')
    .sort(sort)
    .skip(skip)
    .limit(limit);

  // Get total count for pagination
  const count = await Review.countDocuments(filter);

  // Calculate average rating
  const avgRating = await Review.aggregate([
    { $match: { freelancer: freelancerId } },
    { $group: { _id: null, avg: { $avg: '$rating' } } },
  ]);

  // Count reviews by rating (1-5 stars)
  const ratingCounts = await Review.aggregate([
    { $match: { freelancer: freelancerId } },
    { $group: { _id: '$rating', count: { $sum: 1 } } },
  ]);

  // Format rating counts
  const ratingStats = {
    1: 0,
    2: 0,
    3: 0,
    4: 0,
    5: 0,
  };

  ratingCounts.forEach((item) => {
    ratingStats[item._id] = item.count;
  });

  res.json({
    reviews,
    page,
    pages: Math.ceil(count / limit),
    total: count,
    avgRating: avgRating.length > 0 ? avgRating[0].avg : 0,
    ratingStats,
  });
});

/**
 * @desc    Get review by ID
 * @route   GET /api/reviews/:id
 * @access  Public
 */
export const getReviewById = asyncHandler(async (req, res) => {
  const review = await Review.findById(req.params.id)
    .populate('client', 'name email profileImage')
    .populate('freelancer', 'name email profileImage')
    .populate('project', 'title');

  if (!review) {
    res.status(404);
    throw new Error('Review not found');
  }

  res.json(review);
});

/**
 * @desc    Respond to a review
 * @route   PUT /api/reviews/:id/respond
 * @access  Private (Freelancer only - review recipient)
 */
export const respondToReview = asyncHandler(async (req, res) => {
  const { response } = req.body;
  const reviewId = req.params.id;

  // Find review
  const review = await Review.findById(reviewId);

  if (!review) {
    res.status(404);
    throw new Error('Review not found');
  }

  // Check if user is the freelancer who received the review
  if (review.freelancer.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to respond to this review');
  }

  // Update review with response
  review.response = response;
  await review.save();

  // Notify client of response via Socket.io
  emitToUser(review.client.toString(), 'reviewResponse', {
    reviewId: review._id,
    freelancerId: req.user._id,
    response,
  });

  res.json(review);
});

/**
 * @desc    Get reviews for a project
 * @route   GET /api/reviews/project/:projectId
 * @access  Private (Project participants only)
 */
export const getProjectReviews = asyncHandler(async (req, res) => {
  const projectId = req.params.projectId;

  // Find project
  const project = await Project.findById(projectId);

  if (!project) {
    res.status(404);
    throw new Error('Project not found');
  }

  // Check if user is project owner or assigned freelancer
  const isAuthorized = 
    project.client.toString() === req.user._id.toString() ||
    (project.assignedFreelancer && project.assignedFreelancer.toString() === req.user._id.toString());

  if (!isAuthorized) {
    res.status(403);
    throw new Error('Not authorized to view reviews for this project');
  }

  // Get reviews for project
  const reviews = await Review.find({ project: projectId })
    .populate('client', 'name email profileImage')
    .populate('freelancer', 'name email profileImage');

  res.json(reviews);
});
