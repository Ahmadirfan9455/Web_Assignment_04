import TimeEntry from '../models/TimeEntry.js';
import Project from '../models/project.model.js';
import { User } from '../models/user.model.js';
import mongoose from 'mongoose';
import { catchAsync } from '../utils/errorHandlers.js';
import AppError from '../utils/appError.js';

/**
 * Get all time entries with filtering and pagination
 * @route GET /api/admin/time-entries
 * @access Private (Admin)
 */
const getTimeEntries = catchAsync(async (req, res) => {
  const { 
    page = 1, 
    limit = 10, 
    project, 
    freelancer, 
    status, 
    startDate, 
    endDate,
    sortBy = 'createdAt',
    sortOrder = 'desc'
  } = req.query;
  
  // Build filter object
  const filter = {};
  
  if (project && project !== 'all') {
    filter.project = mongoose.Types.ObjectId(project);
  }
  
  if (freelancer && freelancer !== 'all') {
    filter.freelancer = mongoose.Types.ObjectId(freelancer);
  }
  
  if (status && status !== 'all') {
    filter.status = status;
  }
  
  // Date range filter
  if (startDate && endDate) {
    filter.date = {
      $gte: new Date(startDate),
      $lte: new Date(endDate)
    };
  } else if (startDate) {
    filter.date = { $gte: new Date(startDate) };
  } else if (endDate) {
    filter.date = { $lte: new Date(endDate) };
  }
  
  // Build sort object
  const sort = {};
  sort[sortBy] = sortOrder === 'asc' ? 1 : -1;
  
  // Calculate pagination
  const skip = (parseInt(page) - 1) * parseInt(limit);
  
  // Execute query with pagination
  const timeEntries = await TimeEntry.find(filter)
    .sort(sort)
    .skip(skip)
    .limit(parseInt(limit))
    .populate('project', 'title client')
    .populate('freelancer', 'name email profileImage')
    .populate({
      path: 'statusHistory.updatedBy',
      select: 'name email role'
    });
  
  // Get total count for pagination
  const total = await TimeEntry.countDocuments(filter);
  
  // Calculate total pages
  const totalPages = Math.ceil(total / parseInt(limit));
  
  res.status(200).json({
    status: 'success',
    results: timeEntries.length,
    page: parseInt(page),
    limit: parseInt(limit),
    total,
    totalPages,
    timeEntries
  });
});

/**
 * Get time entry by ID
 * @route GET /api/admin/time-entries/:id
 * @access Private (Admin)
 */
const getTimeEntryById = catchAsync(async (req, res, next) => {
  const timeEntry = await TimeEntry.findById(req.params.id)
    .populate('project', 'title client')
    .populate('freelancer', 'name email profileImage')
    .populate({
      path: 'statusHistory.updatedBy',
      select: 'name email role'
    });
  
  if (!timeEntry) {
    return next(new AppError('Time entry not found', 404));
  }
  
  res.status(200).json({
    status: 'success',
    timeEntry
  });
});

/**
 * Approve time entry
 * @route PATCH /api/admin/time-entries/:id/approve
 * @access Private (Admin)
 */
const approveTimeEntry = catchAsync(async (req, res, next) => {
  const { note } = req.body;
  
  // Find time entry
  const timeEntry = await TimeEntry.findById(req.params.id);
  
  if (!timeEntry) {
    return next(new AppError('Time entry not found', 404));
  }
  
  // Check if already approved
  if (timeEntry.status === 'approved') {
    return next(new AppError('Time entry is already approved', 400));
  }
  
  // Update time entry
  timeEntry.status = 'approved';
  
  // Add to status history
  timeEntry.statusHistory.push({
    status: 'approved',
    note: note || 'Time entry approved by admin',
    updatedBy: req.user._id,
    date: new Date()
  });
  
  await timeEntry.save();
  
  // Emit socket event for real-time updates
  if (req.io) {
    req.io.to(`user_${timeEntry.freelancer}`).emit('timeEntry:statusUpdated', {
      timeEntryId: timeEntry._id,
      status: 'approved'
    });
  }
  
  res.status(200).json({
    status: 'success',
    message: 'Time entry approved successfully',
    timeEntry
  });
});

/**
 * Reject time entry
 * @route PATCH /api/admin/time-entries/:id/reject
 * @access Private (Admin)
 */
const rejectTimeEntry = catchAsync(async (req, res, next) => {
  const { note, rejectionReason } = req.body;
  
  if (!rejectionReason) {
    return next(new AppError('Rejection reason is required', 400));
  }
  
  // Find time entry
  const timeEntry = await TimeEntry.findById(req.params.id);
  
  if (!timeEntry) {
    return next(new AppError('Time entry not found', 404));
  }
  
  // Check if already rejected
  if (timeEntry.status === 'rejected') {
    return next(new AppError('Time entry is already rejected', 400));
  }
  
  // Update time entry
  timeEntry.status = 'rejected';
  timeEntry.rejectionReason = rejectionReason;
  
  // Add to status history
  timeEntry.statusHistory.push({
    status: 'rejected',
    note: note || rejectionReason,
    updatedBy: req.user._id,
    date: new Date()
  });
  
  await timeEntry.save();
  
  // Emit socket event for real-time updates
  if (req.io) {
    req.io.to(`user_${timeEntry.freelancer}`).emit('timeEntry:statusUpdated', {
      timeEntryId: timeEntry._id,
      status: 'rejected',
      rejectionReason
    });
  }
  
  res.status(200).json({
    status: 'success',
    message: 'Time entry rejected successfully',
    timeEntry
  });
});

/**
 * Get time entry statistics
 * @route GET /api/admin/time-entries/stats
 * @access Private (Admin)
 */
const getTimeEntryStats = catchAsync(async (req, res) => {
  // Get current date
  const now = new Date();
  
  // Calculate start of current week (Sunday)
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - now.getDay());
  startOfWeek.setHours(0, 0, 0, 0);
  
  // Calculate end of current week (Saturday)
  const endOfWeek = new Date(startOfWeek);
  endOfWeek.setDate(startOfWeek.getDate() + 6);
  endOfWeek.setHours(23, 59, 59, 999);
  
  // Get pending approvals count
  const pendingApprovals = await TimeEntry.countDocuments({ status: 'pending' });
  
  // Get total hours logged this week
  const timeEntriesThisWeek = await TimeEntry.find({
    date: { $gte: startOfWeek, $lte: endOfWeek },
    status: { $in: ['pending', 'approved'] }
  });
  
  const hoursLoggedThisWeek = timeEntriesThisWeek.reduce((total, entry) => total + entry.hours, 0);
  
  // Get active freelancers (those who logged time this week)
  const activeFreelancers = await TimeEntry.distinct('freelancer', {
    date: { $gte: startOfWeek, $lte: endOfWeek }
  });
  
  // Get total hours by status
  const hoursByStatus = await TimeEntry.aggregate([
    {
      $group: {
        _id: '$status',
        totalHours: { $sum: '$hours' }
      }
    }
  ]);
  
  res.status(200).json({
    status: 'success',
    stats: {
      pendingApprovals,
      hoursLoggedThisWeek,
      activeFreelancers: activeFreelancers.length,
      hoursByStatus: hoursByStatus.reduce((obj, item) => {
        obj[item._id] = item.totalHours;
        return obj;
      }, {})
    }
  });
});

/**
 * Get active projects for filtering
 * @route GET /api/admin/projects/active
 * @access Private (Admin)
 */
const getActiveProjects = catchAsync(async (req, res) => {
  const projects = await Project.find({ 
    status: { $in: ['active', 'in_progress'] } 
  })
  .select('_id title client')
  .sort({ createdAt: -1 });
  
  res.status(200).json({
    status: 'success',
    results: projects.length,
    projects
  });
});

/**
 * Get freelancers for filtering
 * @route GET /api/admin/users/freelancers
 * @access Private (Admin)
 */
const getFreelancers = catchAsync(async (req, res) => {
  const freelancers = await User.find({ role: 'freelancer' })
    .select('_id name email profileImage')
    .sort({ name: 1 });
  
  res.status(200).json({
    status: 'success',
    results: freelancers.length,
    freelancers
  });
});

export {
  getTimeEntries,
  getTimeEntryById,
  approveTimeEntry,
  rejectTimeEntry,
  getTimeEntryStats,
  getActiveProjects,
  getFreelancers
};
