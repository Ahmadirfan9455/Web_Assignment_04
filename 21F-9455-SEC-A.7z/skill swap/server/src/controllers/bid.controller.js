import Project from '../models/project.model.js';
import { User, Freelancer } from '../models/user.model.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import { notifyProjectOwner } from '../services/notification.service.js';

/**
 * @desc    Submit a bid for a project
 * @route   POST /api/bids/:projectId
 * @access  Private (Freelancer only)
 */
export const submitBid = asyncHandler(async (req, res) => {
  const { amount, deliveryTime, proposal } = req.body;
  const projectId = req.params.projectId;

  // Find project
  const project = await Project.findById(projectId);

  if (!project) {
    res.status(404);
    throw new Error('Project not found');
  }

  // Check if project is open for bidding
  if (project.status !== 'open') {
    res.status(400);
    throw new Error('Project is not open for bidding');
  }

  // Check if freelancer has already bid on this project
  const existingBid = project.bids.find(
    (bid) => bid.freelancer.toString() === req.user._id.toString()
  );

  if (existingBid) {
    res.status(400);
    throw new Error('You have already submitted a bid for this project');
  }

  // Create new bid
  const newBid = {
    freelancer: req.user._id,
    amount,
    deliveryTime,
    proposal,
  };

  // Add bid to project
  project.bids.push(newBid);
  await project.save();

  // Add bid to freelancer's bids
  await Freelancer.findOneAndUpdate(
    { user: req.user._id },
    { $push: { bids: project._id } }
  );

  // Notify project owner of new bid
  await notifyProjectOwner(project.client, project._id, req.user._id);

  // Real-time: emit to project room
  const { getIO } = await import('../services/socket.service.js');
  getIO().to(`project_${project._id}`).emit('bid:new', {
    projectId: project._id,
    bid: newBid,
    freelancerId: req.user._id,
  });

  res.status(201).json({
    message: 'Bid submitted successfully',
    bid: newBid,
  });
});

/**
 * @desc    Update a bid
 * @route   PUT /api/bids/:projectId
 * @access  Private (Freelancer only - owner)
 */
export const updateBid = asyncHandler(async (req, res) => {
  const { amount, deliveryTime, proposal } = req.body;
  const projectId = req.params.projectId;

  // Find project
  const project = await Project.findById(projectId);

  if (!project) {
    res.status(404);
    throw new Error('Project not found');
  }

  // Find bid
  const bidIndex = project.bids.findIndex(
    (bid) => bid.freelancer.toString() === req.user._id.toString()
  );

  if (bidIndex === -1) {
    res.status(404);
    throw new Error('Bid not found');
  }

  // Check if bid can be updated (not accepted or rejected)
  if (project.bids[bidIndex].status !== 'pending') {
    res.status(400);
    throw new Error('Cannot update bid that is already accepted or rejected');
  }

  // Update bid
  project.bids[bidIndex].amount = amount || project.bids[bidIndex].amount;
  project.bids[bidIndex].deliveryTime = deliveryTime || project.bids[bidIndex].deliveryTime;
  project.bids[bidIndex].proposal = proposal || project.bids[bidIndex].proposal;

  await project.save();

  // Real-time: emit to project room
  const { getIO } = await import('../services/socket.service.js');
  getIO().to(`project_${project._id}`).emit('bid:updated', {
    projectId: project._id,
    bid: project.bids[bidIndex],
    freelancerId: req.user._id,
  });

  res.json({
    message: 'Bid updated successfully',
    bid: project.bids[bidIndex],
  });
});

/**
 * @desc    Accept a bid
 * @route   PUT /api/bids/:projectId/accept/:bidId
 * @access  Private (Client only - project owner)
 */
export const acceptBid = asyncHandler(async (req, res) => {
  const projectId = req.params.projectId;
  const bidId = req.params.bidId;

  // Find project
  const project = await Project.findById(projectId);

  if (!project) {
    res.status(404);
    throw new Error('Project not found');
  }

  // Check if user is project owner
  if (project.client.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to accept bids for this project');
  }

  // Find bid
  const bid = project.bids.id(bidId);

  if (!bid) {
    res.status(404);
    throw new Error('Bid not found');
  }

  // Update bid status
  bid.status = 'accepted';

  // Update project status and assigned freelancer
  project.status = 'in-progress';
  project.assignedFreelancer = bid.freelancer;

  await project.save();

  // Update freelancer's completed projects count
  await Freelancer.findOneAndUpdate(
    { user: bid.freelancer },
    { $inc: { completedProjects: 1 } }
  );

  // Real-time: emit to project room
  const { getIO } = await import('../services/socket.service.js');
  getIO().to(`project_${project._id}`).emit('bid:accepted', {
    projectId: project._id,
    bid,
    freelancerId: bid.freelancer,
  });

  res.json({
    message: 'Bid accepted successfully',
    project,
  });
});

/**
 * @desc    Reject a bid
 * @route   PUT /api/bids/:projectId/reject/:bidId
 * @access  Private (Client only - project owner)
 */
export const rejectBid = asyncHandler(async (req, res) => {
  const projectId = req.params.projectId;
  const bidId = req.params.bidId;

  // Find project
  const project = await Project.findById(projectId);

  if (!project) {
    res.status(404);
    throw new Error('Project not found');
  }

  // Check if user is project owner
  if (project.client.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to reject bids for this project');
  }

  // Find bid
  const bid = project.bids.id(bidId);

  if (!bid) {
    res.status(404);
    throw new Error('Bid not found');
  }

  // Update bid status
  bid.status = 'rejected';

  await project.save();

  // Real-time: emit to project room
  const { getIO } = await import('../services/socket.service.js');
  getIO().to(`project_${project._id}`).emit('bid:rejected', {
    projectId: project._id,
    bid,
    freelancerId: bid.freelancer,
  });

  res.json({
    message: 'Bid rejected successfully',
    project,
  });
});

/**
 * @desc    Counter offer a bid
 * @route   PUT /api/bids/:projectId/counter/:bidId
 * @access  Private (Client only - project owner)
 */
export const counterBid = asyncHandler(async (req, res) => {
  const { amount, deliveryTime, message } = req.body;
  const projectId = req.params.projectId;
  const bidId = req.params.bidId;

  // Find project
  const project = await Project.findById(projectId);

  if (!project) {
    res.status(404);
    throw new Error('Project not found');
  }

  // Check if user is project owner
  if (project.client.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to counter bids for this project');
  }

  // Find bid
  const bid = project.bids.id(bidId);

  if (!bid) {
    res.status(404);
    throw new Error('Bid not found');
  }

  // Update bid status and add counter offer
  bid.status = 'countered';
  bid.counterOffer = {
    amount: amount || bid.amount,
    deliveryTime: deliveryTime || bid.deliveryTime,
    message,
    createdAt: Date.now(),
  };

  await project.save();

  // Real-time: emit to project room
  const { getIO } = await import('../services/socket.service.js');
  getIO().to(`project_${project._id}`).emit('bid:countered', {
    projectId: project._id,
    bid,
    freelancerId: bid.freelancer,
  });

  res.json({
    message: 'Counter offer sent successfully',
    project,
  });
});

/**
 * @desc    Get all bids for a project
 * @route   GET /api/bids/:projectId
 * @access  Private (Client only - project owner)
 */
export const getProjectBids = asyncHandler(async (req, res) => {
  const projectId = req.params.projectId;

  // Find project
  const project = await Project.findById(projectId)
    .populate('bids.freelancer', 'name email')
    .select('bids');

  if (!project) {
    res.status(404);
    throw new Error('Project not found');
  }

  // Check if user is project owner
  if (project.client.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to view bids for this project');
  }

  res.json(project.bids);
});

/**
 * @desc    Get freelancer's bids
 * @route   GET /api/bids/freelancer
 * @access  Private (Freelancer only)
 */
export const getFreelancerBids = asyncHandler(async (req, res) => {
  // Find all projects where freelancer has bid
  const projects = await Project.find({
    'bids.freelancer': req.user._id,
  })
    .select('title description budget status bids')
    .populate('client', 'name email');

  // Extract bids
  const bids = projects.map((project) => {
    const bid = project.bids.find(
      (bid) => bid.freelancer.toString() === req.user._id.toString()
    );

    return {
      project: {
        _id: project._id,
        title: project.title,
        description: project.description,
        budget: project.budget,
        status: project.status,
        client: project.client,
      },
      bid,
    };
  });

  res.json(bids);
});

/**
 * @desc    Get bid analytics
 * @route   GET /api/bids/analytics
 * @access  Private (Freelancer only)
 */
export const getBidAnalytics = asyncHandler(async (req, res) => {
  // Find all projects where freelancer has bid
  const projects = await Project.find({
    'bids.freelancer': req.user._id,
  }).select('bids');

  // Extract bids
  const bids = projects.flatMap((project) =>
    project.bids.filter(
      (bid) => bid.freelancer.toString() === req.user._id.toString()
    )
  );

  // Calculate analytics
  const totalBids = bids.length;
  const acceptedBids = bids.filter((bid) => bid.status === 'accepted').length;
  const rejectedBids = bids.filter((bid) => bid.status === 'rejected').length;
  const pendingBids = bids.filter((bid) => bid.status === 'pending').length;
  const counteredBids = bids.filter((bid) => bid.status === 'countered').length;

  const avgBidAmount =
    bids.reduce((sum, bid) => sum + bid.amount, 0) / (totalBids || 1);

  res.json({
    totalBids,
    acceptedBids,
    rejectedBids,
    pendingBids,
    counteredBids,
    acceptanceRate: totalBids ? (acceptedBids / totalBids) * 100 : 0,
    avgBidAmount,
  });
});
