/**
 * Contract Controller
 * 
 * Handles contract management between clients and freelancers:
 * - Creating contracts
 * - Signing contracts
 * - Updating contract terms
 * - Managing contract versions
 */

import Contract from '../models/contract.model.js';
import Project from '../models/project.model.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import { hashData } from '../utils/hashUtils.js';
import { emitToUser } from '../services/socket.service.js';

/**
 * @desc    Create a new contract
 * @route   POST /api/contracts/:projectId
 * @access  Private (Client only - project owner)
 */
export const createContract = asyncHandler(async (req, res) => {
  const { terms, paymentTerms, deliverables } = req.body;
  const projectId = req.params.projectId;

  // Find project
  const project = await Project.findById(projectId);

  if (!project) {
    res.status(404);
    throw new Error('Project not found');
  }

  // Check if user is project owner
  if (project.client.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to create contract for this project');
  }

  // Check if project has assigned freelancer
  if (!project.assignedFreelancer) {
    res.status(400);
    throw new Error('Cannot create contract without assigned freelancer');
  }

  // Check if contract already exists
  const existingContract = await Contract.findOne({ project: projectId });

  if (existingContract) {
    res.status(400);
    throw new Error('Contract already exists for this project');
  }

  // Create contract
  const contract = await Contract.create({
    project: projectId,
    client: req.user._id,
    freelancer: project.assignedFreelancer,
    terms,
    paymentTerms,
    deliverables,
    _modifiedBy: req.user._id, // For versioning
  });

  // Update project with contract reference
  project.contractId = contract._id;
  await project.save();

  // Notify freelancer of new contract via Socket.io
  emitToUser(project.assignedFreelancer.toString(), 'newContract', {
    contractId: contract._id,
    projectId,
    clientId: req.user._id,
  });

  res.status(201).json(contract);
});

/**
 * @desc    Get contract by ID
 * @route   GET /api/contracts/:id
 * @access  Private (Contract participants only)
 */
export const getContractById = asyncHandler(async (req, res) => {
  const contract = await Contract.findById(req.params.id)
    .populate('client', 'name email')
    .populate('freelancer', 'name email')
    .populate('project', 'title');

  if (!contract) {
    res.status(404);
    throw new Error('Contract not found');
  }

  // Check if user is contract participant
  const isParticipant = 
    contract.client.toString() === req.user._id.toString() ||
    contract.freelancer.toString() === req.user._id.toString();

  if (!isParticipant) {
    res.status(403);
    throw new Error('Not authorized to view this contract');
  }

  res.json(contract);
});

/**
 * @desc    Get contracts for a user
 * @route   GET /api/contracts
 * @access  Private
 */
export const getUserContracts = asyncHandler(async (req, res) => {
  // Determine field to query based on user role
  const field = req.user.role === 'client' ? 'client' : 'freelancer';
  
  // Build filter object
  const filter = { [field]: req.user._id };
  
  // Filter by status
  if (req.query.status) {
    filter.status = req.query.status;
  }
  
  // Pagination
  const page = Number(req.query.page) || 1;
  const limit = Number(req.query.limit) || 10;
  const skip = (page - 1) * limit;

  // Get contracts
  const contracts = await Contract.find(filter)
    .populate('client', 'name email')
    .populate('freelancer', 'name email')
    .populate('project', 'title')
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit);

  // Get total count for pagination
  const count = await Contract.countDocuments(filter);

  res.json({
    contracts,
    page,
    pages: Math.ceil(count / limit),
    total: count,
  });
});

/**
 * @desc    Sign a contract
 * @route   PUT /api/contracts/:id/sign
 * @access  Private (Contract participants only)
 */
export const signContract = asyncHandler(async (req, res) => {
  const contract = await Contract.findById(req.params.id);

  if (!contract) {
    res.status(404);
    throw new Error('Contract not found');
  }

  // Check if user is contract participant
  const isClient = contract.client.toString() === req.user._id.toString();
  const isFreelancer = contract.freelancer.toString() === req.user._id.toString();

  if (!isClient && !isFreelancer) {
    res.status(403);
    throw new Error('Not authorized to sign this contract');
  }

  // Get IP address
  const ipAddress = req.ip || req.connection.remoteAddress;

  // Update signature based on user role
  if (isClient) {
    contract.clientSignature = {
      signed: true,
      timestamp: Date.now(),
      ipAddress,
    };
  } else {
    contract.freelancerSignature = {
      signed: true,
      timestamp: Date.now(),
      ipAddress,
    };
  }

  // Save contract (status will be updated in pre-save middleware)
  contract._modifiedBy = req.user._id; // For versioning
  await contract.save();

  // If both parties have signed, update project status
  if (contract.clientSignature.signed && contract.freelancerSignature.signed) {
    const project = await Project.findById(contract.project);
    
    if (project && project.status === 'open') {
      project.status = 'in-progress';
      await project.save();
    }

    // Notify both parties that contract is active
    emitToUser(contract.client.toString(), 'contractActive', {
      contractId: contract._id,
      projectId: contract.project,
    });

    emitToUser(contract.freelancer.toString(), 'contractActive', {
      contractId: contract._id,
      projectId: contract.project,
    });
  } else {
    // Notify the other party that contract has been signed
    const recipientId = isClient ? contract.freelancer.toString() : contract.client.toString();
    
    emitToUser(recipientId, 'contractSigned', {
      contractId: contract._id,
      projectId: contract.project,
      signedBy: req.user._id,
    });
  }

  res.json(contract);
});

/**
 * @desc    Update contract terms
 * @route   PUT /api/contracts/:id
 * @access  Private (Client only - contract owner)
 */
export const updateContract = asyncHandler(async (req, res) => {
  const { terms, paymentTerms, deliverables } = req.body;
  const contractId = req.params.id;

  const contract = await Contract.findById(contractId);

  if (!contract) {
    res.status(404);
    throw new Error('Contract not found');
  }

  // Check if user is contract owner (client)
  if (contract.client.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to update this contract');
  }

  // Check if contract can be updated (not active or completed)
  if (contract.status === 'active' || contract.status === 'completed') {
    res.status(400);
    throw new Error('Cannot update contract that is already active or completed');
  }

  // Update contract fields
  contract.terms = terms || contract.terms;
  contract.paymentTerms = paymentTerms || contract.paymentTerms;
  
  if (deliverables) {
    contract.deliverables = deliverables;
  }

  // Reset signatures if terms are changed
  if (terms && terms !== contract.terms) {
    contract.clientSignature = {
      signed: false,
      timestamp: null,
      ipAddress: null,
    };
    contract.freelancerSignature = {
      signed: false,
      timestamp: null,
      ipAddress: null,
    };
    contract.status = 'draft';
  }

  // Save contract
  contract._modifiedBy = req.user._id; // For versioning
  await contract.save();

  // Notify freelancer of contract update
  emitToUser(contract.freelancer.toString(), 'contractUpdated', {
    contractId: contract._id,
    projectId: contract.project,
    clientId: req.user._id,
  });

  res.json(contract);
});

/**
 * @desc    Add attachment to contract
 * @route   POST /api/contracts/:id/attachments
 * @access  Private (Contract participants only)
 */
export const addContractAttachment = asyncHandler(async (req, res) => {
  const { url, name, type } = req.body;
  const contractId = req.params.id;

  const contract = await Contract.findById(contractId);

  if (!contract) {
    res.status(404);
    throw new Error('Contract not found');
  }

  // Check if user is contract participant
  const isParticipant = 
    contract.client.toString() === req.user._id.toString() ||
    contract.freelancer.toString() === req.user._id.toString();

  if (!isParticipant) {
    res.status(403);
    throw new Error('Not authorized to add attachments to this contract');
  }

  // Add attachment
  contract.attachments.push({
    url,
    name,
    type,
    uploadedBy: req.user._id,
    uploadedAt: Date.now(),
  });

  // Save contract
  contract._modifiedBy = req.user._id; // For versioning
  await contract.save();

  // Notify other party of new attachment
  const recipientId = 
    contract.client.toString() === req.user._id.toString()
      ? contract.freelancer.toString()
      : contract.client.toString();

  emitToUser(recipientId, 'contractAttachmentAdded', {
    contractId: contract._id,
    projectId: contract.project,
    attachmentName: name,
    addedBy: req.user._id,
  });

  res.status(201).json({
    message: 'Attachment added successfully',
    attachment: contract.attachments[contract.attachments.length - 1],
  });
});

/**
 * @desc    Get contract versions
 * @route   GET /api/contracts/:id/versions
 * @access  Private (Contract participants only)
 */
export const getContractVersions = asyncHandler(async (req, res) => {
  const contract = await Contract.findById(req.params.id)
    .populate('versions.createdBy', 'name email');

  if (!contract) {
    res.status(404);
    throw new Error('Contract not found');
  }

  // Check if user is contract participant
  const isParticipant = 
    contract.client.toString() === req.user._id.toString() ||
    contract.freelancer.toString() === req.user._id.toString();

  if (!isParticipant) {
    res.status(403);
    throw new Error('Not authorized to view this contract');
  }

  res.json(contract.versions);
});

/**
 * @desc    Complete a contract
 * @route   PUT /api/contracts/:id/complete
 * @access  Private (Client only - contract owner)
 */
export const completeContract = asyncHandler(async (req, res) => {
  const contractId = req.params.id;

  const contract = await Contract.findById(contractId);

  if (!contract) {
    res.status(404);
    throw new Error('Contract not found');
  }

  // Check if user is contract owner (client)
  if (contract.client.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to complete this contract');
  }

  // Check if contract is active
  if (contract.status !== 'active') {
    res.status(400);
    throw new Error('Only active contracts can be completed');
  }

  // Update contract status
  contract.status = 'completed';
  contract.endDate = Date.now();
  await contract.save();

  // Update project status
  const project = await Project.findById(contract.project);
  
  if (project) {
    project.status = 'completed';
    project.progress = 100;
    await project.save();
  }

  // Notify freelancer of contract completion
  emitToUser(contract.freelancer.toString(), 'contractCompleted', {
    contractId: contract._id,
    projectId: contract.project,
    clientId: req.user._id,
  });

  res.json({
    message: 'Contract completed successfully',
    contract,
  });
});
