/**
 * Export Controller
 * 
 * Handles exporting data in various formats (CSV, PDF)
 * for analytics reports and project information.
 */

import { asyncHandler } from '../middleware/errorHandler.js';
import Project from '../models/project.model.js';
import { User, Freelancer } from '../models/user.model.js';
import Review from '../models/review.model.js';
import fs from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';

/**
 * @desc    Export projects data as CSV
 * @route   GET /api/export/projects
 * @access  Private (Client/Admin)
 */
export const exportProjectsCSV = asyncHandler(async (req, res) => {
  // Create directory if it doesn't exist
  const exportDir = 'exports';
  if (!fs.existsSync(exportDir)) {
    fs.mkdirSync(exportDir, { recursive: true });
  }

  // Query parameters for filtering
  const { status, category, startDate, endDate } = req.query;
  
  // Build filter object
  const filter = {};
  
  // Add user-specific filter if client
  if (req.user.role === 'client') {
    filter.client = req.user._id;
  }
  
  // Add status filter if provided
  if (status) {
    filter.status = status;
  }
  
  // Add category filter if provided
  if (category) {
    filter.category = category;
  }
  
  // Add date range filter if provided
  if (startDate || endDate) {
    filter.createdAt = {};
    if (startDate) {
      filter.createdAt.$gte = new Date(startDate);
    }
    if (endDate) {
      filter.createdAt.$lte = new Date(endDate);
    }
  }
  
  // Get projects
  const projects = await Project.find(filter)
    .populate('client', 'name email')
    .populate('assignedFreelancer', 'name email')
    .sort({ createdAt: -1 });
  
  // Create CSV content
  let csv = 'ID,Title,Description,Budget,Status,Category,Client,Freelancer,Created Date,Deadline,Progress\n';
  
  projects.forEach((project) => {
    // Format data and handle potential null values
    const clientName = project.client ? project.client.name : 'N/A';
    const freelancerName = project.assignedFreelancer ? project.assignedFreelancer.name : 'N/A';
    const createdDate = project.createdAt.toISOString().split('T')[0];
    const deadline = project.deadline ? project.deadline.toISOString().split('T')[0] : 'N/A';
    
    // Escape commas in text fields
    const title = `"${project.title.replace(/"/g, '""')}"`;
    const description = `"${project.description.replace(/"/g, '""')}"`;
    const category = `"${project.category}"`;
    
    // Add row to CSV
    csv += `${project._id},${title},${description},${project.budget},${project.status},${category},${clientName},${freelancerName},${createdDate},${deadline},${project.progress}%\n`;
  });
  
  // Generate unique filename
  const filename = `projects_export_${uuidv4()}.csv`;
  const filepath = path.join(exportDir, filename);
  
  // Write CSV file
  fs.writeFileSync(filepath, csv);
  
  // Set headers for file download
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename=${filename}`);
  
  // Send file
  res.sendFile(path.resolve(filepath), (err) => {
    if (err) {
      console.error('Error sending file:', err);
    }
    
    // Delete file after sending
    fs.unlinkSync(filepath);
  });
});

/**
 * @desc    Export freelancer performance data as CSV
 * @route   GET /api/export/freelancers
 * @access  Private (Admin only)
 */
export const exportFreelancersCSV = asyncHandler(async (req, res) => {
  // Create directory if it doesn't exist
  const exportDir = 'exports';
  if (!fs.existsSync(exportDir)) {
    fs.mkdirSync(exportDir, { recursive: true });
  }

  // Get all freelancers with their user info
  const freelancers = await Freelancer.find()
    .populate('user', 'name email')
    .sort({ rating: -1 });
  
  // Create CSV content
  let csv = 'ID,Name,Email,Rating,Completed Projects,Verification Level,Skills,Hourly Rate\n';
  
  freelancers.forEach((freelancer) => {
    // Format data and handle potential null values
    const name = freelancer.user ? `"${freelancer.user.name.replace(/"/g, '""')}"` : 'N/A';
    const email = freelancer.user ? freelancer.user.email : 'N/A';
    const skills = `"${freelancer.skills.join(', ').replace(/"/g, '""')}"`;
    
    // Add row to CSV
    csv += `${freelancer._id},${name},${email},${freelancer.rating},${freelancer.completedProjects},${freelancer.verificationLevel},${skills},${freelancer.hourlyRate}\n`;
  });
  
  // Generate unique filename
  const filename = `freelancers_export_${uuidv4()}.csv`;
  const filepath = path.join(exportDir, filename);
  
  // Write CSV file
  fs.writeFileSync(filepath, csv);
  
  // Set headers for file download
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename=${filename}`);
  
  // Send file
  res.sendFile(path.resolve(filepath), (err) => {
    if (err) {
      console.error('Error sending file:', err);
    }
    
    // Delete file after sending
    fs.unlinkSync(filepath);
  });
});

/**
 * @desc    Export analytics data as CSV
 * @route   GET /api/export/analytics
 * @access  Private (Admin only)
 */
export const exportAnalyticsCSV = asyncHandler(async (req, res) => {
  // Create directory if it doesn't exist
  const exportDir = 'exports';
  if (!fs.existsSync(exportDir)) {
    fs.mkdirSync(exportDir, { recursive: true });
  }

  // Get date range from query parameters
  const { startDate, endDate, type } = req.query;
  const start = startDate ? new Date(startDate) : new Date(new Date().setMonth(new Date().getMonth() - 1));
  const end = endDate ? new Date(endDate) : new Date();
  
  // Determine which analytics to export
  let csv = '';
  let filename = '';
  
  if (type === 'users' || !type) {
    // User growth analytics
    const users = await User.aggregate([
      {
        $match: {
          createdAt: { $gte: start, $lte: end }
        }
      },
      {
        $group: {
          _id: {
            year: { $year: '$createdAt' },
            month: { $month: '$createdAt' },
            day: { $dayOfMonth: '$createdAt' }
          },
          count: { $sum: 1 },
          clients: {
            $sum: { $cond: [{ $eq: ['$role', 'client'] }, 1, 0] }
          },
          freelancers: {
            $sum: { $cond: [{ $eq: ['$role', 'freelancer'] }, 1, 0] }
          }
        }
      },
      {
        $sort: {
          '_id.year': 1,
          '_id.month': 1,
          '_id.day': 1
        }
      }
    ]);
    
    // Create CSV content
    csv = 'Date,Total Users,Clients,Freelancers\n';
    
    users.forEach((day) => {
      const date = `${day._id.year}-${String(day._id.month).padStart(2, '0')}-${String(day._id.day).padStart(2, '0')}`;
      csv += `${date},${day.count},${day.clients},${day.freelancers}\n`;
    });
    
    filename = `user_growth_${uuidv4()}.csv`;
  } else if (type === 'projects') {
    // Project analytics
    const projects = await Project.aggregate([
      {
        $match: {
          createdAt: { $gte: start, $lte: end }
        }
      },
      {
        $group: {
          _id: {
            year: { $year: '$createdAt' },
            month: { $month: '$createdAt' },
            day: { $dayOfMonth: '$createdAt' }
          },
          count: { $sum: 1 },
          open: {
            $sum: { $cond: [{ $eq: ['$status', 'open'] }, 1, 0] }
          },
          inProgress: {
            $sum: { $cond: [{ $eq: ['$status', 'in-progress'] }, 1, 0] }
          },
          completed: {
            $sum: { $cond: [{ $eq: ['$status', 'completed'] }, 1, 0] }
          },
          avgBudget: { $avg: '$budget' }
        }
      },
      {
        $sort: {
          '_id.year': 1,
          '_id.month': 1,
          '_id.day': 1
        }
      }
    ]);
    
    // Create CSV content
    csv = 'Date,Total Projects,Open,In Progress,Completed,Average Budget\n';
    
    projects.forEach((day) => {
      const date = `${day._id.year}-${String(day._id.month).padStart(2, '0')}-${String(day._id.day).padStart(2, '0')}`;
      const avgBudget = day.avgBudget ? day.avgBudget.toFixed(2) : '0.00';
      csv += `${date},${day.count},${day.open},${day.inProgress},${day.completed},${avgBudget}\n`;
    });
    
    filename = `project_analytics_${uuidv4()}.csv`;
  } else if (type === 'revenue') {
    // Revenue analytics (based on completed projects)
    const revenue = await Project.aggregate([
      {
        $match: {
          status: 'completed',
          updatedAt: { $gte: start, $lte: end }
        }
      },
      {
        $group: {
          _id: {
            year: { $year: '$updatedAt' },
            month: { $month: '$updatedAt' },
            day: { $dayOfMonth: '$updatedAt' }
          },
          totalRevenue: { $sum: '$budget' },
          projectCount: { $sum: 1 },
          avgRevenue: { $avg: '$budget' }
        }
      },
      {
        $sort: {
          '_id.year': 1,
          '_id.month': 1,
          '_id.day': 1
        }
      }
    ]);
    
    // Create CSV content
    csv = 'Date,Total Revenue,Project Count,Average Revenue\n';
    
    revenue.forEach((day) => {
      const date = `${day._id.year}-${String(day._id.month).padStart(2, '0')}-${String(day._id.day).padStart(2, '0')}`;
      const avgRevenue = day.avgRevenue ? day.avgRevenue.toFixed(2) : '0.00';
      csv += `${date},${day.totalRevenue.toFixed(2)},${day.projectCount},${avgRevenue}\n`;
    });
    
    filename = `revenue_analytics_${uuidv4()}.csv`;
  }
  
  // Generate filepath
  const filepath = path.join(exportDir, filename);
  
  // Write CSV file
  fs.writeFileSync(filepath, csv);
  
  // Set headers for file download
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename=${filename}`);
  
  // Send file
  res.sendFile(path.resolve(filepath), (err) => {
    if (err) {
      console.error('Error sending file:', err);
    }
    
    // Delete file after sending
    fs.unlinkSync(filepath);
  });
});
