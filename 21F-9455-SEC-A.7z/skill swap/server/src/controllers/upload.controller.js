/**
 * Upload Controller
 * 
 * Handles file uploads for:
 * - Freelancer verification documents
 * - Project attachments
 * - User profile images
 */

import { asyncHandler } from '../middleware/errorHandler.js';
import { Freelancer } from '../models/user.model.js';
import Project from '../models/project.model.js';
import fs from 'fs';
import path from 'path';
import { hashData } from '../utils/hashUtils.js';

/**
 * @desc    Upload verification document
 * @route   POST /api/upload/document
 * @access  Private (Freelancer only)
 */
export const uploadDocument = asyncHandler(async (req, res) => {
  if (!req.file) {
    res.status(400);
    throw new Error('No file uploaded');
  }

  const filePath = req.file.path.replace(/\\/g, '/'); // Normalize path for all OS
  const fileUrl = `${req.protocol}://${req.get('host')}/${filePath}`;
  
  // Generate document hash for verification
  const fileBuffer = fs.readFileSync(req.file.path);
  const documentHash = hashData(fileBuffer.toString('base64'));
  
  // Update freelancer profile with document
  const freelancer = await Freelancer.findOne({ user: req.user._id });
  
  if (!freelancer) {
    // Delete uploaded file if freelancer not found
    fs.unlinkSync(req.file.path);
    
    res.status(404);
    throw new Error('Freelancer profile not found');
  }
  
  // Add document to freelancer's verification documents
  freelancer.verificationDocuments.push({
    url: fileUrl,
    name: req.file.originalname,
    type: req.file.mimetype,
    hash: documentHash,
    uploadedAt: Date.now(),
  });
  
  await freelancer.save();
  
  res.status(201).json({
    message: 'Document uploaded successfully',
    document: {
      url: fileUrl,
      name: req.file.originalname,
      type: req.file.mimetype,
      hash: documentHash,
    },
  });
});

/**
 * @desc    Upload project attachment
 * @route   POST /api/upload/project/:projectId
 * @access  Private
 */
export const uploadProjectAttachment = asyncHandler(async (req, res) => {
  if (!req.file) {
    res.status(400);
    throw new Error('No file uploaded');
  }

  const projectId = req.params.projectId;
  const project = await Project.findById(projectId);
  
  if (!project) {
    // Delete uploaded file if project not found
    fs.unlinkSync(req.file.path);
    
    res.status(404);
    throw new Error('Project not found');
  }
  
  // Check if user is project owner or assigned freelancer
  const isAuthorized = 
    project.client.toString() === req.user._id.toString() ||
    (project.assignedFreelancer && project.assignedFreelancer.toString() === req.user._id.toString());
  
  if (!isAuthorized) {
    // Delete uploaded file if user not authorized
    fs.unlinkSync(req.file.path);
    
    res.status(403);
    throw new Error('Not authorized to upload attachments to this project');
  }
  
  const filePath = req.file.path.replace(/\\/g, '/'); // Normalize path for all OS
  const fileUrl = `${req.protocol}://${req.get('host')}/${filePath}`;
  
  // Add attachment to project
  if (!project.attachments) {
    project.attachments = [];
  }
  
  project.attachments.push({
    url: fileUrl,
    name: req.file.originalname,
    type: req.file.mimetype,
    uploadedBy: req.user._id,
    uploadedAt: Date.now(),
  });
  
  await project.save();
  
  res.status(201).json({
    message: 'Attachment uploaded successfully',
    attachment: {
      url: fileUrl,
      name: req.file.originalname,
      type: req.file.mimetype,
    },
  });
});

/**
 * @desc    Upload profile image
 * @route   POST /api/upload/profile
 * @access  Private
 */
export const uploadProfileImage = asyncHandler(async (req, res) => {
  if (!req.file) {
    res.status(400);
    throw new Error('No file uploaded');
  }

  const filePath = req.file.path.replace(/\\/g, '/'); // Normalize path for all OS
  const fileUrl = `${req.protocol}://${req.get('host')}/${filePath}`;
  
  // Update user profile with image URL
  const user = await User.findById(req.user._id);
  user.profileImage = fileUrl;
  await user.save();
  
  // If user is a freelancer, update freelancer profile too
  if (user.role === 'freelancer') {
    const freelancer = await Freelancer.findOne({ user: req.user._id });
    if (freelancer) {
      freelancer.profileImage = fileUrl;
      await freelancer.save();
    }
  }
  
  res.status(200).json({
    message: 'Profile image uploaded successfully',
    profileImage: fileUrl,
  });
});

/**
 * @desc    Delete uploaded file
 * @route   DELETE /api/upload/:fileId
 * @access  Private
 */
export const deleteUploadedFile = asyncHandler(async (req, res) => {
  const { fileId } = req.params;
  const { type, projectId } = req.query;
  
  if (type === 'document') {
    // Delete verification document
    const freelancer = await Freelancer.findOne({ user: req.user._id });
    
    if (!freelancer) {
      res.status(404);
      throw new Error('Freelancer profile not found');
    }
    
    const document = freelancer.verificationDocuments.id(fileId);
    
    if (!document) {
      res.status(404);
      throw new Error('Document not found');
    }
    
    // Extract filename from URL
    const filename = document.url.split('/').pop();
    const filePath = path.join('uploads', 'documents', filename);
    
    // Delete file from disk if it exists
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
    
    // Remove document from freelancer profile
    freelancer.verificationDocuments.pull(fileId);
    await freelancer.save();
    
    res.json({ message: 'Document deleted successfully' });
  } else if (type === 'project') {
    // Delete project attachment
    const project = await Project.findById(projectId);
    
    if (!project) {
      res.status(404);
      throw new Error('Project not found');
    }
    
    // Check if user is project owner or assigned freelancer
    const isAuthorized = 
      project.client.toString() === req.user._id.toString() ||
      (project.assignedFreelancer && project.assignedFreelancer.toString() === req.user._id.toString());
    
    if (!isAuthorized) {
      res.status(403);
      throw new Error('Not authorized to delete attachments from this project');
    }
    
    const attachment = project.attachments.id(fileId);
    
    if (!attachment) {
      res.status(404);
      throw new Error('Attachment not found');
    }
    
    // Extract filename from URL
    const filename = attachment.url.split('/').pop();
    const filePath = path.join('uploads', 'projects', filename);
    
    // Delete file from disk if it exists
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
    
    // Remove attachment from project
    project.attachments.pull(fileId);
    await project.save();
    
    res.json({ message: 'Attachment deleted successfully' });
  } else {
    res.status(400);
    throw new Error('Invalid file type');
  }
});
