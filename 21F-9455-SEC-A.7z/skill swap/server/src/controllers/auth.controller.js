import { User, Freelancer, Client } from '../models/user.model.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import { generateToken, generateRefreshToken } from '../utils/jwtUtils.js';
import { hashPassword, matchPassword, generateVerificationToken } from '../utils/hashUtils.js';
import { sendVerificationEmail, sendPasswordResetEmail } from '../services/email.service.js';
import passport from '../config/passport.js';
import jwt from 'jsonwebtoken';
import axios from 'axios';

/**
 * @desc    Register a new user
 * @route   POST /api/auth/signup
 * @access  Public
 */
export const registerUser = asyncHandler(async (req, res) => {
  const { name, email, password, phone, role } = req.body;

  // Check if user already exists
  const userExists = await User.findOne({ email });
  if (userExists) {
    res.status(400);
    throw new Error('User already exists');
  }

  // Hash password
  const hashedPassword = await hashPassword(password);

  // Generate verification token
  const verificationToken = generateVerificationToken();
  const verificationTokenExpires = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

  // Create user
  const user = await User.create({
    name,
    email,
    password: hashedPassword,
    phone,
    role: role || 'client',
    verificationToken,
    verificationTokenExpires,
  });

  // Create role-specific profile
  if (user.role === 'freelancer') {
    await Freelancer.create({
      user: user._id,
    });
  } else if (user.role === 'client') {
    await Client.create({
      user: user._id,
    });
  }

  // Send verification email
  await sendVerificationEmail(user.email, verificationToken);

  // For development purposes, automatically verify the user
  // In production, this would be removed and users would need to verify via email
  if (process.env.NODE_ENV !== 'production') {
    user.isVerified = true;
    await user.save();
    console.log(`[DEV MODE] Auto-verified user ${user.email}`);
  }

  if (user) {
    res.status(201).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      isVerified: user.isVerified,
      token: generateToken(user._id, user.role, user.email, user.name),
      message: process.env.NODE_ENV !== 'production' 
        ? 'Registration successful. Your account has been automatically verified (dev mode).'
        : 'Registration successful. Please verify your email.',
    });
  } else {
    res.status(400);
    throw new Error('Invalid user data');
  }
});

/**
 * @desc    Verify user email
 * @route   GET /api/auth/verify/:token
 * @access  Public
 */
export const verifyEmail = asyncHandler(async (req, res) => {
  const { token } = req.params;

  const user = await User.findOne({
    verificationToken: token,
    verificationTokenExpires: { $gt: Date.now() },
  });

  if (!user) {
    res.status(400);
    throw new Error('Invalid or expired verification token');
  }

  user.isVerified = true;
  user.verificationToken = undefined;
  user.verificationTokenExpires = undefined;
  await user.save();

  res.status(200).json({
    message: 'Email verified successfully. You can now log in.',
  });
});

/**
 * @desc    Login user
 * @route   POST /api/auth/login
 * @access  Public
 */
export const loginUser = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  // Find user
  const user = await User.findOne({ email });

  // Check if user exists and password matches
  if (user && (await matchPassword(password, user.password))) {
    // Check if email is verified
    if (!user.isVerified) {
      res.status(401);
      throw new Error('Please verify your email before logging in');
    }

    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token: generateToken(user._id, user.role, user.email, user.name),
      refreshToken: generateRefreshToken(user._id),
    });
  } else {
    res.status(401);
    throw new Error('Invalid email or password');
  }
});

/**
 * @desc    Get user profile
 * @route   GET /api/auth/profile
 * @access  Private
 */
export const getUserProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).select('-password');

  if (user) {
    let profile;

    if (user.role === 'freelancer') {
      profile = await Freelancer.findOne({ user: user._id });
    } else if (user.role === 'client') {
      profile = await Client.findOne({ user: user._id });
    }

    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role,
      isVerified: user.isVerified,
      profile,
    });
  } else {
    res.status(404);
    throw new Error('User not found');
  }
});

/**
 * @desc    Get current user data
 * @route   GET /api/auth/me
 * @access  Private
 */
export const getCurrentUser = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).select('-password');

  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }

  // Get role-specific profile data
  let profileData = null;
  if (user.role === 'freelancer') {
    profileData = await Freelancer.findOne({ user: user._id });
  } else if (user.role === 'client') {
    profileData = await Client.findOne({ user: user._id });
  }

  res.status(200).json({
    _id: user._id,
    name: user.name,
    email: user.email,
    role: user.role,
    isVerified: user.isVerified,
    createdAt: user.createdAt,
    profileData: profileData
  });
});

/**
 * @desc    Update user profile
 * @route   PUT /api/auth/profile
 * @access  Private
 */
export const updateUserProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);

  if (user) {
    user.name = req.body.name || user.name;
    user.email = req.body.email || user.email;
    user.phone = req.body.phone || user.phone;

    if (req.body.password) {
      user.password = await hashPassword(req.body.password);
    }

    const updatedUser = await user.save();

    // Update role-specific profile
    if (user.role === 'freelancer' && req.body.profile) {
      const freelancer = await Freelancer.findOne({ user: user._id });
      
      if (freelancer) {
        freelancer.skills = req.body.profile.skills || freelancer.skills;
        freelancer.bio = req.body.profile.bio || freelancer.bio;
        freelancer.hourlyRate = req.body.profile.hourlyRate || freelancer.hourlyRate;
        
        if (req.body.profile.portfolio) {
          freelancer.portfolio = req.body.profile.portfolio;
        }
        
        await freelancer.save();
      }
    } else if (user.role === 'client' && req.body.profile) {
      const client = await Client.findOne({ user: user._id });
      
      if (client) {
        client.company = req.body.profile.company || client.company;
        client.website = req.body.profile.website || client.website;
        
        await client.save();
      }
    }

    res.json({
      _id: updatedUser._id,
      name: updatedUser.name,
      email: updatedUser.email,
      phone: updatedUser.phone,
      role: updatedUser.role,
      token: generateToken(updatedUser._id, updatedUser.role, updatedUser.email, updatedUser.name),
    });
  } else {
    res.status(404);
    throw new Error('User not found');
  }
});

/**
 * @desc    Update user role
 * @route   PUT /api/auth/update-role
 * @access  Private
 */
export const updateUserRole = asyncHandler(async (req, res) => {
  const { role } = req.body;
  
  if (!role || !['client', 'freelancer'].includes(role)) {
    res.status(400);
    throw new Error('Invalid role specified');
  }
  
  // Get the user
  const user = await User.findById(req.user._id);
  
  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }
  
  // Check if user is already in the requested role
  if (user.role === role) {
    return res.status(200).json({
      success: true,
      message: `You are already a ${role}`,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        isVerified: user.isVerified,
      },
    });
  }
  
  // Update user role
  user.role = role;
  await user.save();
  
  // Create role-specific profile if it doesn't exist
  if (role === 'freelancer') {
    const freelancerExists = await Freelancer.findOne({ user: user._id });
    if (!freelancerExists) {
      await Freelancer.create({
        user: user._id,
      });
    }
  } else if (role === 'client') {
    const clientExists = await Client.findOne({ user: user._id });
    if (!clientExists) {
      await Client.create({
        user: user._id,
      });
    }
  }
  
  // Generate new token with updated role
  const token = generateToken(user._id, user.role, user.email, user.name);
  
  res.status(200).json({
    success: true,
    message: `Your role has been updated to ${role}`,
    token,
    user: {
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      isVerified: user.isVerified,
    },
  });
});

/**
 * @desc    Forgot password
 * @route   POST /api/auth/forgot-password
 * @access  Public
 */
export const forgotPassword = asyncHandler(async (req, res) => {
  const { email } = req.body;

  const user = await User.findOne({ email });

  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }

  // Generate reset token
  const resetToken = generateVerificationToken();
  const resetTokenExpires = new Date(Date.now() + 1 * 60 * 60 * 1000); // 1 hour

  user.resetPasswordToken = resetToken;
  user.resetPasswordExpires = resetTokenExpires;
  await user.save();

  // Send password reset email
  const { success, message } = await sendPasswordResetEmail(user.email, resetToken);
  
  if (!success) {
    res.status(500);
    throw new Error(`Failed to send password reset email: ${message}`);
  }

  res.status(200).json({
    success: true,
    message: 'Password reset email sent. Please check your inbox.'
  });
});

/**
 * @desc    Reset password
 * @route   POST /api/auth/reset-password/:token
 * @access  Public
 */
export const resetPassword = asyncHandler(async (req, res) => {
  const { token } = req.params;
  const { password } = req.body;

  const user = await User.findOne({
    resetPasswordToken: token,
    resetPasswordExpires: { $gt: Date.now() },
  });

  if (!user) {
    res.status(400);
    throw new Error('Invalid or expired reset token');
  }

  // Hash new password
  user.password = await hashPassword(password);
  user.resetPasswordToken = undefined;
  user.resetPasswordExpires = undefined;
  await user.save();

  res.status(200).json({
    message: 'Password reset successful',
  });
});

/**
 * @desc    Google OAuth login
 * @route   GET /api/auth/google
 * @access  Public
 */
export const googleLogin = asyncHandler(async (req, res, next) => {
  passport.authenticate('google', { scope: ['profile', 'email'] })(req, res, next);
});

/**
 * @desc    Google OAuth callback
 * @route   GET /api/auth/google/callback
 * @access  Public
 */
export const googleCallback = asyncHandler(async (req, res, next) => {
  passport.authenticate('google', { session: false }, (err, user) => {
    if (err) {
      console.error('Google OAuth Error:', err);
      return res.redirect(`${process.env.CLIENT_URL}/login?error=${encodeURIComponent(err.message)}`);
    }
    
    if (!user) {
      console.error('Google OAuth: No user returned');
      return res.redirect(`${process.env.CLIENT_URL}/login?error=Authentication failed`);
    }

    console.log('Google OAuth successful for user:', user.email);

    // Generate JWT tokens
    const token = generateToken(user._id, user.role, user.email, user.name);
    const refreshToken = generateRefreshToken(user._id);

    // Set HTTP-only cookie with refresh token
    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    });

    // Redirect to frontend with access token
    res.redirect(`${process.env.CLIENT_URL}/auth/success?token=${token}`);
  })(req, res, next);
});

/**
 * @desc    Handle Google OAuth with access token (for @react-oauth/google)
 * @route   POST /api/auth/google/callback
 * @access  Public
 */
export const handleGoogleOAuth = asyncHandler(async (req, res) => {
  const { credential } = req.body;
  
  if (!credential) {
    res.status(400);
    throw new Error('Google access token is required');
  }

  try {
    // Get user info from Google with the access token
    const userInfoResponse = await axios.get('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: {
        Authorization: `Bearer ${credential}`
      }
    });

    const googleUserInfo = userInfoResponse.data;
    
    if (!googleUserInfo || !googleUserInfo.email) {
      res.status(400);
      throw new Error('Failed to fetch user info from Google');
    }

    console.log('Google user info:', googleUserInfo);

    // Check if user exists
    let user = await User.findOne({ email: googleUserInfo.email });

    if (!user) {
      // Create new user
      user = await User.create({
        name: googleUserInfo.name,
        email: googleUserInfo.email,
        googleId: googleUserInfo.sub,
        isVerified: true,
        role: 'client', // Default role
        profileImage: googleUserInfo.picture || '',
        // We don't set a password for Google users
      });

      // Create client profile
      await Client.create({
        user: user._id,
      });
      
      console.log(`Created new user from Google auth: ${googleUserInfo.email}`);
    } else if (!user.googleId) {
      // If user exists but no googleId, update it
      user.googleId = googleUserInfo.sub;
      user.isVerified = true;
      if (googleUserInfo.picture && !user.profileImage) {
        user.profileImage = googleUserInfo.picture;
      }
      await user.save();
      console.log(`Updated existing user with Google ID: ${googleUserInfo.email}`);
    } else {
      console.log(`Existing Google user logged in: ${googleUserInfo.email}`);
    }

    // Generate tokens
    const token = generateToken(user._id, user.role, user.email, user.name);
    const refreshToken = generateRefreshToken(user._id);

    // Set HTTP-only cookie with refresh token
    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    });

    res.status(200).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      isVerified: user.isVerified,
      profileImage: user.profileImage,
      token,
    });
  } catch (error) {
    console.error('Google OAuth error:', error.response?.data || error.message);
    res.status(400);
    throw new Error('Google authentication failed: ' + (error.response?.data?.error_description || error.message));
  }
});

/**
 * @desc    Verify Google token from client
 * @route   POST /api/auth/google/verify
 * @access  Public
 */
export const verifyGoogleToken = asyncHandler(async (req, res) => {
  const { credential } = req.body;
  
  if (!credential) {
    res.status(400);
    throw new Error('Google token is required');
  }

  try {
    // Decode the JWT to get user info
    const decoded = jwt.decode(credential);
    
    if (!decoded || !decoded.email) {
      res.status(400);
      throw new Error('Invalid Google token');
    }

    // Check if user exists
    let user = await User.findOne({ email: decoded.email });

    if (!user) {
      // Create new user
      user = await User.create({
        name: decoded.name,
        email: decoded.email,
        googleId: decoded.sub,
        isVerified: true,
        role: 'client', // Default role
        profileImage: decoded.picture || '',
      });

      // Create client profile
      await Client.create({
        user: user._id,
      });
    } else if (!user.googleId) {
      // If user exists but no googleId, update it
      user.googleId = decoded.sub;
      user.isVerified = true;
      await user.save();
    }

    // Generate tokens
    const token = generateToken(user._id, user.role, user.email, user.name);
    const refreshToken = generateRefreshToken(user._id);

    // Set HTTP-only cookie with refresh token
    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    });

    res.status(200).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      isVerified: user.isVerified,
      profileImage: user.profileImage,
      token,
    });
  } catch (error) {
    res.status(400);
    throw new Error('Invalid Google token: ' + error.message);
  }
});
