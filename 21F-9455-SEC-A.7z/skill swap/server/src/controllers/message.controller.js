import Message from '../models/message.model.js';
import { asyncHandler } from '../middleware/errorHandler.js';

/**
 * @desc    Send a message
 * @route   POST /api/messages
 * @access  Private
 */
export const sendMessage = asyncHandler(async (req, res) => {
  const { receiver, content, project, metadata, attachments } = req.body;

  const message = await Message.create({
    sender: req.user._id,
    receiver,
    content,
    project,
    metadata,
    attachments,
  });

  // Populate sender and receiver info
  const populatedMessage = await Message.findById(message._id)
    .populate('sender', 'name email')
    .populate('receiver', 'name email');

  // Real-time: emit a socket event to sender, receiver, and project room (if applicable)
  const { getIO } = await import('../services/socket.service.js');
  getIO().to(message.sender.toString()).emit('message:new', populatedMessage);
  getIO().to(message.receiver.toString()).emit('message:new', populatedMessage);
  if (message.project) {
    getIO().to(`project_${message.project.toString()}`).emit('message:new', populatedMessage);
  }

  res.status(201).json(populatedMessage);
});

/**
 * @desc    Get conversation between two users
 * @route   GET /api/messages/:userId
 * @access  Private
 */
export const getConversation = asyncHandler(async (req, res) => {
  const userId = req.params.userId;
  const currentUserId = req.user._id;

  // Find all messages between the two users
  const messages = await Message.find({
    $or: [
      { sender: currentUserId, receiver: userId },
      { sender: userId, receiver: currentUserId },
    ],
  })
    .populate('sender', 'name email')
    .populate('receiver', 'name email')
    .sort({ createdAt: 1 });

  res.json(messages);
});

/**
 * @desc    Get all conversations for a user
 * @route   GET /api/messages
 * @access  Private
 */
export const getConversations = asyncHandler(async (req, res) => {
  const currentUserId = req.user._id;

  try {
    // Find all messages where user is sender or receiver
    const messages = await Message.find({
      $or: [{ sender: currentUserId }, { receiver: currentUserId }],
    })
      .populate('sender', 'name email')
      .populate('receiver', 'name email')
      .sort({ createdAt: -1 });

    if (!messages || messages.length === 0) {
      return res.json([]);
    }

    // Group messages by conversation
    const conversations = {};

    for (const message of messages) {
      try {
        // Skip messages with missing sender or receiver
        if (!message.sender || !message.receiver) {
          console.log('Skipping message with missing sender or receiver:', message._id);
          continue;
        }

        // Handle case where sender or receiver might be null after population
        // This can happen if a user was deleted but messages remain
        if (!message.sender._id || !message.receiver._id) {
          console.log('Skipping message with invalid sender or receiver after population:', message._id);
          continue;
        }

        // Safely determine the other user in the conversation
        let otherUser;
        try {
          otherUser = message.sender._id.toString() === currentUserId.toString()
            ? message.receiver
            : message.sender;
        } catch (error) {
          console.log('Error determining other user:', error.message);
          continue;
        }

        // Skip if otherUser is undefined or null
        if (!otherUser || !otherUser._id) {
          console.log('Skipping message with undefined otherUser');
          continue;
        }

        const otherUserId = otherUser._id.toString();

        // Create or update conversation entry
        if (!conversations[otherUserId]) {
          conversations[otherUserId] = {
            user: {
              _id: otherUser._id,
              name: otherUser.name || 'Unknown User',
              email: otherUser.email || 'unknown@example.com'
            },
            lastMessage: {
              _id: message._id,
              content: message.content || '',
              createdAt: message.createdAt,
              readStatus: message.readStatus || false
            },
            unreadCount: 0,
          };
        }

        // Update last message if this one is newer
        if (!conversations[otherUserId].lastMessage.createdAt || 
            new Date(message.createdAt) > new Date(conversations[otherUserId].lastMessage.createdAt)) {
          conversations[otherUserId].lastMessage = {
            _id: message._id,
            content: message.content || '',
            createdAt: message.createdAt,
            readStatus: message.readStatus || false
          };
        }
        
        // Update unread count
        try {
          if (message.sender && 
              message.sender._id && 
              message.sender._id.toString() !== currentUserId.toString() && 
              !message.readStatus) {
            conversations[otherUserId].unreadCount += 1;
          }
        } catch (error) {
          console.log('Error updating unread count:', error.message);
        }
      } catch (messageError) {
        console.log('Error processing message:', messageError.message);
        // Continue to next message
        continue;
      }
    }

    // Convert conversations object to array and sort by last message date
    const conversationsArray = Object.values(conversations)
      .filter(conv => conv && conv.lastMessage && conv.lastMessage.createdAt) // Filter out invalid conversations
      .sort((a, b) => {
        try {
          return new Date(b.lastMessage.createdAt) - new Date(a.lastMessage.createdAt);
        } catch (error) {
          return 0; // Default sort position if dates can't be compared
        }
      });

    res.json(conversationsArray);
  } catch (error) {
    console.error('Error in getConversations:', error);
    res.status(500).json({ 
      message: 'Error fetching conversations', 
      error: error.message,
      success: false
    });
  }
});

/**
 * @desc    Mark message as read
 * @route   PUT /api/messages/:id/read
 * @access  Private
 */
export const markMessageAsRead = asyncHandler(async (req, res) => {
  const messageId = req.params.id;

  const message = await Message.findById(messageId);

  if (!message) {
    res.status(404);
    throw new Error('Message not found');
  }

  // Check if user is the receiver
  if (message.receiver.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to mark this message as read');
  }

  message.readStatus = true;
  await message.save();

  res.json({ message: 'Message marked as read' });
});

/**
 * @desc    Get project messages
 * @route   GET /api/messages/project/:projectId
 * @access  Private
 */
export const getProjectMessages = asyncHandler(async (req, res) => {
  const projectId = req.params.projectId;
  const currentUserId = req.user._id;

  // Find all messages related to the project
  const messages = await Message.find({
    project: projectId,
    $or: [{ sender: currentUserId }, { receiver: currentUserId }],
  })
    .populate('sender', 'name email')
    .populate('receiver', 'name email')
    .sort({ createdAt: 1 });

  res.json(messages);
});
