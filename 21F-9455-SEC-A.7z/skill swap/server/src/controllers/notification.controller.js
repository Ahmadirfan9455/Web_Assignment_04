import { asyncHandler } from '../middleware/errorHandler.js';
import { 
  getUserNotificationPreferences,
  updateUserNotificationPreferences,
  sendVerificationNotification
} from '../services/notification.service.js';
import { sendNotificationEmail } from '../services/email.service.js';

/**
 * @desc    Send email notification
 * @route   POST /api/notify/email
 * @access  Private
 */
export const sendEmail = asyncHandler(async (req, res) => {
  const { recipient, subject, message } = req.body;

  // Check if user has email notifications enabled
  const preferences = await getUserNotificationPreferences(recipient);
  
  if (!preferences.email) {
    return res.status(400).json({
      message: 'Email notifications are disabled for this user',
    });
  }

  // Send email
  const result = await sendNotificationEmail(recipient, subject, message);

  res.status(200).json({
    success: true,
    result,
  });
});

/**
 * @desc    Send SMS notification (mock)
 * @route   POST /api/notify/sms
 * @access  Private
 */
export const sendSMS = asyncHandler(async (req, res) => {
  const { recipient, message } = req.body;

  // Check if user has SMS notifications enabled
  const preferences = await getUserNotificationPreferences(recipient);
  
  if (!preferences.sms) {
    return res.status(400).json({
      message: 'SMS notifications are disabled for this user',
    });
  }

  // Mock SMS sending
  console.log(`[MOCK SMS SERVICE] Sending SMS to ${recipient}: ${message}`);

  res.status(200).json({
    success: true,
    messageId: `sms-${Date.now()}`,
  });
});

/**
 * @desc    Send in-app notification
 * @route   POST /api/notify/in-app
 * @access  Private
 */
export const sendInAppNotification = asyncHandler(async (req, res) => {
  const { recipient, type, title, message, data } = req.body;

  // Check if user has in-app notifications enabled
  const preferences = await getUserNotificationPreferences(recipient);
  
  if (!preferences.inApp) {
    return res.status(400).json({
      message: 'In-app notifications are disabled for this user',
    });
  }

  // In a real implementation, this would save to a notifications collection
  // and potentially trigger a real-time event via Socket.io
  console.log(`[IN-APP NOTIFICATION] Sending to ${recipient}: ${title}`);

  res.status(200).json({
    success: true,
    notificationId: `notify-${Date.now()}`,
  });
});

/**
 * @desc    Get user notification preferences
 * @route   GET /api/notify/preferences
 * @access  Private
 */
export const getNotificationPreferences = asyncHandler(async (req, res) => {
  const preferences = await getUserNotificationPreferences(req.user._id);
  
  res.json(preferences);
});

/**
 * @desc    Update user notification preferences
 * @route   PUT /api/notify/preferences
 * @access  Private
 */
export const updateNotificationPreferences = asyncHandler(async (req, res) => {
  const result = await updateUserNotificationPreferences(req.user._id, req.body);
  
  res.json({
    message: 'Notification preferences updated',
    preferences: result.preferences,
  });
});

/**
 * @desc    Schedule a notification
 * @route   POST /api/notify/schedule
 * @access  Private
 */
export const scheduleNotification = asyncHandler(async (req, res) => {
  const { recipient, type, title, message, scheduledFor, data } = req.body;

  try {
    // Validate scheduled time
    const scheduledTime = new Date(scheduledFor);
    
    if (isNaN(scheduledTime.getTime())) {
      res.status(400);
      throw new Error('Invalid scheduled time format');
    }
    
    if (scheduledTime <= new Date()) {
      res.status(400);
      throw new Error('Scheduled time must be in the future');
    }
    
    // Use the scheduler service to schedule the notification
    const taskId = await import('../services/scheduler.service.js')
      .then(module => module.scheduleNotification(
        scheduledTime,
        recipient,
        type,
        title,
        message,
        data
      ));
    
    res.status(200).json({
      success: true,
      scheduledId: taskId,
      scheduledFor: scheduledTime,
    });
  } catch (error) {
    res.status(400);
    throw new Error(`Failed to schedule notification: ${error.message}`);
  }
});

/**
 * @desc    Cancel a scheduled notification
 * @route   DELETE /api/notify/schedule/:taskId
 * @access  Private
 */
export const cancelScheduledNotification = asyncHandler(async (req, res) => {
  const { taskId } = req.params;
  
  try {
    // Use the scheduler service to cancel the notification
    const success = await import('../services/scheduler.service.js')
      .then(module => module.cancelScheduledNotification(taskId));
    
    if (!success) {
      res.status(404);
      throw new Error('Scheduled notification not found or already executed');
    }
    
    res.status(200).json({
      success: true,
      message: 'Scheduled notification cancelled successfully',
    });
  } catch (error) {
    res.status(error.statusCode || 400);
    throw new Error(`Failed to cancel notification: ${error.message}`);
  }
});

/**
 * @desc    Get all scheduled notifications
 * @route   GET /api/notify/schedule
 * @access  Private (Admin only)
 */
export const getScheduledNotifications = asyncHandler(async (req, res) => {
  try {
    // Use the scheduler service to get all scheduled notifications
    const notifications = await import('../services/scheduler.service.js')
      .then(module => module.getScheduledNotifications());
    
    res.status(200).json(notifications);
  } catch (error) {
    res.status(500);
    throw new Error(`Failed to get scheduled notifications: ${error.message}`);
  }
});
