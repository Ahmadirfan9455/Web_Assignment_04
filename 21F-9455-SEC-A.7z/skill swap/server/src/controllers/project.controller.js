import Project from '../models/project.model.js';
import { User, Freelancer } from '../models/user.model.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import { hashData } from '../utils/hashUtils.js';

/**
 * @desc    Create a new project
 * @route   POST /api/projects
 * @access  Private (Client only)
 */
export const createProject = asyncHandler(async (req, res) => {
  const {
    title,
    description,
    requirements,
    deadline,
    budget,
    category,
    skills,
  } = req.body;

  // Handle attachments
  let attachments = [];
  if (req.files && req.files.length > 0) {
    attachments = req.files.map(file => `/uploads/projects/${file.filename}`);
  }

  // Create project
  const project = await Project.create({
    title,
    description,
    requirements,
    deadline,
    budget,
    category,
    skills,
    client: req.user._id,
    attachments,
  });

  // Add project to client's projects
  await User.findByIdAndUpdate(req.user._id, {
    $push: { projects: project._id },
  });

  res.status(201).json(project);
});

/**
 * @desc    Search projects with suggestions
 * @route   GET /api/projects/search
 * @access  Public
 */
export const searchProjects = asyncHandler(async (req, res) => {
  const { query } = req.query;
  
  if (!query || query.trim() === '') {
    return res.status(200).json([]);
  }

  // Create a regex for case-insensitive search
  const searchRegex = new RegExp(query, 'i');
  
  // Search in title, description, and skills
  const projects = await Project.find({
    $or: [
      { title: searchRegex },
      { description: searchRegex },
      { category: searchRegex },
      { skills: { $in: [searchRegex] } }
    ]
  })
  .select('title category budget skills') // Only return necessary fields for suggestions
  .limit(10); // Limit to 10 suggestions
  
  res.status(200).json(projects);
});

/**
 * @desc    Get all projects
 * @route   GET /api/projects
 * @access  Public
 */
export const getProjects = asyncHandler(async (req, res) => {
  // Build filter object
  const filter = {};
  
  // Filter by status
  if (req.query.status) {
    filter.status = req.query.status;
  }
  
  // Filter by category
  if (req.query.category) {
    filter.category = req.query.category;
  }
  
  // Filter by skills
  if (req.query.skills) {
    const skillsArray = req.query.skills.split(',');
    filter.skills = { $in: skillsArray };
  }
  
  // Filter by budget range
  if (req.query.minBudget || req.query.maxBudget) {
    filter.budget = {};
    if (req.query.minBudget) {
      filter.budget.$gte = Number(req.query.minBudget);
    }
    if (req.query.maxBudget) {
      filter.budget.$lte = Number(req.query.maxBudget);
    }
  }
  
  // Text search
  if (req.query.search) {
    filter.$text = { $search: req.query.search };
  }

  // Pagination
  const page = Number(req.query.page) || 1;
  const limit = Number(req.query.limit) || 10;
  const skip = (page - 1) * limit;

  const projects = await Project.find(filter)
    .populate('client', 'name email')
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit);

  // Get total count for pagination
  const count = await Project.countDocuments(filter);

  res.json({
    projects,
    page,
    pages: Math.ceil(count / limit),
    total: count,
  });
});

/**
 * @desc    Get project by ID
 * @route   GET /api/projects/:id
 * @access  Public
 */
export const getProjectById = asyncHandler(async (req, res) => {
  const project = await Project.findById(req.params.id)
    .populate('client', 'name email')
    .populate('bids.freelancer', 'name email')
    .populate('assignedFreelancer', 'name email');

  if (project) {
    res.json(project);
  } else {
    res.status(404);
    throw new Error('Project not found');
  }
});

/**
 * @desc    Update project
 * @route   PUT /api/projects/:id
 * @access  Private (Client only - owner)
 */
export const updateProject = asyncHandler(async (req, res) => {
  const project = await Project.findById(req.params.id);

  if (!project) {
    res.status(404);
    throw new Error('Project not found');
  }

  // Check if user is project owner
  if (project.client.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to update this project');
  }

  // Check if project can be updated (not in progress or completed)
  if (project.status !== 'open') {
    res.status(400);
    throw new Error('Cannot update project that is already in progress or completed');
  }

  // Update project fields
  project.title = req.body.title || project.title;
  project.description = req.body.description || project.description;
  project.requirements = req.body.requirements || project.requirements;
  project.deadline = req.body.deadline || project.deadline;
  project.budget = req.body.budget || project.budget;
  project.category = req.body.category || project.category;
  project.skills = req.body.skills || project.skills;

  // Handle attachments
  if (req.files && req.files.length > 0) {
    project.attachments = req.files.map(file => `/uploads/projects/${file.filename}`);
  }

  const updatedProject = await project.save();
  res.json(updatedProject);
});

/**
 * @desc    Delete project
 * @route   DELETE /api/projects/:id
 * @access  Private (Client only - owner)
 */
export const deleteProject = asyncHandler(async (req, res) => {
  const project = await Project.findById(req.params.id);

  if (!project) {
    res.status(404);
    throw new Error('Project not found');
  }

  // Check if user is project owner
  if (project.client.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to delete this project');
  }

  // Check if project can be deleted (not in progress or completed)
  if (project.status !== 'open') {
    res.status(400);
    throw new Error('Cannot delete project that is already in progress or completed');
  }

  await project.remove();
  res.json({ message: 'Project removed' });
});

/**
 * @desc    Add milestone to project
 * @route   POST /api/projects/:id/milestones
 * @access  Private (Client only - owner)
 */
export const addMilestone = asyncHandler(async (req, res) => {
  const { title, description, dueDate, amount } = req.body;

  const project = await Project.findById(req.params.id);

  if (!project) {
    res.status(404);
    throw new Error('Project not found');
  }

  // Check if user is project owner
  if (project.client.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to add milestones to this project');
  }

  // Add milestone
  project.milestones.push({
    title,
    description,
    dueDate,
    amount,
  });

  await project.save();
  res.status(201).json(project);
});

/**
 * @desc    Update project progress
 * @route   PUT /api/projects/:id/progress
 * @access  Private (Freelancer only - assigned)
 */
export const updateProgress = asyncHandler(async (req, res) => {
  const { progress } = req.body;

  const project = await Project.findById(req.params.id);

  if (!project) {
    res.status(404);
    throw new Error('Project not found');
  }

  // Check if user is assigned freelancer
  if (project.assignedFreelancer.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to update progress for this project');
  }

  // Update progress
  project.progress = progress;

  // If progress is 100%, mark project as completed
  if (progress === 100) {
    project.status = 'completed';
  }

  await project.save();
  res.json(project);
});

/**
 * @desc    Update milestone status
 * @route   PUT /api/projects/:id/milestones/:milestoneId
 * @access  Private (Client/Freelancer - owner/assigned)
 */
export const updateMilestoneStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;

  const project = await Project.findById(req.params.id);

  if (!project) {
    res.status(404);
    throw new Error('Project not found');
  }

  // Find milestone
  const milestone = project.milestones.id(req.params.milestoneId);

  if (!milestone) {
    res.status(404);
    throw new Error('Milestone not found');
  }

  // Check permissions based on status update
  if (status === 'completed') {
    // Only freelancer can mark as completed
    if (project.assignedFreelancer.toString() !== req.user._id.toString()) {
      res.status(403);
      throw new Error('Only assigned freelancer can mark milestone as completed');
    }
  } else if (status === 'approved') {
    // Only client can approve
    if (project.client.toString() !== req.user._id.toString()) {
      res.status(403);
      throw new Error('Only client can approve milestone');
    }
  }

  // Update milestone status
  milestone.status = status;

  if (status === 'completed') {
    milestone.completedAt = Date.now();
  }

  await project.save();
  res.json(project);
});

/**
 * @desc    Generate contract for project
 * @route   POST /api/projects/:id/contract
 * @access  Private (Client only - owner)
 */
export const generateContract = asyncHandler(async (req, res) => {
  const { terms } = req.body;

  const project = await Project.findById(req.params.id);

  if (!project) {
    res.status(404);
    throw new Error('Project not found');
  }

  // Check if user is project owner
  if (project.client.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('Not authorized to generate contract for this project');
  }

  // Check if project has assigned freelancer
  if (!project.assignedFreelancer) {
    res.status(400);
    throw new Error('Cannot generate contract without assigned freelancer');
  }

  // Generate contract hash
  const contractData = {
    projectId: project._id,
    clientId: project.client,
    freelancerId: project.assignedFreelancer,
    terms,
    timestamp: Date.now(),
  };

  // Hash contract data
  const contractHash = hashData(JSON.stringify(contractData));

  // Update project with contract hash
  project.contractHash = contractHash;
  await project.save();

  res.status(201).json({
    message: 'Contract generated successfully',
    contractHash,
  });
});
