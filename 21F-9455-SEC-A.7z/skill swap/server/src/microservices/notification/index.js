/**
 * Notification Microservice
 * 
 * This microservice handles all notification-related functionality:
 * - Email notifications
 * - SMS notifications
 * - In-app notifications
 * - Notification preferences
 * - Scheduled notifications
 * 
 * In a full microservice architecture, this would be a separate service
 * with its own database and API endpoints.
 */

import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { sendEmail, sendSMS, sendInAppNotification } from './services.js';

// Initialize express app
dotenv.config();
const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.post('/api/email', async (req, res) => {
  const { recipient, subject, message } = req.body;
  
  try {
    const result = await sendEmail(recipient, subject, message);
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/sms', async (req, res) => {
  const { recipient, message } = req.body;
  
  try {
    const result = await sendSMS(recipient, message);
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/in-app', async (req, res) => {
  const { recipient, type, title, message, data } = req.body;
  
  try {
    const result = await sendInAppNotification(recipient, type, title, message, data);
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Start server (in a real microservice deployment)
if (process.env.NODE_ENV !== 'test') {
  const PORT = process.env.NOTIFICATION_SERVICE_PORT || 5001;
  app.listen(PORT, () => {
    console.log(`Notification microservice running on port ${PORT}`);
  });
}

export default app;
