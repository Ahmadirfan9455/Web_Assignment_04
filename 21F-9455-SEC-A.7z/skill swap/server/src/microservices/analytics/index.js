/**
 * Analytics Microservice
 * 
 * This microservice handles all analytics-related functionality:
 * - User growth tracking
 * - Project analytics
 * - Bid analytics
 * - Revenue tracking
 * - Platform performance metrics
 * 
 * In a full microservice architecture, this would be a separate service
 * with its own database and API endpoints.
 */

import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { 
  getUserGrowth, 
  getProjectAnalytics, 
  getBidAnalytics,
  getRevenueAnalytics,
  getPopularSkills
} from './services.js';

// Initialize express app
dotenv.config();
const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.get('/api/analytics/users', async (req, res) => {
  try {
    const result = await getUserGrowth(req.query.period);
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/analytics/projects', async (req, res) => {
  try {
    const result = await getProjectAnalytics(req.query);
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/analytics/bids', async (req, res) => {
  try {
    const result = await getBidAnalytics(req.query);
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/analytics/revenue', async (req, res) => {
  try {
    const result = await getRevenueAnalytics(req.query.period);
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/analytics/skills', async (req, res) => {
  try {
    const result = await getPopularSkills(req.query.limit);
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Start server (in a real microservice deployment)
if (process.env.NODE_ENV !== 'test') {
  const PORT = process.env.ANALYTICS_SERVICE_PORT || 5002;
  app.listen(PORT, () => {
    console.log(`Analytics microservice running on port ${PORT}`);
  });
}

export default app;
