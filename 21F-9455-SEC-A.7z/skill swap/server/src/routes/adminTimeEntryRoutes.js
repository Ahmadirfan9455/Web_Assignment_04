const express = require('express');
const router = express.Router();
const timeEntryController = require('../controllers/timeEntryController');
const { protect, restrictTo } = require('../middleware/authMiddleware');

// Protect all routes - require authentication
router.use(protect);
// Restrict to admin only
router.use(restrictTo('admin'));

// Time entries routes
router.get('/', timeEntryController.getTimeEntries);
router.get('/stats', timeEntryController.getTimeEntryStats);
router.get('/:id', timeEntryController.getTimeEntryById);
router.patch('/:id/approve', timeEntryController.approveTimeEntry);
router.patch('/:id/reject', timeEntryController.rejectTimeEntry);

// Projects and users routes for filtering
router.get('/projects/active', timeEntryController.getActiveProjects);
router.get('/users/freelancers', timeEntryController.getFreelancers);

module.exports = router;
