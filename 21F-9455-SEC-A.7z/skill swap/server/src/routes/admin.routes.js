import express from 'express';
import {
  getPendingFreelancers,
  verifyFreelancer,
  rejectFreelancer,
  getPlatformAnalytics,
  getDocumentVerifications,
  verifyDocument,
  getAllUsers,
  getUserById,
  updateUserStatus,
  deleteUser,
} from '../controllers/admin.controller.js';
import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

// All routes are protected and admin-only
router.use(protect, authorize(['admin']));

// User management routes
router.get('/users', getAllUsers);
router.get('/users/:id', getUserById);
router.put('/users/:id/status', updateUserStatus);
router.delete('/users/:id', deleteUser);

// Freelancer verification routes
router.get('/freelancers/pending', getPendingFreelancers);
router.put('/freelancers/:id/verify', verifyFreelancer);
router.put('/freelancers/:id/reject', rejectFreelancer);

// Document verification routes
router.get('/documents', getDocumentVerifications);
router.put('/documents/:id/verify', verifyDocument);

// Analytics routes
router.get('/analytics', getPlatformAnalytics);

export default router;
