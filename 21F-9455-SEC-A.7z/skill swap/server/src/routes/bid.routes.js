import express from 'express';
import {
  submitBid,
  updateBid,
  acceptBid,
  rejectBid,
  counterBid,
  getProjectBids,
  getFreelancerBids,
  getBidAnalytics,
} from '../controllers/bid.controller.js';
import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

// Freelancer routes
router.post('/:projectId', protect, authorize(['freelancer']), submitBid);
router.put('/:projectId', protect, authorize(['freelancer']), updateBid);
router.get('/freelancer', protect, authorize(['freelancer']), getFreelancerBids);
router.get('/analytics', protect, authorize(['freelancer']), getBidAnalytics);

// Client routes
router.get('/:projectId', protect, authorize(['client']), getProjectBids);
router.put('/:projectId/accept/:bidId', protect, authorize(['client']), acceptBid);
router.put('/:projectId/reject/:bidId', protect, authorize(['client']), rejectBid);
router.put('/:projectId/counter/:bidId', protect, authorize(['client']), counterBid);

export default router;
