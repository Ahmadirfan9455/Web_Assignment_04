import express from 'express';
import {
  sendMessage,
  getConversation,
  getConversations,
  markMessageAsRead,
  getProjectMessages,
} from '../controllers/message.controller.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

// All routes are protected
router.use(protect);

// Message routes
router.post('/', sendMessage);
router.get('/', getConversations);
router.get('/conversations', getConversations);
router.get('/:userId', getConversation);
router.put('/:id/read', markMessageAsRead);
router.get('/project/:projectId', getProjectMessages);

export default router;
