import express from 'express';
import {
  registerUser,
  loginUser,
  verifyEmail,
  getUserProfile,
  updateUserProfile,
  forgotPassword,
  resetPassword,
  updateUserRole,
  getCurrentUser,
  googleLogin,
  googleCallback,
  verifyGoogleToken,
  handleGoogleOAuth,
} from '../controllers/auth.controller.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

// Public routes
router.post('/signup', registerUser);
router.post('/login', loginUser);
router.get('/verify/:token', verifyEmail);
router.post('/forgot-password', forgotPassword);
router.post('/reset-password/:token', resetPassword);

// Google OAuth routes
router.get('/google', googleLogin);
router.get('/google/callback', googleCallback);
router.post('/google/verify', verifyGoogleToken);
router.post('/google/callback', handleGoogleOAuth); // New route for @react-oauth/google

// Protected routes
router.get('/profile', protect, getUserProfile);
router.put('/profile', protect, updateUserProfile);
router.put('/update-role', protect, updateUserRole);
router.get('/me', protect, getCurrentUser);

export default router;
