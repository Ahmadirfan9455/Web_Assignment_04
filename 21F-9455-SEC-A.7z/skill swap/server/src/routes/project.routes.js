import express from 'express';
import {
  createProject,
  getProjects,
  getProjectById,
  updateProject,
  deleteProject,
  addMilestone,
  updateProgress,
  updateMilestoneStatus,
  generateContract,
  searchProjects,
} from '../controllers/project.controller.js';
import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

// Public routes
router.get('/search', searchProjects);
router.get('/', getProjects);
router.get('/:id', getProjectById);

// Client-only routes
import { setUploadType, uploadMultipleFiles, handleUploadErrors } from '../middleware/upload.middleware.js';

router.post('/',
  protect,
  authorize(['client']),
  setUploadType('project'),
  uploadMultipleFiles(5),
  handleUploadErrors,
  createProject
);
router.put('/:id',
  protect,
  authorize(['client']),
  setUploadType('project'),
  uploadMultipleFiles(5),
  handleUploadErrors,
  updateProject
);
router.delete('/:id', protect, authorize(['client']), deleteProject);
router.post('/:id/milestones', protect, authorize(['client']), addMilestone);
router.post('/:id/contract', protect, authorize(['client']), generateContract);

// Freelancer-only routes
router.put('/:id/progress', protect, authorize(['freelancer']), updateProgress);

// Shared routes (with permission checks in controller)
router.put('/:id/milestones/:milestoneId', protect, updateMilestoneStatus);

export default router;
