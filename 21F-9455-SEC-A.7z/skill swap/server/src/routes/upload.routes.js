import express from 'express';
import {
  uploadDocument,
  uploadProjectAttachment,
  uploadProfileImage,
  deleteUploadedFile,
} from '../controllers/upload.controller.js';
import { protect, authorize } from '../middleware/authMiddleware.js';
import { 
  setUploadType, 
  uploadSingleFile, 
  uploadMultipleFiles,
  handleUploadErrors 
} from '../middleware/upload.middleware.js';

const router = express.Router();

// All routes are protected
router.use(protect);

// General file upload route (for multiple files)
router.post(
  '/',
  setUploadType('project'),
  uploadMultipleFiles(5),
  handleUploadErrors,
  (req, res) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ message: 'No files uploaded' });
    }
    
    // Return file information
    const files = req.files.map(file => {
      const filePath = file.path.replace(/\\/g, '/'); // Normalize path for all OS
      return {
        originalName: file.originalname,
        url: `${req.protocol}://${req.get('host')}/${filePath}`,
        mimetype: file.mimetype,
        size: file.size
      };
    });
    
    res.status(201).json(files);
  }
);

// Document upload route (freelancers only)
router.post(
  '/document',
  authorize(['freelancer']),
  setUploadType('document'),
  uploadSingleFile,
  handleUploadErrors,
  uploadDocument
);

// Project attachment upload route
router.post(
  '/project/:projectId',
  setUploadType('project'),
  uploadSingleFile,
  handleUploadErrors,
  uploadProjectAttachment
);

// Profile image upload route
router.post(
  '/profile',
  setUploadType('profile'),
  uploadSingleFile,
  handleUploadErrors,
  uploadProfileImage
);

// Delete uploaded file route
router.delete('/:fileId', deleteUploadedFile);

export default router;
