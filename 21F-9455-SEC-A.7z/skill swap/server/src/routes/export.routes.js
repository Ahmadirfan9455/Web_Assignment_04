import express from 'express';
import {
  exportProjectsCSV,
  exportFreelancersCSV,
  exportAnalyticsCSV,
} from '../controllers/export.controller.js';
import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

// All routes are protected
router.use(protect);

// Export projects data (clients and admins)
router.get('/projects', protect, authorize(['client', 'admin']), exportProjectsCSV);

// Export freelancers data (admin only)
router.get('/freelancers', protect, authorize(['admin']), exportFreelancersCSV);

// Export analytics data (admin only)
router.get('/analytics', protect, authorize(['admin']), exportAnalyticsCSV);

export default router;
