import express from 'express';
import {
  getMilestones,
  getMilestoneById,
  updateMilestoneStatus,
  getMilestoneStats,
  getProjects
} from '../controllers/milestoneController.js';
import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

// All routes are protected and admin-only
router.use(protect, authorize(['admin']));

// Milestone routes
router.get('/', getMilestones);
router.get('/stats', getMilestoneStats);
router.get('/projects', getProjects);
router.get('/:id', getMilestoneById);
router.patch('/:id/status', updateMilestoneStatus);

export default router;
