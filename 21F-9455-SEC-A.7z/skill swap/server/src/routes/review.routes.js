import express from 'express';
import {
  createReview,
  getFreelancerReviews,
  getReviewById,
  respondToReview,
  getProjectReviews,
} from '../controllers/review.controller.js';
import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

// Public routes
router.get('/freelancer/:freelancerId', getFreelancerReviews);
router.get('/:id', getReviewById);

// Protected routes
router.post('/:projectId', protect, authorize(['client']), createReview);
router.put('/:id/respond', protect, authorize(['freelancer']), respondToReview);
router.get('/project/:projectId', protect, getProjectReviews);

export default router;
