import express from 'express';
import {
  getTimeEntries,
  getTimeEntryById,
  approveTimeEntry,
  rejectTimeEntry,
  getTimeEntryStats,
  getActiveProjects,
  getFreelancers
} from '../controllers/timeEntryController.js';
import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

// All routes are protected and admin-only
router.use(protect, authorize(['admin']));

// Time entries routes
router.get('/', getTimeEntries);
router.get('/stats', getTimeEntryStats);
router.get('/:id', getTimeEntryById);
router.patch('/:id/approve', approveTimeEntry);
router.patch('/:id/reject', rejectTimeEntry);

// Projects and users routes for filtering
router.get('/projects/active', getActiveProjects);
router.get('/users/freelancers', getFreelancers);

export default router;
