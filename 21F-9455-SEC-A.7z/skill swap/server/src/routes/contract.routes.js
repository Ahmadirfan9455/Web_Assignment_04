import express from 'express';
import {
  createContract,
  getContractById,
  getUserContracts,
  signContract,
  updateContract,
  addContractAttachment,
  getContractVersions,
  completeContract,
} from '../controllers/contract.controller.js';
import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

// All routes are protected
router.use(protect);

// Get user contracts
router.get('/', getUserContracts);

// Get contract by ID
router.get('/:id', getContractById);

// Get contract versions
router.get('/:id/versions', getContractVersions);

// Create contract (client only)
router.post('/:projectId', authorize(['client']), createContract);

// Update contract (client only)
router.put('/:id', authorize(['client']), updateContract);

// Sign contract (both client and freelancer)
router.put('/:id/sign', signContract);

// Complete contract (client only)
router.put('/:id/complete', authorize(['client']), completeContract);

// Add attachment to contract
router.post('/:id/attachments', addContractAttachment);

export default router;
