import express from 'express';
import {
  sendEmail,
  sendSMS,
  sendInAppNotification,
  getNotificationPreferences,
  updateNotificationPreferences,
  scheduleNotification,
  cancelScheduledNotification,
  getScheduledNotifications,
} from '../controllers/notification.controller.js';
import { protect, authorize } from '../middleware/authMiddleware.js';
const adminOnly = authorize('admin');

const router = express.Router();

// All routes are protected
router.use(protect);

// Notification routes
router.post('/email', sendEmail);
router.post('/sms', sendSMS);
router.post('/in-app', sendInAppNotification);
router.post('/schedule', protect, scheduleNotification);
router.delete('/schedule/:taskId', protect, cancelScheduledNotification);
router.get('/schedule', protect, adminOnly, getScheduledNotifications);

// Preferences routes
router.get('/preferences', getNotificationPreferences);
router.put('/preferences', updateNotificationPreferences);

export default router;
