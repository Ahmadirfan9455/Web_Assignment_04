/**
 * Development Routes
 * These routes are only available in development mode for testing purposes
 * They should be disabled in production
 */

import express from 'express';
import { User } from '../models/user.model.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import { hashPassword } from '../utils/passwordUtils.js';

const router = express.Router();

/**
 * @desc    Verify a user by email (DEV ONLY)
 * @route   GET /api/dev/verify-user/:email
 * @access  Public (but only in development)
 */
router.get('/verify-user/:email', asyncHandler(async (req, res) => {
  // Only allow in development
  if (process.env.NODE_ENV === 'production') {
    return res.status(404).json({ message: 'Route not found' });
  }

  const { email } = req.params;
  
  const user = await User.findOne({ email });
  
  if (!user) {
    return res.status(404).json({ message: 'User not found' });
  }
  
  user.isVerified = true;
  await user.save();
  
  res.status(200).json({
    message: `User ${email} has been verified successfully (DEV MODE)`,
    user: {
      _id: user._id,
      name: user.name,
      email: user.email,
      isVerified: user.isVerified
    }
  });
}));

/**
 * @desc    List all users (DEV ONLY)
 * @route   GET /api/dev/users
 * @access  Public (but only in development)
 */
router.get('/users', asyncHandler(async (req, res) => {
  // Only allow in development
  if (process.env.NODE_ENV === 'production') {
    return res.status(404).json({ message: 'Route not found' });
  }
  
  const users = await User.find().select('-password');
  
  res.status(200).json({
    count: users.length,
    users
  });
}));

/**
 * @desc    Create an admin user (DEV ONLY)
 * @route   POST /api/dev/create-admin
 * @access  Public (but only in development)
 */
router.post('/create-admin', asyncHandler(async (req, res) => {
  // Only allow in development
  if (process.env.NODE_ENV === 'production') {
    return res.status(404).json({ message: 'Route not found' });
  }
  
  const { name, email, password } = req.body;
  
  if (!name || !email || !password) {
    return res.status(400).json({ message: 'Please provide name, email, and password' });
  }
  
  // Check if user already exists
  const userExists = await User.findOne({ email });
  if (userExists) {
    // If user exists but is not an admin, update role to admin
    if (userExists.role !== 'admin') {
      userExists.role = 'admin';
      await userExists.save();
      return res.status(200).json({
        message: `User ${email} role updated to admin`,
        user: {
          _id: userExists._id,
          name: userExists.name,
          email: userExists.email,
          role: userExists.role,
          isVerified: userExists.isVerified
        }
      });
    }
    return res.status(400).json({ message: 'User already exists and is already an admin' });
  }
  
  // Hash password
  const hashedPassword = await hashPassword(password);
  
  // Create admin user
  const user = await User.create({
    name,
    email,
    password: hashedPassword,
    role: 'admin',
    isVerified: true, // Auto-verify admin users
  });
  
  res.status(201).json({
    message: 'Admin user created successfully',
    user: {
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      isVerified: user.isVerified
    }
  });
}));

export default router;
