import express from 'express';
import { searchFreelancers } from '../controllers/freelancer.controller.js';

const router = express.Router();

// Freelancer search/filter endpoint
router.get('/search', searchFreelancers);

export default router;
