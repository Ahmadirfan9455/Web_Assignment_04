const express = require('express');
const router = express.Router();
const milestoneController = require('../controllers/milestoneController');
const { protect, restrictTo } = require('../middleware/authMiddleware');

// Protect all routes - require authentication
router.use(protect);
// Restrict to admin only
router.use(restrictTo('admin'));

// Milestone routes
router.get('/', milestoneController.getMilestones);
router.get('/stats', milestoneController.getMilestoneStats);
router.get('/:id', milestoneController.getMilestoneById);
router.patch('/:id/status', milestoneController.updateMilestoneStatus);

// Projects route for filtering
router.get('/projects', milestoneController.getProjects);

module.exports = router;
