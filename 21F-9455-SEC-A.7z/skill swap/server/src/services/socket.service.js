/**
 * Socket.io Service
 * 
 * This service handles real-time communication using Socket.io.
 * It provides functionality for:
 * - Real-time messaging
 * - Live bid updates
 * - Project activity notifications
 * - User online status
 */

import { Server } from 'socket.io';
import jwt from 'jsonwebtoken';
import { User } from '../models/user.model.js';

let io;

/**
 * Initialize Socket.io server
 * @param {Object} server - HTTP server instance
 */
export const initSocketServer = (server) => {
  io = new Server(server, {
    cors: {
      origin: process.env.CLIENT_URL || '*',
      methods: ['GET', 'POST'],
      credentials: true
    },
    transports: ['websocket', 'polling'],
    allowEIO3: true
  });

  // Authentication middleware
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token || 
                   socket.handshake.headers.authorization?.split(' ')[1] ||
                   socket.handshake.query.token;
      
      if (!token) {
        console.log('Socket auth: No token provided, allowing anonymous connection');
        socket.user = { _id: 'anonymous', role: 'guest' };
        return next();
      }
      
      try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findById(decoded.id).select('-password');
        
        if (!user) {
          console.log('Socket auth: User not found, allowing anonymous connection');
          socket.user = { _id: 'anonymous', role: 'guest' };
          return next();
        }
        
        // Attach user to socket
        socket.user = user;
        next();
      } catch (tokenError) {
        console.log('Socket auth: Invalid token, allowing anonymous connection');
        socket.user = { _id: 'anonymous', role: 'guest' };
        return next();
      }
    } catch (error) {
      console.error('Socket auth error:', error);
      socket.user = { _id: 'anonymous', role: 'guest' };
      return next();
    }
  });

  // Connection handler
  io.on('connection', (socket) => {
    console.log(`User connected: ${socket.user._id}`);
    
    // Join user to their own room for private messages
    socket.join(socket.user._id.toString());
    
    // Join user to project rooms if they're a freelancer or client
    if (socket.user.projects && socket.user.projects.length > 0) {
      socket.user.projects.forEach(project => {
        socket.join(`project_${project}`);
      });
    }
    
    // Update user's online status
    updateUserStatus(socket.user._id, true);
    
    // Handle private messages
    socket.on('sendMessage', (data) => {
      handlePrivateMessage(socket, data);
    });
    
    // Handle bid notifications
    socket.on('newBid', (data) => {
      handleBidNotification(socket, data);
    });
    
    // Handle project updates
    socket.on('projectUpdate', (data) => {
      handleProjectUpdate(socket, data);
    });
    
    // Handle time entry updates
    socket.on('timeEntryUpdate', (data) => {
      handleTimeEntryUpdate(socket, data);
    });
    
    // Handle milestone updates
    socket.on('milestoneUpdate', (data) => {
      handleMilestoneUpdate(socket, data);
    });
    
    // Handle typing indicators
    socket.on('typing', (data) => {
      socket.to(data.receiver).emit('typing', {
        sender: socket.user._id,
        isTyping: data.isTyping,
      });
    });
    
    // Handle disconnection
    socket.on('disconnect', () => {
      console.log(`User disconnected: ${socket.user._id}`);
      updateUserStatus(socket.user._id, false);
    });
  });

  return io;
};

/**
 * Update user's online status
 * @param {string} userId - User ID
 * @param {boolean} isOnline - Online status
 */
const updateUserStatus = async (userId, isOnline) => {
  try {
    // Broadcast to all users that this user's status changed
    io.emit('userStatus', {
      userId,
      isOnline,
      lastSeen: isOnline ? null : new Date(),
    });
  } catch (error) {
    console.error('Error updating user status:', error);
  }
};

/**
 * Handle private message
 * @param {Object} socket - Socket instance
 * @param {Object} data - Message data
 */
const handlePrivateMessage = async (socket, data) => {
  try {
    const { receiver, content, project, metadata } = data;
    
    // Emit to receiver
    socket.to(receiver).emit('newMessage', {
      _id: data._id || `temp-${Date.now()}`,
      sender: socket.user._id,
      senderName: socket.user.name,
      content,
      project,
      createdAt: new Date(),
      readStatus: false,
    });
    
    // Acknowledge message sent
    socket.emit('messageSent', {
      _id: data._id,
      receiver,
      timestamp: new Date(),
    });
  } catch (error) {
    console.error('Error sending private message:', error);
    socket.emit('messageError', {
      error: 'Failed to send message',
    });
  }
};

/**
 * Handle bid notification
 * @param {Object} socket - Socket instance
 * @param {Object} data - Bid data
 */
const handleBidNotification = async (socket, data) => {
  try {
    const { projectId, projectTitle, clientId } = data;
    
    // Emit to project owner
    socket.to(clientId).emit('newBidNotification', {
      projectId,
      projectTitle,
      freelancerId: socket.user._id,
      freelancerName: socket.user.name,
      timestamp: new Date(),
    });
  } catch (error) {
    console.error('Error sending bid notification:', error);
  }
};

/**
 * Handle project update
 * @param {Object} socket - Socket instance
 * @param {Object} data - Project update data
 */
const handleProjectUpdate = async (socket, data) => {
  try {
    const { projectId, updateType, recipients } = data;
    
    // Emit to all recipients
    recipients.forEach((recipientId) => {
      socket.to(recipientId).emit('projectUpdateNotification', {
        projectId,
        updateType,
        updatedBy: socket.user._id,
        updatedByName: socket.user.name,
        timestamp: new Date(),
      });
    });
  } catch (error) {
    console.error('Error sending project update:', error);
  }
};

/**
 * Handle time entry update
 * @param {Object} socket - Socket instance
 * @param {Object} data - Time entry update data
 */
const handleTimeEntryUpdate = async (socket, data) => {
  try {
    const { timeEntryId, status, freelancerId, projectId } = data;
    
    // Emit to the freelancer who submitted the time entry
    socket.to(freelancerId.toString()).emit('timeEntryStatusUpdated', {
      timeEntryId,
      status,
      updatedBy: socket.user._id,
      updatedByName: socket.user.name,
      timestamp: new Date(),
    });
    
    // Emit to project room for other stakeholders
    if (projectId) {
      socket.to(`project_${projectId}`).emit('timeEntryUpdated', {
        timeEntryId,
        status,
        freelancerId,
        updatedBy: socket.user._id,
        timestamp: new Date(),
      });
    }
  } catch (error) {
    console.error('Error sending time entry update:', error);
  }
};

/**
 * Handle milestone update
 * @param {Object} socket - Socket instance
 * @param {Object} data - Milestone update data
 */
const handleMilestoneUpdate = async (socket, data) => {
  try {
    const { milestoneId, status, projectId, note } = data;
    
    // Emit to project room for all stakeholders
    if (projectId) {
      socket.to(`project_${projectId}`).emit('milestoneStatusUpdated', {
        milestoneId,
        status,
        note,
        updatedBy: socket.user._id,
        updatedByName: socket.user.name,
        timestamp: new Date(),
      });
    }
  } catch (error) {
    console.error('Error sending milestone update:', error);
  }
};

/**
 * Get Socket.io instance
 * @returns {Object} Socket.io instance
 */
export const getIO = () => {
  if (!io) {
    throw new Error('Socket.io not initialized');
  }
  return io;
};

/**
 * Emit event to specific user
 * @param {string} userId - User ID
 * @param {string} event - Event name
 * @param {Object} data - Event data
 */
export const emitToUser = (userId, event, data) => {
  if (!io) {
    throw new Error('Socket.io not initialized');
  }
  io.to(userId.toString()).emit(event, data);
};

/**
 * Emit event to multiple users
 * @param {Array} userIds - Array of user IDs
 * @param {string} event - Event name
 * @param {Object} data - Event data
 */
export const emitToUsers = (userIds, event, data) => {
  if (!io) {
    throw new Error('Socket.io not initialized');
  }
  userIds.forEach((userId) => {
    io.to(userId.toString()).emit(event, data);
  });
};

/**
 * Emit event to all connected users
 * @param {string} event - Event name
 * @param {Object} data - Event data
 */
export const emitToAll = (event, data) => {
  if (!io) {
    throw new Error('Socket.io not initialized');
  }
  io.emit(event, data);
};
