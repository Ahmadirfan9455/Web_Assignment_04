/**
 * Scheduler Service
 * 
 * Handles scheduled tasks such as:
 * - Deadline reminders
 * - Scheduled notifications
 * - Periodic system maintenance
 * - Automated reports
 */

import cron from 'node-cron';
import { v4 as uuidv4 } from 'uuid';
import { User } from '../models/user.model.js';
import Project from '../models/project.model.js';
import { sendEmail } from '../controllers/notification.controller.js';
import { emitToUser } from './socket.service.js';
import { callMicroservice } from '../config/microservices.js';

// Store for scheduled tasks
const scheduledTasks = new Map();
// Store for scheduled notifications
const scheduledNotifications = new Map();

/**
 * Initialize the scheduler service
 */
export const initScheduler = () => {
  console.log('Scheduler service initialized');
  
  // Set up recurring tasks
  setupRecurringTasks();
  
  // Load any persisted scheduled notifications from database
  // This is a placeholder for now since we're not persisting notifications to DB yet
  console.log('Loading persisted scheduled notifications...');
};

/**
 * Set up recurring tasks
 */
const setupRecurringTasks = () => {
  // Schedule deadline reminders - runs daily at 9:00 AM
  scheduledTasks.set('deadlineReminders', cron.schedule('0 9 * * *', async () => {
    await sendDeadlineReminders();
  }));
  
  // Weekly project status reports - runs every Monday at 8:00 AM
  scheduledTasks.set('weeklyReports', cron.schedule('0 8 * * 1', async () => {
    await generateWeeklyReports();
  }));
  
  // Monthly analytics - runs on the 1st of each month at 1:00 AM
  scheduledTasks.set('monthlyAnalytics', cron.schedule('0 1 1 * *', async () => {
    await generateMonthlyAnalytics();
  }));
  
  // Inactive user reminders - runs every Wednesday at 3:00 PM
  scheduledTasks.set('inactiveUserReminders', cron.schedule('0 15 * * 3', async () => {
    await sendInactiveUserReminders();
  }));
  
  // Schedule milestone reminders - runs daily at 10:00 AM
  scheduledTasks.set('milestoneReminders', cron.schedule('0 10 * * *', async () => {
    await sendMilestoneReminders();
  }));
  
  // Schedule inactive project reminders - runs weekly on Monday at 8:00 AM
  scheduledTasks.set('inactiveProjectReminders', cron.schedule('0 8 * * 1', async () => {
    await sendInactiveProjectReminders();
  }));
  
  // Schedule system maintenance - runs weekly on Sunday at 2:00 AM
  scheduledTasks.set('systemMaintenance', cron.schedule('0 2 * * 0', async () => {
    await performSystemMaintenance();
  }));
  
  // Schedule automated reports - runs monthly on the 1st at 6:00 AM
  scheduledTasks.set('automatedReports', cron.schedule('0 6 1 * *', async () => {
    await generateAutomatedReports();
  }));
  
  console.log('Scheduler service initialized successfully');
};

/**
 * Send deadline reminders for projects approaching their deadlines
 */
async function sendDeadlineReminders() {
  try {
    console.log('Sending deadline reminders...');
    
    // Find projects with deadlines in the next 3 days
    const threeDaysFromNow = new Date();
    threeDaysFromNow.setDate(threeDaysFromNow.getDate() + 3);
    
    // Send reminders for each project
    for (const project of projects) {
      const daysRemaining = Math.ceil((project.deadline - now) / (1000 * 60 * 60 * 24));
      
      // Notify client
      if (project.client) {
        // Send in-app notification
        emitToUser(project.client._id.toString(), 'deadlineReminder', {
          projectId: project._id,
          projectTitle: project.title,
          daysRemaining,
        });
        
        // Send email notification
        await callMicroservice('notification', 'email', 'POST', {
          recipient: project.client.email,
          subject: `Deadline Reminder: ${project.title}`,
          message: `Your project "${project.title}" is due in ${daysRemaining} days. Please check the project status and ensure all requirements are being met.`,
        });
      }
      
      // Notify assigned freelancer if any
      if (project.assignedFreelancer) {
        // Send in-app notification
        emitToUser(project.assignedFreelancer._id.toString(), 'deadlineReminder', {
          projectId: project._id,
          projectTitle: project.title,
          daysRemaining,
        });
        
        // Send email notification
        await callMicroservice('notification', 'email', 'POST', {
          recipient: project.assignedFreelancer.email,
          subject: `Deadline Reminder: ${project.title}`,
          message: `The project "${project.title}" is due in ${daysRemaining} days. Please ensure you complete all deliverables on time.`,
        });
      }
    }
    
    console.log(`Sent deadline reminders for ${projects.length} projects`);
  } catch (error) {
    console.error('Error sending deadline reminders:', error);
  }
};

/**
 * Send milestone reminders for upcoming milestones
 */
const sendMilestoneReminders = async () => {
  try {
    console.log('Sending milestone reminders...');
    
    // Get current date and date 3 days from now
    const now = new Date();
    const threeDaysFromNow = new Date();
    threeDaysFromNow.setDate(now.getDate() + 3);
    
    // Find projects with milestones due in the next 3 days
    const projects = await Project.find({
      status: 'in-progress',
      'milestones.dueDate': { $gte: now, $lte: threeDaysFromNow },
      'milestones.status': { $in: ['pending', 'in-progress'] }
    }).populate('client').populate('assignedFreelancer');
    
    let reminderCount = 0;
    
    // Send reminders for each project with upcoming milestones
    for (const project of projects) {
      // Filter milestones that are due in the next 3 days
      const upcomingMilestones = project.milestones.filter(milestone => 
        milestone.dueDate >= now && 
        milestone.dueDate <= threeDaysFromNow &&
        ['pending', 'in-progress'].includes(milestone.status)
      );
      
      if (upcomingMilestones.length === 0) continue;
      
      // Notify client
      if (project.client) {
        // Send in-app notification
        emitToUser(project.client._id.toString(), 'milestoneReminder', {
          projectId: project._id,
          projectTitle: project.title,
          milestonesCount: upcomingMilestones.length,
        });
        
        // Send email notification
        await callMicroservice('notification', 'email', 'POST', {
          recipient: project.client.email,
          subject: `Milestone Reminder: ${project.title}`,
          message: `Your project "${project.title}" has ${upcomingMilestones.length} milestone(s) due in the next 3 days. Please check the project status.`,
        });
      }
      
      // Notify assigned freelancer
      if (project.assignedFreelancer) {
        // Send in-app notification
        emitToUser(project.assignedFreelancer._id.toString(), 'milestoneReminder', {
          projectId: project._id,
          projectTitle: project.title,
          milestonesCount: upcomingMilestones.length,
        });
        
        // Send email notification
        await callMicroservice('notification', 'email', 'POST', {
          recipient: project.assignedFreelancer.email,
          subject: `Milestone Reminder: ${project.title}`,
          message: `The project "${project.title}" has ${upcomingMilestones.length} milestone(s) due in the next 3 days. Please ensure you complete them on time.`,
        });
      }
      
      reminderCount += upcomingMilestones.length;
    }
    
    console.log(`Sent reminders for ${reminderCount} milestones`);
  } catch (error) {
    console.error('Error sending milestone reminders:', error);
  }
};

/**
 * Send reminders for inactive projects
 */
const sendInactiveProjectReminders = async () => {
  try {
    console.log('Sending inactive project reminders...');
    
    // Get date 14 days ago
    const twoWeeksAgo = new Date();
    twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14);
    
    // Find in-progress projects with no updates in the last 14 days
    const projects = await Project.find({
      status: 'in-progress',
      updatedAt: { $lt: twoWeeksAgo }
    }).populate('client').populate('assignedFreelancer');
    
    // Send reminders for each inactive project
    for (const project of projects) {
      // Notify client
      if (project.client) {
        // Send in-app notification
        emitToUser(project.client._id.toString(), 'inactiveProjectReminder', {
          projectId: project._id,
          projectTitle: project.title,
        });
        
        // Send email notification
        await callMicroservice('notification', 'email', 'POST', {
          recipient: project.client.email,
          subject: `Inactive Project: ${project.title}`,
          message: `Your project "${project.title}" has been inactive for over 2 weeks. Please check the status or contact your freelancer.`,
        });
      }
      
      // Notify assigned freelancer
      if (project.assignedFreelancer) {
        // Send in-app notification
        emitToUser(project.assignedFreelancer._id.toString(), 'inactiveProjectReminder', {
          projectId: project._id,
          projectTitle: project.title,
        });
        
        // Send email notification
        await callMicroservice('notification', 'email', 'POST', {
          recipient: project.assignedFreelancer.email,
          subject: `Inactive Project: ${project.title}`,
          message: `The project "${project.title}" has been inactive for over 2 weeks. Please update the progress or contact the client.`,
        });
      }
    }
    
    console.log(`Sent reminders for ${projects.length} inactive projects`);
  } catch (error) {
    console.error('Error sending inactive project reminders:', error);
  }
};

/**
 * Perform system maintenance tasks
 */
const performSystemMaintenance = async () => {
  try {
    console.log('Performing system maintenance...');
    
    // Clean up expired verification tokens
    const expiredTokenResult = await User.updateMany(
      { verificationTokenExpires: { $lt: new Date() } },
      { $unset: { verificationToken: "", verificationTokenExpires: "" } }
    );
    
    // Clean up expired reset password tokens
    const expiredResetResult = await User.updateMany(
      { resetPasswordExpires: { $lt: new Date() } },
      { $unset: { resetPasswordToken: "", resetPasswordExpires: "" } }
    );
    
    console.log(`System maintenance completed: Cleaned up ${expiredTokenResult.nModified} expired verification tokens and ${expiredResetResult.nModified} expired reset tokens`);
  } catch (error) {
    console.error('Error performing system maintenance:', error);
  }
};

/**
 * Generate automated reports for admins
 */
const generateAutomatedReports = async () => {
  try {
    console.log('Generating automated reports...');
    
    // Get admin users
    const admins = await User.find({ role: 'admin' });
    
    // Get previous month data
    const now = new Date();
    const firstDayPrevMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const lastDayPrevMonth = new Date(now.getFullYear(), now.getMonth(), 0);
    
    // Get month name
    const monthName = firstDayPrevMonth.toLocaleString('default', { month: 'long' });
    
    // Get new users count
    const newUsers = await User.countDocuments({
      createdAt: { $gte: firstDayPrevMonth, $lte: lastDayPrevMonth }
    });
    
    // Get new projects count
    const newProjects = await Project.countDocuments({
      createdAt: { $gte: firstDayPrevMonth, $lte: lastDayPrevMonth }
    });
    
    // Get completed projects count
    const completedProjects = await Project.countDocuments({
      status: 'completed',
      updatedAt: { $gte: firstDayPrevMonth, $lte: lastDayPrevMonth }
    });
    
    // Get total revenue from completed projects
    const revenueResult = await Project.aggregate([
      {
        $match: {
          status: 'completed',
          updatedAt: { $gte: firstDayPrevMonth, $lte: lastDayPrevMonth }
        }
      },
      {
        $group: {
          _id: null,
          totalRevenue: { $sum: '$budget' }
        }
      }
    ]);
    
    const totalRevenue = revenueResult.length > 0 ? revenueResult[0].totalRevenue : 0;
    
    // Generate report message
    const reportMessage = `
      <h2>Monthly Report - ${monthName} ${firstDayPrevMonth.getFullYear()}</h2>
      <p>Here's a summary of platform activity for the past month:</p>
      <ul>
        <li><strong>New Users:</strong> ${newUsers}</li>
        <li><strong>New Projects:</strong> ${newProjects}</li>
        <li><strong>Completed Projects:</strong> ${completedProjects}</li>
        <li><strong>Total Revenue:</strong> $${totalRevenue.toFixed(2)}</li>
      </ul>
      <p>For detailed analytics, please visit the admin dashboard.</p>
    `;
    
    // Send report to all admins
    for (const admin of admins) {
      await callMicroservice('notification', 'email', 'POST', {
        recipient: admin.email,
        subject: `SkillSwap Monthly Report - ${monthName} ${firstDayPrevMonth.getFullYear()}`,
        message: reportMessage,
      });
    }
    
    console.log(`Sent monthly reports to ${admins.length} admins`);
  } catch (error) {
    console.error('Error generating automated reports:', error);
  }
};

/**
 * Schedule a custom notification
 * @param {Date} scheduledFor - Date and time to send notification
 * @param {string} recipientId - User ID to receive notification
 * @param {string} type - Notification type
 * @param {string} title - Notification title
 * @param {string} message - Notification message
 * @param {Object} data - Additional data
 * @returns {string} Scheduled task ID
 */
export const scheduleNotification = (scheduledFor, recipientId, type, title, message, data = {}) => {
  try {
    // Calculate delay in milliseconds
    const now = new Date();
    const delay = scheduledFor.getTime() - now.getTime();
    
    if (delay <= 0) {
      throw new Error('Scheduled time must be in the future');
    }
    
    // Generate unique task ID
    const taskId = `notification_${recipientId}_${Date.now()}`;
    
    // Schedule task
    const task = setTimeout(async () => {
      try {
        // Send in-app notification
        emitToUser(recipientId, 'scheduledNotification', {
          type,
          title,
          message,
          data,
        });
        
        // Get user email
        const user = await User.findById(recipientId);
        
        if (user && user.email) {
          // Send email notification
          await callMicroservice('notification', 'email', 'POST', {
            recipient: user.email,
            subject: title,
            message,
          });
        }
        
        // Remove task from scheduled tasks
        scheduledTasks.delete(taskId);
      } catch (error) {
        console.error('Error sending scheduled notification:', error);
      }
    }, delay);
    
    // Store task reference
    scheduledTasks.set(taskId, {
      task,
      scheduledFor,
      recipientId,
      type,
      title,
      message,
    });
    
    return taskId;
  } catch (error) {
    console.error('Error scheduling notification:', error);
    throw error;
  }
};

/**
 * Cancel a scheduled notification
 * @param {string} taskId - Scheduled task ID
 * @returns {boolean} Success status
 */
export const cancelScheduledNotification = (taskId) => {
  try {
    if (!scheduledTasks.has(taskId)) {
      return false;
    }
    
    const task = scheduledTasks.get(taskId);
    
    // Clear timeout
    clearTimeout(task.task);
    
    // Remove from scheduled tasks
    scheduledTasks.delete(taskId);
    
    return true;
  } catch (error) {
    console.error('Error canceling scheduled notification:', error);
    return false;
  }
};

/**
 * Get all scheduled notifications
 * @returns {Array} List of scheduled notifications
 */
export const getScheduledNotifications = () => {
  const notifications = [];
  
  for (const [taskId, task] of scheduledTasks.entries()) {
    // Only include actual notifications, not system tasks
    if (taskId.startsWith('notification_')) {
      notifications.push({
        taskId,
        scheduledFor: task.scheduledFor,
        recipientId: task.recipientId,
        type: task.type,
        title: task.title,
        message: task.message,
      });
    }
  }
  
  return notifications;
};
