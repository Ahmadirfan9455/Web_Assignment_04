/**
 * Email service for sending notifications
 * Using Nodemailer with Gmail for sending real emails
 */
import nodemailer from 'nodemailer';

// Create a transporter for Gmail
// Note: For Gmail, you need to use an App Password instead of your regular password
// To generate an App Password: Google Account > Security > 2-Step Verification > App Passwords
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER || 'ardsir51@gmail.com',
    // For development, we'll use a fallback that doesn't actually send emails
    pass: process.env.EMAIL_PASS || ''
  },
  // Fallback to console logging if email sending fails
  debug: true
});

// Flag to track if we're in development mode with no valid email credentials
const isEmailConfigured = process.env.EMAIL_PASS && process.env.EMAIL_PASS.length > 0;

// Base URL for verification links
const baseUrl = process.env.CLIENT_URL || 'http://localhost:3000';

/**
 * Send verification email to user
 * @param {string} email - User's email address
 * @param {string} token - Verification token
 */
export const sendVerificationEmail = async (email, token) => {
  try {
    // Create verification URL
    const verificationUrl = `${baseUrl}/verify-email/${token}`;
    
    // If email is not configured, just log the verification URL and return success
    if (!isEmailConfigured) {
      console.log(`[DEV MODE] Email sending skipped. Verification URL for ${email}:`);
      console.log(verificationUrl);
      console.log(`Token: ${token}`);
      return {
        success: true,
        messageId: `mock-${Date.now()}`,
        devMode: true
      };
    }
    
    // Email content
    const mailOptions = {
      from: `"SkillSwap Team" <${process.env.EMAIL_USER || 'ardsir51@gmail.com'}>`,
      to: email,
      subject: 'Verify Your SkillSwap Account',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
          <h2 style="color: #4f46e5;">Welcome to SkillSwap!</h2>
          <p>Thank you for registering. Please verify your email address to activate your account.</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${verificationUrl}" style="background-color: #4f46e5; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; font-weight: bold;">Verify Email Address</a>
          </div>
          <p>If the button above doesn't work, you can also copy and paste the following link into your browser:</p>
          <p style="word-break: break-all; color: #4f46e5;">${verificationUrl}</p>
          <p>This verification link will expire in 24 hours.</p>
          <hr style="border: none; border-top: 1px solid #e0e0e0; margin: 20px 0;">
          <p style="color: #666; font-size: 12px;">If you didn't create an account on SkillSwap, you can safely ignore this email.</p>
        </div>
      `
    };
    
    // Send email
    const info = await transporter.sendMail(mailOptions);
    console.log(`Email sent to ${email}: ${info.messageId}`);
    
    return {
      success: true,
      messageId: info.messageId
    };
  } catch (error) {
    console.error('Email sending failed:', error);
    // In development, we'll still consider this a success so the registration process can continue
    if (process.env.NODE_ENV !== 'production') {
      console.log(`[DEV MODE] Verification URL for ${email} (after email error):`);
      console.log(`${baseUrl}/verify-email/${token}`);
      return {
        success: true,
        messageId: `mock-${Date.now()}`,
        devMode: true,
        error: error.message
      };
    }
    return {
      success: false,
      error: error.message
    };
  }
};

/**
 * Send password reset email to user
 * @param {string} email - User's email address
 * @param {string} token - Reset password token
 */
export const sendPasswordResetEmail = async (email, token) => {
  try {
    // Create reset password URL
    const resetUrl = `${baseUrl}/reset-password/${token}`;
    
    // If email is not configured, just log the reset URL and return success
    if (!isEmailConfigured) {
      console.log('Development mode: Password reset URL:', resetUrl);
      return { success: true, message: 'Reset password email logged (dev mode)' };
    }
    
    // Email content
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'SkillSwap - Reset Your Password',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); padding: 20px; border-radius: 10px 10px 0 0; text-align: center;">
            <h1 style="color: white; margin: 0;">SkillSwap</h1>
          </div>
          <div style="background-color: #1e1e2d; color: #e2e8f0; padding: 20px; border-radius: 0 0 10px 10px;">
            <h2 style="margin-top: 0;">Reset Your Password</h2>
            <p>You requested to reset your password. Click the button below to create a new password:</p>
            <div style="text-align: center; margin: 30px 0;">
              <a href="${resetUrl}" style="background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block; font-weight: bold;">Reset Password</a>
            </div>
            <p>If you didn't request a password reset, you can safely ignore this email.</p>
            <p>This link will expire in 1 hour.</p>
            <hr style="border: none; border-top: 1px solid #4b5563; margin: 20px 0;">
            <p style="font-size: 12px; color: #9ca3af; text-align: center;">&copy; ${new Date().getFullYear()} SkillSwap. All rights reserved.</p>
          </div>
        </div>
      `
    };
    
    // Send email
    const info = await transporter.sendMail(mailOptions);
    console.log('Password reset email sent:', info.messageId);
    return { success: true, message: 'Reset password email sent' };
  } catch (error) {
    console.error('Error sending password reset email:', error);
    return { success: false, message: error.message };
  }
};

/**
 * Send notification email
 * @param {string} email - User's email address
 * @param {string} subject - Email subject
 * @param {string} message - Email message
 */
export const sendNotificationEmail = async (email, subject, message) => {
  try {
    // Email content
    const mailOptions = {
      from: `"SkillSwap Team" <${process.env.EMAIL_USER || 'ardsir51@gmail.com'}>`,
      to: email,
      subject: subject,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
          <h2 style="color: #4f46e5;">SkillSwap Notification</h2>
          <p>${message}</p>
          <hr style="border: none; border-top: 1px solid #e0e0e0; margin: 20px 0;">
          <p style="color: #666; font-size: 12px;">This is an automated message from SkillSwap. Please do not reply to this email.</p>
        </div>
      `
    };
    
    // Send email
    const info = await transporter.sendMail(mailOptions);
    console.log(`Notification email sent to ${email}: ${info.messageId}`);
    
    return {
      success: true,
      messageId: info.messageId
    };
  } catch (error) {
    console.error('Notification email sending failed:', error);
    return {
      success: false,
      error: error.message
    };
  }
};
