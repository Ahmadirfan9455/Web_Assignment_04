import jwt from 'jsonwebtoken';

/**
 * Generate a JWT token for authentication
 * @param {string} id - User ID to encode in the token
 * @returns {string} JWT token
 */
/**
 * Generate a JWT token for authentication
 * @param {string} id - User ID to encode in the token
 * @param {string} role - User role
 * @param {string} email - User email
 * @param {string} name - User name
 * @returns {string} JWT token
 */
export const generateToken = (id, role, email, name) => {
  return jwt.sign({ id, role, email, name }, process.env.JWT_SECRET, {
    expiresIn: '30d',
  });
};

/**
 * Generate refresh token with longer expiry
 * @param {string} id - User ID to encode in the token
 * @returns {string} Refresh token
 */
export const generateRefreshToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_REFRESH_SECRET, {
    expiresIn: '60d',
  });
};
