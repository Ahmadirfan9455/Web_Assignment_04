import bcrypt from 'bcrypt';
import crypto from 'crypto';

/**
 * Hash a password using bcrypt
 * @param {string} password - Plain text password
 * @returns {string} Hashed password
 */
export const hashPassword = async (password) => {
  const salt = await bcrypt.genSalt(10);
  return await bcrypt.hash(password, salt);
};

/**
 * Compare a plain text password with a hashed password
 * @param {string} enteredPassword - Plain text password
 * @param {string} hashedPassword - Hashed password from database
 * @returns {boolean} True if passwords match
 */
export const matchPassword = async (enteredPassword, hashedPassword) => {
  return await bcrypt.compare(enteredPassword, hashedPassword);
};

/**
 * Hash sensitive data using SHA-256
 * @param {string} data - Data to hash
 * @returns {string} Hashed data
 */
export const hashData = (data) => {
  return crypto.createHash('sha256').update(data).digest('hex');
};

/**
 * Generate a random token for email verification, password reset, etc.
 * @returns {string} Random token
 */
export const generateVerificationToken = () => {
  return crypto.randomBytes(32).toString('hex');
};
