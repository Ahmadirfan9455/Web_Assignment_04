/**
 * Error handling utilities
 * 
 * This file contains utility functions for handling errors in async/await functions
 * and standardizing error responses.
 */

/**
 * Async error handler wrapper
 * Eliminates the need for try/catch blocks in controllers
 * @param {Function} fn - Async function to wrap
 * @returns {Function} Express middleware function
 */
export const catchAsync = (fn) => {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};

/**
 * Format error response
 * @param {Error} err - Error object
 * @param {number} statusCode - HTTP status code
 * @returns {Object} Formatted error object
 */
export const formatError = (err, statusCode = 500) => {
  return {
    status: 'error',
    statusCode,
    message: err.message || 'Server Error',
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
  };
};

/**
 * Send error response
 * @param {Error} err - Error object
 * @param {Object} res - Express response object
 * @param {number} statusCode - HTTP status code
 */
export const sendError = (err, res, statusCode = 500) => {
  res.status(statusCode).json(formatError(err, statusCode));
};
