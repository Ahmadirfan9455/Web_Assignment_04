import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import http from "http";
import passport from "passport";
import cookieParser from "cookie-parser";
import connectDB from "./config/db.js";
import { initSocketServer } from "./services/socket.service.js";
import { initScheduler } from "./services/scheduler.service.js";
import authRoutes from "./routes/auth.routes.js";
import projectRoutes from "./routes/project.routes.js";
import bidRoutes from "./routes/bid.routes.js";
import messageRoutes from "./routes/message.routes.js";
import adminRoutes from "./routes/admin.routes.js";
import freelancerRoutes from "./routes/freelancer.routes.js";
import notificationRoutes from "./routes/notification.routes.js";
import reviewRoutes from "./routes/review.routes.js";
import uploadRoutes from "./routes/upload.routes.js";
import contractRoutes from "./routes/contract.routes.js";
import exportRoutes from "./routes/export.routes.js";
import timeEntryRoutes from "./routes/timeEntry.routes.js";
import milestoneRoutes from "./routes/milestone.routes.js";
import devRoutes from "./routes/dev.routes.js";
import { errorHandler } from "./middleware/errorHandler.js";
import { attachSocketIO } from "./middleware/socketMiddleware.js";

dotenv.config();
const app = express();
const server = http.createServer(app);

// Initialize Socket.io
initSocketServer(server);

// Initialize scheduler service
initScheduler();

// Middleware
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:3000',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(passport.initialize());
app.use(attachSocketIO);

// Connect to MongoDB Atlas
connectDB();

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/projects", projectRoutes);
app.use("/api/bids", bidRoutes);
app.use("/api/messages", messageRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/admin/time-entries", attachSocketIO, timeEntryRoutes);
app.use("/api/admin/milestones", attachSocketIO, milestoneRoutes);
app.use("/api/notify", notificationRoutes);
app.use("/api/reviews", reviewRoutes);
app.use("/api/freelancers", freelancerRoutes);
app.use("/api/upload", uploadRoutes);
app.use("/api/contracts", contractRoutes);
app.use("/api/export", exportRoutes);

// Development routes (only available in development)
if (process.env.NODE_ENV !== 'production') {
  app.use("/api/dev", devRoutes);
  console.log('⚠️ Development routes enabled');
}

// Serve uploaded files
app.use("/uploads", express.static("uploads"));

// Error handler
app.use(errorHandler);

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
