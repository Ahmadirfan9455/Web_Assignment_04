import mongoose from 'mongoose';

const projectSchema = mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Please add a project title'],
      trim: true,
    },
    description: {
      type: String,
      required: [true, 'Please add a project description'],
    },
    requirements: {
      type: String,
      required: [true, 'Please add project requirements'],
    },
    deadline: {
      type: Date,
      required: [true, 'Please add a deadline'],
    },
    budget: {
      type: Number,
      required: [true, 'Please add a budget'],
    },
    client: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    category: {
      type: String,
      required: [true, 'Please add a category'],
      enum: ['Web Development', 'Mobile Development', 'UI/UX Design', 'Graphic Design', 'Content Writing', 'Digital Marketing', 'Other'],
    },
    skills: [String],
    status: {
      type: String,
      enum: ['open', 'in-progress', 'completed', 'cancelled'],
      default: 'open',
    },
    bids: [
      {
        freelancer: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'User',
          required: true,
        },
        amount: {
          type: Number,
          required: true,
        },
        deliveryTime: {
          type: Number, // In days
          required: true,
        },
        proposal: {
          type: String,
          required: true,
        },
        status: {
          type: String,
          enum: ['pending', 'accepted', 'rejected', 'countered'],
          default: 'pending',
        },
        createdAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],
    assignedFreelancer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    milestones: [
      {
        title: {
          type: String,
          required: true,
        },
        description: {
          type: String,
        },
        dueDate: {
          type: Date,
          required: true,
        },
        amount: {
          type: Number,
          required: true,
        },
        status: {
          type: String,
          enum: ['pending', 'in-progress', 'completed', 'approved'],
          default: 'pending',
        },
        completedAt: Date,
      },
    ],
    progress: {
      type: Number, // Percentage
      default: 0,
    },
    contractHash: {
      type: String, // SHA-256 hash of contract
    },
  },
  {
    timestamps: true,
  }
);

// Add text indexes for search functionality
projectSchema.index({ title: 'text', description: 'text', skills: 'text' });

const Project = mongoose.model('Project', projectSchema);

export default Project;
