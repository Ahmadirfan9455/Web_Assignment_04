import mongoose from 'mongoose';

const reviewSchema = mongoose.Schema(
  {
    project: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Project',
      required: true,
    },
    client: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    freelancer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    rating: {
      type: Number,
      required: [true, 'Please add a rating'],
      min: 1,
      max: 5,
    },
    comment: {
      type: String,
      required: [true, 'Please add a comment'],
    },
    response: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

// Ensure a user can only review a project once
reviewSchema.index({ project: 1, client: 1 }, { unique: true });

const Review = mongoose.model('Review', reviewSchema);

export default Review;
