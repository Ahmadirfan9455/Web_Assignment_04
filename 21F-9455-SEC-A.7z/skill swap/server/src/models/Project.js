import mongoose from 'mongoose';

const projectSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Project title is required'],
    trim: true,
    minlength: [5, 'Project title must be at least 5 characters'],
    maxlength: [100, 'Project title cannot exceed 100 characters']
  },
  description: {
    type: String,
    required: [true, 'Project description is required'],
    trim: true,
    minlength: [20, 'Project description must be at least 20 characters'],
    maxlength: [5000, 'Project description cannot exceed 5000 characters']
  },
  client: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Client is required']
  },
  budget: {
    min: {
      type: Number,
      required: [true, 'Minimum budget is required'],
      min: [5, 'Minimum budget must be at least $5']
    },
    max: {
      type: Number,
      required: [true, 'Maximum budget is required'],
      min: [5, 'Maximum budget must be at least $5']
    }
  },
  duration: {
    type: String,
    required: [true, 'Project duration is required'],
    enum: {
      values: ['less_than_1_week', '1_to_2_weeks', '2_to_4_weeks', '1_to_3_months', '3_to_6_months', 'more_than_6_months'],
      message: 'Invalid project duration'
    }
  },
  skills: [{
    type: String,
    trim: true
  }],
  category: {
    type: String,
    required: [true, 'Project category is required'],
    trim: true
  },
  status: {
    type: String,
    enum: {
      values: ['draft', 'open', 'in_progress', 'completed', 'cancelled'],
      message: 'Invalid project status'
    },
    default: 'open'
  },
  visibility: {
    type: String,
    enum: {
      values: ['public', 'private', 'invite_only'],
      message: 'Invalid visibility option'
    },
    default: 'public'
  },
  attachments: [{
    filename: String,
    originalName: String,
    path: String,
    mimetype: String,
    size: Number,
    uploadedAt: {
      type: Date,
      default: Date.now
    }
  }],
  bids: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Bid'
  }],
  selectedFreelancer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  milestones: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Milestone'
  }],
  contract: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Contract'
  },
  completedAt: Date,
  featured: {
    type: Boolean,
    default: false
  },
  urgent: {
    type: Boolean,
    default: false
  }
}, { timestamps: true });

// Indexes for faster queries
projectSchema.index({ status: 1 });
projectSchema.index({ client: 1 });
projectSchema.index({ selectedFreelancer: 1 });
projectSchema.index({ category: 1 });
projectSchema.index({ 'skills': 1 });
projectSchema.index({ createdAt: -1 });
projectSchema.index({ featured: 1, urgent: 1 });

// Virtual for bid count
projectSchema.virtual('bidCount').get(function() {
  return this.bids ? this.bids.length : 0;
});

// Virtual for average bid
projectSchema.virtual('averageBid').get(function() {
  if (!this.bids || this.bids.length === 0) return 0;
  
  let sum = 0;
  let count = 0;
  
  this.bids.forEach(bid => {
    if (bid.amount) {
      sum += bid.amount;
      count++;
    }
  });
  
  return count > 0 ? sum / count : 0;
});

const Project = mongoose.model('Project', projectSchema);

export default Project;
