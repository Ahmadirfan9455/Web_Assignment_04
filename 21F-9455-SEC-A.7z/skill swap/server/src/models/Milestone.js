import mongoose from 'mongoose';

const milestoneSchema = new mongoose.Schema({
  project: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Project',
    required: true
  },
  title: {
    type: String,
    required: true,
    trim: true,
    minlength: 3,
    maxlength: 100
  },
  description: {
    type: String,
    required: true,
    trim: true,
    minlength: 10,
    maxlength: 1000
  },
  amount: {
    type: Number,
    required: true,
    min: 0
  },
  dueDate: {
    type: Date,
    required: true
  },
  deliverables: [{
    type: String,
    trim: true
  }],
  status: {
    type: String,
    enum: ['not_started', 'in_progress', 'completed', 'approved', 'rejected'],
    default: 'not_started'
  },
  statusHistory: [{
    status: {
      type: String,
      enum: ['not_started', 'in_progress', 'completed', 'approved', 'rejected'],
      required: true
    },
    note: String,
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    date: {
      type: Date,
      default: Date.now
    }
  }],
  attachments: [{
    filename: String,
    originalName: String,
    path: String,
    mimetype: String,
    size: Number,
    uploadedAt: {
      type: Date,
      default: Date.now
    }
  }]
}, { timestamps: true });

// Indexes for faster queries
milestoneSchema.index({ project: 1 });
milestoneSchema.index({ status: 1 });
milestoneSchema.index({ dueDate: 1 });
milestoneSchema.index({ createdAt: -1 });

// Pre-save hook to add status to history if it's a new milestone
milestoneSchema.pre('save', function(next) {
  if (this.isNew) {
    this.statusHistory.push({
      status: this.status,
      note: 'Milestone created',
      date: new Date()
    });
  }
  next();
});

// Virtual for completion percentage
milestoneSchema.virtual('completionPercentage').get(function() {
  const statusWeights = {
    'not_started': 0,
    'in_progress': 50,
    'completed': 90,
    'approved': 100,
    'rejected': 75
  };
  
  return statusWeights[this.status] || 0;
});

const Milestone = mongoose.model('Milestone', milestoneSchema);

export default Milestone;
