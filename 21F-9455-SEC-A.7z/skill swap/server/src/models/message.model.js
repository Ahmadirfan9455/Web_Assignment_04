import mongoose from 'mongoose';
import { hashData } from '../utils/hashUtils.js';

const messageSchema = mongoose.Schema(
  {
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    receiver: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    content: {
      type: String,
      required: [true, 'Message content is required'],
    },
    project: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Project',
    },
    readStatus: {
      type: Boolean,
      default: false,
    },
    metadata: {
      type: String, // Hashed metadata for privacy
    },
    attachments: [
      {
        url: String,
        name: String,
        type: String,
      },
    ],
  },
  {
    timestamps: true,
  }
);

// Pre-save middleware to hash metadata
messageSchema.pre('save', function (next) {
  if (this.isModified('metadata') && this.metadata) {
    this.metadata = hashData(this.metadata);
  }
  next();
});

const Message = mongoose.model('Message', messageSchema);

export default Message;
