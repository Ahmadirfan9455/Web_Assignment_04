import mongoose from 'mongoose';

const timeEntrySchema = new mongoose.Schema({
  project: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Project',
    required: true
  },
  freelancer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  hours: {
    type: Number,
    required: true,
    min: 0.1,
    max: 24
  },
  description: {
    type: String,
    required: true,
    trim: true,
    minlength: 5,
    maxlength: 1000
  },
  tasks: [{
    type: String,
    trim: true
  }],
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected'],
    default: 'pending'
  },
  rejectionReason: {
    type: String,
    trim: true
  },
  statusHistory: [{
    status: {
      type: String,
      enum: ['pending', 'approved', 'rejected'],
      required: true
    },
    note: String,
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    date: {
      type: Date,
      default: Date.now
    }
  }]
}, { timestamps: true });

// Indexes for faster queries
timeEntrySchema.index({ project: 1, freelancer: 1, date: 1 });
timeEntrySchema.index({ status: 1 });
timeEntrySchema.index({ createdAt: -1 });

// Virtual for total hours
timeEntrySchema.virtual('totalHours').get(function() {
  return this.hours;
});

// Pre-save hook to add status to history if it's a new entry
timeEntrySchema.pre('save', function(next) {
  if (this.isNew) {
    this.statusHistory.push({
      status: this.status,
      note: 'Time entry created',
      date: new Date()
    });
  }
  next();
});

const TimeEntry = mongoose.model('TimeEntry', timeEntrySchema);

export default TimeEntry;
