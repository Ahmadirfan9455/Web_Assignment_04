import mongoose from 'mongoose';

/**
 * Bid Schema
 * Represents a freelancer bid on a project
 */
const bidSchema = new mongoose.Schema(
  {
    project: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Project',
      required: [true, 'Project reference is required'],
      index: true,
    },
    freelancer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Freelancer reference is required'],
      index: true,
    },
    amount: {
      type: Number,
      required: [true, 'Bid amount is required'],
      min: [5, 'Bid amount must be at least $5'],
    },
    period: {
      // Period in days the freelancer expects to complete the project
      type: Number,
      required: [true, 'Delivery period (in days) is required'],
      min: [1, 'Delivery period must be at least 1 day'],
    },
    coverLetter: {
      type: String,
      trim: true,
      maxlength: [5000, 'Cover letter cannot exceed 5000 characters'],
    },
    status: {
      type: String,
      enum: {
        values: ['pending', 'accepted', 'rejected', 'withdrawn'],
        message: 'Invalid bid status',
      },
      default: 'pending',
      index: true,
    },
  },
  {
    timestamps: true,
  }
);

// Compound index to ensure a freelancer can bid on a project only once
bidSchema.index({ project: 1, freelancer: 1 }, { unique: true });

const Bid = mongoose.model('Bid', bidSchema);
export default Bid;
