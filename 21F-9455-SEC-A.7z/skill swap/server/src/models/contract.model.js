/**
 * Contract Model
 * 
 * Represents a contract between a client and freelancer for a project.
 * Includes contract terms, signatures, and versioning.
 */

import mongoose from 'mongoose';
import { hashData } from '../utils/hashUtils.js';

const contractSchema = mongoose.Schema(
  {
    project: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Project',
      required: true,
    },
    client: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    freelancer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    terms: {
      type: String,
      required: [true, 'Contract terms are required'],
    },
    clientSignature: {
      signed: {
        type: Boolean,
        default: false,
      },
      timestamp: Date,
      ipAddress: String,
    },
    freelancerSignature: {
      signed: {
        type: Boolean,
        default: false,
      },
      timestamp: Date,
      ipAddress: String,
    },
    status: {
      type: String,
      enum: ['draft', 'pending', 'active', 'completed', 'terminated'],
      default: 'draft',
    },
    hash: {
      type: String, // SHA-256 hash of contract terms
    },
    versions: [
      {
        terms: String,
        hash: String,
        createdBy: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'User',
        },
        createdAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],
    startDate: Date,
    endDate: Date,
    paymentTerms: {
      type: String,
    },
    deliverables: [
      {
        description: String,
        dueDate: Date,
        status: {
          type: String,
          enum: ['pending', 'in-progress', 'completed', 'approved'],
          default: 'pending',
        },
      },
    ],
    attachments: [
      {
        url: String,
        name: String,
        type: String,
        uploadedBy: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'User',
        },
        uploadedAt: Date,
      },
    ],
  },
  {
    timestamps: true,
  }
);

// Pre-save middleware to hash contract terms
contractSchema.pre('save', function (next) {
  if (this.isModified('terms')) {
    // Hash contract terms
    this.hash = hashData(this.terms);
    
    // Add to versions if new or terms changed
    if (this.isNew || this.isModified('terms')) {
      this.versions.push({
        terms: this.terms,
        hash: this.hash,
        createdBy: this.isNew ? this.client : this._modifiedBy,
        createdAt: Date.now(),
      });
    }
  }
  
  // Update status based on signatures
  if (this.clientSignature.signed && this.freelancerSignature.signed) {
    this.status = 'active';
    if (!this.startDate) {
      this.startDate = Date.now();
    }
  } else if (this.clientSignature.signed || this.freelancerSignature.signed) {
    this.status = 'pending';
  }
  
  next();
});

const Contract = mongoose.model('Contract', contractSchema);

export default Contract;
