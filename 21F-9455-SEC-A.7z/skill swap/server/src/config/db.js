import mongoose from "mongoose";
import { createIndexes, validateIndexes } from "./db.indexes.js";

/**
 * Connect to MongoDB Atlas and set up database configuration
 */
const connectDB = async () => {
  try {
    // Configure mongoose options
    mongoose.set('strictQuery', false);
    
    // Set up connection pool
    const options = {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      maxPoolSize: 10, // Maximum number of connections in the pool
      minPoolSize: 2,  // Minimum number of connections in the pool
      serverSelectionTimeoutMS: 5000, // Timeout for server selection
      socketTimeoutMS: 45000, // Close sockets after 45 seconds of inactivity
      family: 4 // Use IPv4, skip trying IPv6
    };
    
    // Connect to MongoDB Atlas
    const mongoUri = process.env.MONGO_URI || process.env.MONGODB_URI;

    if (!mongoUri) {
      throw new Error('MongoDB connection string not found. Please set MONGO_URI (preferred) or MONGODB_URI in your .env file');
    }

    const conn = await mongoose.connect(mongoUri, options);
    console.log(`MongoDB Atlas connected: ${conn.connection.host}`);
    
    // Set up error handling for the connection
    mongoose.connection.on('error', (err) => {
      console.error('MongoDB connection error:', err);
    });
    
    mongoose.connection.on('disconnected', () => {
      console.warn('MongoDB disconnected. Attempting to reconnect...');
    });
    
    mongoose.connection.on('reconnected', () => {
      console.log('MongoDB reconnected successfully');
    });
    
    // Create indexes for optimal performance
    await createIndexes();
    
    // Validate indexes in development environment
    if (process.env.NODE_ENV === 'development') {
      await validateIndexes();
    }
    
    return conn;
  } catch (error) {
    console.error(`MongoDB connection error: ${error.message}`);
    process.exit(1);
  }
};

export default connectDB;
