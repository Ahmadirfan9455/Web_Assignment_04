/**
 * Database Indexes Configuration
 * 
 * This file sets up database indexes for optimized query performance.
 * Proper indexing is crucial for:
 * - Faster query execution
 * - Reduced database load
 * - Efficient sorting and filtering
 * - Supporting text search functionality
 */

import mongoose from 'mongoose';
import { User, Freelancer, Client } from '../models/user.model.js';
import Project from '../models/project.model.js';
import Message from '../models/message.model.js';
import Review from '../models/review.model.js';
import Contract from '../models/contract.model.js';

/**
 * Create indexes for all collections
 */
export const createIndexes = async () => {
  try {
    console.log('Setting up database indexes...');
    
    // User indexes
    await User.collection.createIndexes([
      { key: { email: 1 }, unique: true, background: true },
      { key: { role: 1 }, background: true },
      { key: { verificationToken: 1 }, sparse: true, background: true },
      { key: { resetPasswordToken: 1 }, sparse: true, background: true },
      { key: { isVerified: 1 }, background: true },
    ]);
    
    // Freelancer indexes
    await Freelancer.collection.createIndexes([
      { key: { user: 1 }, unique: true, background: true },
      { key: { skills: 1 }, background: true },
      { key: { verified: 1 }, background: true },
      { key: { verificationLevel: 1 }, background: true },
      { key: { rating: 1 }, background: true },
      { key: { hourlyRate: 1 }, background: true },
    ]);
    
    // Client indexes
    await Client.collection.createIndexes([
      { key: { user: 1 }, unique: true, background: true },
    ]);
    
    // Project indexes
    await Project.collection.createIndexes([
      { key: { client: 1 }, background: true },
      { key: { assignedFreelancer: 1 }, background: true },
      { key: { status: 1 }, background: true },
      { key: { category: 1 }, background: true },
      { key: { deadline: 1 }, background: true },
      { key: { createdAt: 1 }, background: true },
      { key: { 'bids.freelancer': 1 }, background: true },
      { key: { 'milestones.dueDate': 1 }, background: true },
      { key: { 'milestones.status': 1 }, background: true },
      // Text index for search functionality
      { 
        key: { 
          title: 'text', 
          description: 'text', 
          requirements: 'text',
          skills: 'text'
        }, 
        weights: {
          title: 10,
          skills: 5,
          description: 3,
          requirements: 1
        },
        background: true 
      },
    ]);
    
    // Message indexes
    await Message.collection.createIndexes([
      { key: { sender: 1 }, background: true },
      { key: { receiver: 1 }, background: true },
      { key: { project: 1 }, background: true },
      { key: { readStatus: 1 }, background: true },
      { key: { createdAt: 1 }, background: true },
      // Compound index for conversations
      { key: { sender: 1, receiver: 1 }, background: true },
    ]);
    
    // Review indexes
    await Review.collection.createIndexes([
      { key: { project: 1 }, background: true },
      { key: { client: 1 }, background: true },
      { key: { freelancer: 1 }, background: true },
      { key: { rating: 1 }, background: true },
      { key: { createdAt: 1 }, background: true },
      // Unique compound index to ensure one review per project per client
      { key: { project: 1, client: 1 }, unique: true, background: true },
    ]);
    
    // Contract indexes
    await Contract.collection.createIndexes([
      { key: { project: 1 }, unique: true, background: true },
      { key: { client: 1 }, background: true },
      { key: { freelancer: 1 }, background: true },
      { key: { status: 1 }, background: true },
      { key: { createdAt: 1 }, background: true },
      { key: { hash: 1 }, background: true },
    ]);
    
    console.log('Database indexes created successfully');
  } catch (error) {
    console.error('Error creating database indexes:', error);
    // Don't throw error to prevent app from crashing
  }
};

/**
 * Validate existing indexes and repair if needed
 */
export const validateIndexes = async () => {
  try {
    console.log('Validating database indexes...');
    
    // Get all collections
    const collections = [
      User.collection,
      Freelancer.collection,
      Client.collection,
      Project.collection,
      Message.collection,
      Review.collection,
      Contract.collection,
    ];
    
    for (const collection of collections) {
      // Get existing indexes
      const indexes = await collection.indexes();
      
      // Log index information
      console.log(`Collection ${collection.collectionName} has ${indexes.length} indexes`);
      
      // MongoDB Atlas doesn't support the validate command in the same way
      // Just log the indexes instead of trying to validate
      console.log(`Indexes for ${collection.collectionName}:`, indexes.map(idx => idx.name).join(', '));
      
      // No validation result to check since Atlas doesn't support this
      console.log(`Collection ${collection.collectionName} indexes logged successfully`);
    }
    
    console.log('Database indexes validated successfully');
  } catch (error) {
    console.error('Error validating database indexes:', error);
  }
};
