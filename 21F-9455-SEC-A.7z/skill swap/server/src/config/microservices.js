/**
 * Microservices Configuration
 * 
 * This file contains the configuration for connecting to microservices.
 * In a real microservice architecture, these would be separate services
 * with their own deployments, potentially on different servers.
 * 
 * For this implementation, we're using a monolithic approach with
 * microservice-ready code organization for future scalability.
 */

export const microservices = {
  notification: {
    baseUrl: process.env.NOTIFICATION_SERVICE_URL || 'http://localhost:5001/api',
    timeout: 5000, // ms
  },
  analytics: {
    baseUrl: process.env.ANALYTICS_SERVICE_URL || 'http://localhost:5002/api',
    timeout: 5000, // ms
  },
};

/**
 * Make a request to a microservice
 * @param {string} service - Service name (e.g., 'notification', 'analytics')
 * @param {string} endpoint - API endpoint
 * @param {string} method - HTTP method
 * @param {Object} data - Request data
 * @returns {Promise<Object>} Response data
 */
export const callMicroservice = async (service, endpoint, method = 'GET', data = null) => {
  if (!microservices[service]) {
    throw new Error(`Microservice '${service}' not configured`);
  }

  const url = `${microservices[service].baseUrl}/${endpoint}`;
  
  try {
    // In a real implementation, this would use axios or fetch
    console.log(`[MICROSERVICE CALL] ${method} ${url}`);
    
    // For now, we're directly importing and calling the microservice functions
    // In a real deployment, this would be an HTTP request to a separate service
    
    if (service === 'notification') {
      const notificationService = await import('../microservices/notification/services.js');
      
      // Map endpoint to function
      switch (endpoint) {
        case 'email':
          return await notificationService.sendEmail(data.recipient, data.subject, data.message);
        case 'sms':
          return await notificationService.sendSMS(data.recipient, data.message);
        case 'in-app':
          return await notificationService.sendInAppNotification(
            data.recipient, data.type, data.title, data.message, data.data
          );
        default:
          throw new Error(`Unknown notification endpoint: ${endpoint}`);
      }
    }
    
    if (service === 'analytics') {
      const analyticsService = await import('../microservices/analytics/services.js');
      
      // Map endpoint to function
      switch (endpoint) {
        case 'analytics/users':
          return await analyticsService.getUserGrowth(data?.period);
        case 'analytics/projects':
          return await analyticsService.getProjectAnalytics(data);
        case 'analytics/bids':
          return await analyticsService.getBidAnalytics(data);
        case 'analytics/revenue':
          return await analyticsService.getRevenueAnalytics(data?.period);
        case 'analytics/skills':
          return await analyticsService.getPopularSkills(data?.limit);
        default:
          throw new Error(`Unknown analytics endpoint: ${endpoint}`);
      }
    }
    
    throw new Error(`Service implementation not found: ${service}`);
  } catch (error) {
    console.error(`Error calling microservice ${service}/${endpoint}:`, error);
    throw error;
  }
};
