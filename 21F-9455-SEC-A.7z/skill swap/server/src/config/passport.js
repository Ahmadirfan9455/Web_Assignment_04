import passport from 'passport';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import { User, Client, Freelancer } from '../models/user.model.js';
import dotenv from 'dotenv';

dotenv.config();

// Check if Google OAuth credentials are available
const googleClientId = process.env.GOOGLE_CLIENT_ID || 'dummy-client-id';
const googleClientSecret = process.env.GOOGLE_CLIENT_SECRET || 'dummy-client-secret';

// Configure Google Strategy if credentials are available
if (googleClientId === 'dummy-client-id' || googleClientSecret === 'dummy-client-secret') {
  console.warn('⚠️ Google OAuth is not fully configured. Please set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in your .env file.');
}

// Configure Google Strategy
console.log('Google OAuth credentials:', { clientID: googleClientId, clientSecret: googleClientSecret?.substring(0, 5) + '...' });

passport.use(
  new GoogleStrategy(
    {
      clientID: googleClientId,
      clientSecret: googleClientSecret,
      callbackURL: 'http://localhost:5000/api/auth/google/callback',
      scope: ['profile', 'email'],
      proxy: true
    },
    async (accessToken, refreshToken, profile, done) => {
      try {
        // Check if user already exists
        const existingUser = await User.findOne({ email: profile.emails[0].value });

        if (existingUser) {
          // If user exists but was registered via email/password (no googleId)
          if (!existingUser.googleId) {
            existingUser.googleId = profile.id;
            existingUser.isVerified = true; // Auto-verify Google accounts
            await existingUser.save();
          }
          return done(null, existingUser);
        }

        // Create new user if doesn't exist
        const newUser = await User.create({
          name: profile.displayName,
          email: profile.emails[0].value,
          googleId: profile.id,
          isVerified: true, // Auto-verify Google accounts
          role: 'client', // Default role
          profileImage: profile.photos?.[0]?.value || '',
        });

        // Create client profile for the user
        await Client.create({
          user: newUser._id,
        });

        return done(null, newUser);
      } catch (error) {
        return done(error, null);
      }
    }
  )
);

// Serialize user for the session
passport.serializeUser((user, done) => {
  done(null, user.id);
});

// Deserialize user from the session
passport.deserializeUser(async (id, done) => {
  try {
    const user = await User.findById(id);
    done(null, user);
  } catch (error) {
    done(error, null);
  }
});

export default passport;
