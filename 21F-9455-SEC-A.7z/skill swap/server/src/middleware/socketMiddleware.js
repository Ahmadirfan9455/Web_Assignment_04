/**
 * Socket.io Middleware
 * 
 * This middleware attaches the Socket.io instance to the request object
 * so controllers can emit real-time updates.
 */

import { getIO } from '../services/socket.service.js';

export const attachSocketIO = (req, res, next) => {
  try {
    // Attach Socket.io instance to request
    req.io = getIO();
    next();
  } catch (error) {
    console.warn('Socket.io not initialized, continuing without real-time functionality');
    next();
  }
};
