/**
 * File Upload Middleware
 * 
 * This middleware handles file uploads for:
 * - Freelancer verification documents
 * - Project attachments
 * - User profile images
 * 
 * Uses multer for file handling and includes validation for file types and sizes.
 */

import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { v4 as uuidv4 } from 'uuid';

// Ensure upload directories exist
const createDirIfNotExists = (dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
};

// Create upload directories
createDirIfNotExists('uploads');
createDirIfNotExists('uploads/documents');
createDirIfNotExists('uploads/projects');
createDirIfNotExists('uploads/profiles');

// Configure storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    let uploadPath = 'uploads/';
    
    // Determine upload directory based on file type
    if (req.uploadType === 'document') {
      uploadPath += 'documents/';
    } else if (req.uploadType === 'project') {
      uploadPath += 'projects/';
    } else if (req.uploadType === 'profile') {
      uploadPath += 'profiles/';
    }
    
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    // Generate unique filename with original extension
    const uniqueFilename = `${uuidv4()}${path.extname(file.originalname)}`;
    cb(null, uniqueFilename);
  },
});

// File filter for allowed file types
const fileFilter = (req, file, cb) => {
  // Define allowed file types based on upload type
  let allowedTypes = [];
  
  if (req.uploadType === 'document') {
    // Allow PDFs, images, and document files for verification
    allowedTypes = ['.pdf', '.jpg', '.jpeg', '.png', '.doc', '.docx'];
  } else if (req.uploadType === 'project') {
    // Allow various file types for project attachments
    allowedTypes = ['.pdf', '.jpg', '.jpeg', '.png', '.doc', '.docx', '.xls', '.xlsx', '.zip', '.rar'];
  } else if (req.uploadType === 'profile') {
    // Allow only images for profile pictures
    allowedTypes = ['.jpg', '.jpeg', '.png'];
  }
  
  // Check if file extension is allowed
  const ext = path.extname(file.originalname).toLowerCase();
  if (allowedTypes.includes(ext)) {
    cb(null, true);
  } else {
    cb(new Error(`Invalid file type. Allowed types: ${allowedTypes.join(', ')}`), false);
  }
};

// Create multer upload instance
const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB file size limit
  },
});

/**
 * Set upload type middleware
 * @param {string} type - Upload type ('document', 'project', 'profile')
 */
export const setUploadType = (type) => {
  return (req, res, next) => {
    req.uploadType = type;
    next();
  };
};

/**
 * Single file upload middleware
 */
export const uploadSingleFile = (req, res, next) => {
  upload.single('file')(req, res, (err) => {
    if (err) {
      return handleUploadErrors(err, req, res, next);
    }
    next();
  });
};

/**
 * Multiple files upload middleware
 * @param {number} maxCount - Maximum number of files
 */
export const uploadMultipleFiles = (maxCount = 5) => {
  return (req, res, next) => {
    upload.array('files', maxCount)(req, res, (err) => {
      if (err) {
        return handleUploadErrors(err, req, res, next);
      }
      next();
    });
  };
};

/**
 * Error handler for multer errors
 */
export const handleUploadErrors = (err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    // Multer error
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        message: 'File too large. Maximum size is 10MB.',
      });
    }
    return res.status(400).json({
      message: `Upload error: ${err.message}`,
    });
  } else if (err) {
    // Other errors
    return res.status(400).json({
      message: err.message,
    });
  }
  
  next();
};
